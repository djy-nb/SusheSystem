---
name: learn-codebase
description: 快速吃透陌生代码库，理解项目架构和业务逻辑
user_invocable: true
---

# Learn Codebase - 代码库学习助手

帮助快速理解和掌握陌生代码库。

## 功能特性

- 代码结构分析
- 业务流程梳理
- 核心逻辑解读
- 学习路径规划

## 使用方式

```
/learn-codebase 帮我理解这个项目的整体架构
/learn-codebase 梳理用户管理模块的业务流程
/learn-codebase 解读订单处理的核心逻辑
```

## 学习方法

### 1. 宏观架构
```
项目结构 → 技术栈 → 模块划分 → 依赖关系
```

### 2. 业务流程
```
入口 → 控制器 → 服务层 → 数据层 → 响应
```

### 3. 核心逻辑
```
设计模式 → 关键算法 → 数据流转 → 状态管理
```

## 分析维度

### 1. 结构分析
- 目录组织
- 模块职责
- 代码分层
- 依赖关系

### 2. 业务梳理
- 功能模块
- 业务流程
- 数据模型
- 接口设计

### 3. 技术要点
- 框架使用
- 设计模式
- 关键算法
- 性能优化

### 4. 规范学习
- 代码风格
- 命名规范
- 注释规范
- 测试规范

## 学习路径

### 阶段一：快速浏览
1. 阅读 README.md
2. 查看项目结构
3. 识别技术栈
4. 了解构建方式

### 阶段二：深入理解
1. 找到入口文件
2. 跟踪核心流程
3. 理解数据模型
4. 学习关键代码

### 阶段三：实践掌握
1. 运行项目
2. 调试核心功能
3. 修改简单功能
4. 添加新功能

## 输出示例

```markdown
## 代码库学习报告

### 📋 项目概览
- 项目名称: 智能宿舍管理系统
- 技术栈: Spring Boot + Vue 3
- 主要功能: 宿舍管理、报修、能耗等

### 🏗️ 架构分析
├── 前端 (Vue 3)
│   ├── src/views/     # 页面组件
│   ├── src/api/       # API 接口
│   └── src/store/     # 状态管理
│
└── 后端 (Spring Boot)
    ├── controller/    # 控制器
    ├── service/       # 业务逻辑
    └── mapper/        # 数据访问

### 🎯 核心模块
1. **用户管理**
   - 登录认证 (JWT)
   - 权限控制 (RBAC)
   - 用户信息管理

2. **宿舍管理**
   - 楼栋管理
   - 房间管理
   - 床位分配

3. **报修管理**
   - 工单创建
   - 状态流转
   - 统计分析

### 📚 学习建议
1. 从 `main.js` 和 `Application.java` 开始
2. 重点关注 `service` 层的业务逻辑
3. 理解 `mapper` 层的数据操作
4. 学习 `controller` 层的接口设计

### 🔍 关键代码
- 认证逻辑: `SecurityConfig.java`
- 权限控制: `@PreAuthorize`
- 数据校验: `@Valid`
- 异常处理: `GlobalExceptionHandler`
```

## 学习技巧

### 1. 善用搜索
```bash
# 搜索关键类
grep -r "class.*Service" --include="*.java"

# 搜索关键方法
grep -r "public.*find.*ById" --include="*.java"
```

### 2. 跟踪调用链
```
Controller → Service → Mapper → Database
```

### 3. 理解数据流
```
Request → DTO → Entity → Database → Entity → DTO → Response
```

### 4. 学习测试用例
- 单元测试理解方法功能
- 集成测试理解业务流程
- 接口测试理解 API 设计
