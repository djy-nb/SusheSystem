---
name: security-review
description: 代码安全漏洞扫描，发现潜在安全风险
user_invocable: true
---

# Security Review - 安全审查助手

扫描代码中的安全漏洞和潜在风险。

## 功能特性

- SQL 注入检测
- XSS 漏洞扫描
- 敏感信息泄露检查
- 权限控制审查

## 使用方式

```
/security-review 扫描整个项目的安全漏洞
/security-review 审查用户认证模块
```

## 检查类别

### 1. 注入漏洞
- **SQL 注入**: 字符串拼接 SQL
- **命令注入**: Runtime.exec() 参数
- **LDAP 注入**: LDAP 查询拼接
- **XPath 注入**: XPath 表达式拼接

### 2. 跨站脚本 (XSS)
- 反射型 XSS
- 存储型 XSS
- DOM 型 XSS
- 未转义的用户输入

### 3. 敏感信息泄露
- 硬编码密码/密钥
- 日志输出敏感信息
- 异常信息泄露
- 配置文件暴露

### 4. 认证与授权
- 弱密码策略
- 会话管理问题
- 权限检查缺失
- 越权访问风险

### 5. 数据安全
- 明文存储密码
- 不安全的加密算法
- 缺少数据校验
- 敏感数据传输

### 6. 依赖安全
- 已知漏洞的依赖库
- 过期的依赖版本
- 不安全的依赖源

## Java 常见安全问题

### SQL 注入
```java
// ❌ 危险
String sql = "SELECT * FROM user WHERE id = " + id;

// ✅ 安全
String sql = "SELECT * FROM user WHERE id = ?";
PreparedStatement ps = conn.prepareStatement(sql);
ps.setInt(1, id);
```

### XSS 防护
```java
// ❌ 危险
model.addAttribute("input", userInput);

// ✅ 安全
String safeInput = HtmlUtils.htmlEscape(userInput);
model.addAttribute("input", safeInput);
```

### 密码存储
```java
// ❌ 危险
String password = user.getPassword();

// ✅ 安全
BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
String hashedPassword = encoder.encode(rawPassword);
```

## 输出格式

```markdown
## 安全审查报告

### 🔴 高危漏洞
1. [UserService.java:45] SQL 注入风险
   - 问题: 字符串拼接 SQL 语句
   - 建议: 使用 PreparedStatement

### 🟡 中危漏洞
1. [LoginController.java:23] 缺少 CSRF 防护
   - 建议: 添加 @CrossOrigin 或 CSRF Token

### 🟢 低危问题
1. [application.yml:10] 密码明文存储
   - 建议: 使用环境变量或加密存储

### 📊 统计
- 扫描文件: 100
- 高危: 2
- 中危: 5
- 低危: 8
```
