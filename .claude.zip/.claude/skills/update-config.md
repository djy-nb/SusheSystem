---
name: update-config
description: 个性化配置优化，自定义 Claude Code 使用体验
user_invocable: true
---

# Update Config - 配置优化助手

优化 Claude Code 配置，提升使用体验。

## 功能特性

- 个性化配置
- 性能优化
- 快捷操作设置
- 工作流定制

## 使用方式

```
/update-config 优化我的 Claude Code 配置
/update-config 设置快捷命令
/update-config 配置自动补全
```

## 配置维度

### 1. 基础配置
- 模型选择
- 响应风格
- 语言设置
- 主题配置

### 2. 快捷操作
- 自定义命令
- 代码片段
- 快捷键绑定
- 模板管理

### 3. 工作流优化
- 任务自动化
- 批处理配置
- 监控告警
- 报告生成

### 4. 集成配置
- Git 集成
- IDE 集成
- CI/CD 集成
- 第三方服务

## 配置文件

### 项目配置
```json
// .claude/config.json
{
  "model": "claude-3-5-sonnet",
  "language": "zh-CN",
  "theme": "dark",
  "autoSave": true,
  "quickCommands": {
    "build": "mvn clean package",
    "test": "mvn test",
    "run": "mvn spring-boot:run"
  }
}
```

### 用户配置
```json
// ~/.claude/config.json
{
  "defaultModel": "claude-3-5-sonnet",
  "responseStyle": "concise",
  "codeStyle": {
    "indent": 4,
    "lineLength": 120,
    "formatOnSave": true
  }
}
```

## 优化建议

### 1. 响应优化
```json
{
  "response": {
    "maxTokens": 4096,
    "temperature": 0.7,
    "stream": true
  }
}
```

### 2. 代码风格
```json
{
  "codeStyle": {
    "java": {
      "indent": 4,
      "importOrder": ["java.", "javax.", "org.", "com."]
    },
    "vue": {
      "scriptSetup": true,
      "styleScoped": true
    }
  }
}
```

### 3. 快捷命令
```json
{
  "shortcuts": {
    "/run": "运行项目",
    "/test": "运行测试",
    "/build": "构建项目",
    "/deploy": "部署项目"
  }
}
```

## 性能优化

### 1. 缓存配置
```json
{
  "cache": {
    "enabled": true,
    "maxSize": 1000,
    "ttl": 3600
  }
}
```

### 2. 并发配置
```json
{
  "concurrency": {
    "maxConcurrent": 5,
    "queueSize": 100
  }
}
```

## 常见配置

### Java 项目
```json
{
  "java": {
    "version": "17",
    "buildTool": "maven",
    "framework": "spring-boot",
    "codeStyle": "google"
  }
}
```

### Vue 项目
```json
{
  "vue": {
    "version": 3,
    "ui": "element-plus",
    "stateManagement": "pinia",
    "router": "vue-router"
  }
}
```

## 配置管理

### 导出配置
```bash
/export-config > config-backup.json
```

### 导入配置
```bash
/import-config config-backup.json
```

### 重置配置
```bash
/reset-config
```

## 最佳实践

### 1. 版本控制
- 将项目配置纳入版本控制
- 用户配置保持本地
- 敏感信息使用环境变量

### 2. 团队协作
- 统一代码风格配置
- 共享常用快捷命令
- 维护团队模板库

### 3. 持续优化
- 定期review配置
- 根据使用习惯调整
- 优化常用操作流程
