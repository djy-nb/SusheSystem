---
name: frontend-design
description: 通过语音描述生成 UI 界面代码，支持 Vue/React 等框架
user_invocable: true
---

# Frontend Design - UI 界面生成器

根据用户描述生成完整的 UI 界面代码。

## 功能特性

- 支持自然语言描述生成界面
- 支持 Vue 3 / React 等主流框架
- 集成 Element Plus / Ant Design 等 UI 库
- 生成响应式布局代码

## 使用方式

```
/frontend-design 生成一个登录页面，包含用户名、密码输入框和登录按钮，使用卡片布局居中显示
```

## 生成流程

1. **解析需求**: 提取界面元素、布局、交互要求
2. **选择模板**: 根据框架和 UI 库选择基础模板
3. **生成代码**: 输出完整可运行的组件代码
4. **优化建议**: 提供样式优化和交互改进建议

## 支持的界面类型

- 表单页面（登录、注册、设置）
- 列表页面（数据表格、卡片列表）
- 详情页面（文章、商品详情）
- 仪表盘（数据统计、图表展示）
- 弹窗组件（确认框、表单弹窗）

## 输出示例

```vue
<template>
  <div class="login-container">
    <el-card class="login-card">
      <h2>系统登录</h2>
      <el-form>
        <el-form-item>
          <el-input placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item>
          <el-input type="password" placeholder="请输入密码" />
        </el-form-item>
        <el-button type="primary" block>登录</el-button>
      </el-form>
    </el-card>
  </div>
</template>
```
