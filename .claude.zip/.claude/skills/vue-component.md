---
name: vue-component
description: 生成符合项目风格的 Vue 3 组件，使用 Element Plus 和 Echarts
user_invocable: true
---

# Vue 组件生成器

根据用户需求生成符合项目风格的 Vue 3 组件。

## 项目技术栈

- **框架**: Vue 3 (Composition API)
- **UI库**: Element Plus
- **图表**: Echarts
- **构建**: Vite
- **样式**: SCSS

## 代码规范

### 模板规范
- 使用 `<script setup>` 语法
- Element Plus 组件使用 `el-` 前缀
- 图标从 `@element-plus/icons-vue` 导入

### 样式规范
- 使用 `<style lang="scss" scoped>`
- BEM 命名规范（如 `.block__element--modifier`）
- 颜色使用 Element Plus 变量

### 目录结构
```
frontend/src/
├── api/          # API 接口
├── views/        # 页面组件
│   └── [module]/
│       └── index.vue
└── components/   # 公共组件
```

## 生成流程

1. **确认需求**: 了解组件类型（页面/公共）、功能、数据结构
2. **检查 API**: 查看 `frontend/src/api/` 下是否有对应接口
3. **生成代码**: 按照项目风格生成完整组件
4. **输出位置**: 建议用户放置路径

## 组件模板

### 页面组件模板

```vue
<template>
  <div class="[module]-container">
    <!-- 内容区域 -->
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
// 导入 API

// 响应式数据

// 方法

// 生命周期
onMounted(() => {
  // 初始化
})
</script>

<style lang="scss" scoped>
.[module]-container {
  // 样式
}
</style>
```

### 表格页面模板

```vue
<template>
  <div class="[module]-container">
    <!-- 搜索区域 -->
    <el-card shadow="never" class="search-card">
      <el-form :model="searchForm" inline>
        <!-- 搜索项 -->
        <el-form-item>
          <el-button type="primary" @click="handleSearch">搜索</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 表格区域 -->
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>数据列表</span>
          <el-button type="primary" @click="handleAdd">新增</el-button>
        </div>
      </template>

      <el-table :data="tableData" v-loading="loading" border>
        <!-- 表格列 -->
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row)">编辑</el-button>
            <el-button link type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 新增/编辑弹窗 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <!-- 表单项 -->
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

// 搜索表单
const searchForm = ref({})
const pageNum = ref(1)
const pageSize = ref(10)
const total = ref(0)

// 表格数据
const tableData = ref([])
const loading = ref(false)

// 弹窗相关
const dialogVisible = ref(false)
const dialogTitle = ref('')
const form = ref({})
const formRef = ref(null)

// 表单验证规则
const rules = {
  // 定义验证规则
}

// 获取数据
async function fetchData() {
  loading.value = true
  try {
    // 调用 API
  } catch (error) {
    console.error(error)
  } finally {
    loading.value = false
  }
}

// 搜索
function handleSearch() {
  pageNum.value = 1
  fetchData()
}

// 重置
function handleReset() {
  searchForm.value = {}
  handleSearch()
}

// 新增
function handleAdd() {
  dialogTitle.value = '新增'
  form.value = {}
  dialogVisible.value = true
}

// 编辑
function handleEdit(row) {
  dialogTitle.value = '编辑'
  form.value = { ...row }
  dialogVisible.value = true
}

// 删除
async function handleDelete(row) {
  try {
    await ElMessageBox.confirm('确认删除该记录？', '提示', {
      type: 'warning'
    })
    // 调用删除 API
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    // 取消操作
  }
}

// 提交表单
async function handleSubmit() {
  // 表单验证
  // 调用新增/编辑 API
  ElMessage.success('操作成功')
  dialogVisible.value = false
  fetchData()
}

// 分页
function handleSizeChange() {
  pageNum.value = 1
  fetchData()
}

function handleCurrentChange() {
  fetchData()
}

onMounted(() => {
  fetchData()
})
</script>

<style lang="scss" scoped>
.[module]-container {
  .search-card {
    margin-bottom: 20px;
  }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .pagination-wrapper {
    margin-top: 20px;
    display: flex;
    justify-content: flex-end;
  }
}
</style>
```

## 使用方式

用户输入 `/vue-component` 后，询问：
1. 组件类型（页面/公共）
2. 功能描述
3. 数据结构（如有）
4. 放置路径

然后按照规范生成完整组件代码。
