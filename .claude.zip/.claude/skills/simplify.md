---
name: simplify
description: 代码冗余检查与瘦身，提高代码质量和可维护性
user_invocable: true
---

# Simplify - 代码瘦身助手

分析代码冗余，提供简化和优化建议。

## 功能特性

- 检测重复代码
- 识别未使用的代码
- 分析过度复杂的逻辑
- 提供简化方案

## 使用方式

```
/simplify 分析 src/main/java 目录下的代码冗余
/simplify 简化 UserService.java 文件
```

## 检查维度

### 1. 重复代码
- 相同逻辑多处出现
- 可提取的公共方法
- 可复用的工具类

### 2. 未使用代码
- 未调用的方法
- 未使用的变量
- 废弃的类和接口

### 3. 复杂逻辑
- 过长的方法（>50行）
- 过深的嵌套（>3层）
- 复杂的条件表达式

### 4. 代码异味
- 过大的类
- 过多的参数
- 魔法数字
- 硬编码字符串

## 优化建议

### 提取方法
```java
// 优化前
public void process() {
    // 100行代码
}

// 优化后
public void process() {
    validateInput();
    processData();
    saveResult();
    sendNotification();
}
```

### 提取常量
```java
// 优化前
if (status == 1) { ... }

// 优化后
private static final int STATUS_ACTIVE = 1;
if (status == STATUS_ACTIVE) { ... }
```

### 使用设计模式
- 策略模式替代复杂 if-else
- 模板方法模式提取公共流程
- 工厂模式替代复杂创建逻辑

## 输出格式

```markdown
## 代码瘦身报告

### 📊 统计
- 分析文件: 50
- 发现问题: 15
- 潜在节省: 500行代码

### 🔍 详细发现

#### 重复代码
1. [UserService.java:45] 和 [AdminService.java:67] 存在相同逻辑
   - 建议: 提取到 BaseService

#### 未使用代码
1. [Utils.java:123] methodX() 未被调用
   - 建议: 删除或标记为 @Deprecated

#### 复杂逻辑
1. [OrderService.java:200] processOrder() 方法过长
   - 建议: 拆分为多个子方法
```
