---
name: claude-api
description: Claude API 开发指导，避坑与优化建议
user_invocable: true
---

# Claude API - 开发助手

Claude API 集成开发指导，帮助避开常见坑点。

## 功能特性

- API 集成指导
- 常见问题排查
- 性能优化建议
- 最佳实践推荐

## 使用方式

```
/claude-api 帮我集成 Claude API 到 Spring Boot 项目
/claude-api 优化我的 API 调用代码
/claude-api 排查 API 调用失败的问题
```

## API 集成指南

### 1. 环境准备
```xml
<!-- Maven 依赖 -->
<dependency>
    <groupId>com.anthropic</groupId>
    <artifactId>anthropic-java</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 2. 基础配置
```java
@Configuration
public class ClaudeConfig {
    
    @Value("${anthropic.api-key}")
    private String apiKey;
    
    @Bean
    public AnthropicClient anthropicClient() {
        return AnthropicClient.builder()
            .apiKey(apiKey)
            .build();
    }
}
```

### 3. 基础调用
```java
@Service
public class ClaudeService {
    
    private final AnthropicClient client;
    
    public String chat(String message) {
        Message response = client.messages()
            .create(MessageCreateParams.builder()
                .model(Model.CLAUDE_3_5_SONNET)
                .maxTokens(1024)
                .addUserMessage(message)
                .build());
        
        return response.content().get(0).text();
    }
}
```

## 常见坑点

### 1. API Key 安全
```java
// ❌ 危险：硬编码
private String apiKey = "sk-ant-xxx";

// ✅ 安全：环境变量
@Value("${ANTHROPIC_API_KEY}")
private String apiKey;
```

### 2. 请求超时
```java
// ❌ 默认超时可能不够
AnthropicClient client = AnthropicClient.builder()
    .apiKey(apiKey)
    .build();

// ✅ 设置合理超时
AnthropicClient client = AnthropicClient.builder()
    .apiKey(apiKey)
    .timeout(Duration.ofSeconds(30))
    .build();
```

### 3. 错误处理
```java
// ❌ 忽略异常
try {
    return client.messages().create(params);
} catch (Exception e) {
    return null;
}

// ✅ 正确处理
try {
    return client.messages().create(params);
} catch (AnthropicException e) {
    log.error("API调用失败: {}", e.getMessage());
    throw new BusinessException("AI服务暂时不可用");
}
```

### 4. Token 限制
```java
// ❌ 不限制输入长度
String prompt = veryLongText;

// ✅ 截断过长输入
int maxTokens = 4000;
String prompt = truncateToTokenLimit(input, maxTokens);
```

## 性能优化

### 1. 流式响应
```java
// 使用流式减少首字延迟
client.messages()
    .createStream(params)
    .forEach(chunk -> {
        // 处理每个chunk
    });
```

### 2. 缓存机制
```java
@Cacheable(value = "claude-cache", key = "#message.hashCode()")
public String chat(String message) {
    return client.messages().create(params).content();
}
```

### 3. 重试机制
```java
@Retryable(value = AnthropicException.class, maxAttempts = 3)
public String chatWithRetry(String message) {
    return chat(message);
}
```

## 成本控制

### Token 计算
```java
// 估算token数
int estimateTokens(String text) {
    return text.length() / 4; // 粗略估算
}
```

### 成本监控
```java
// 记录每次调用的token使用
log.info("输入tokens: {}, 输出tokens: {}, 费用: ${}", 
    inputTokens, outputTokens, cost);
```
