-- =============================================
-- 添加辅导员角色数据库更新脚本
-- 执行此脚本前请先备份数据库
-- =============================================

USE sushe_system;

-- 1. 更新 sys_user 表的 role 字段注释
ALTER TABLE sys_user MODIFY COLUMN role VARCHAR(20) NOT NULL DEFAULT 'STUDENT' COMMENT '角色：ADMIN-管理员 DORM_ADMIN-宿管员 COUNSELOR-辅导员 STUDENT-学生';

-- 2. 更新现有学生的 college 和 class_name 字段（如果为空）
UPDATE sys_user SET college = '计算机科学与技术学院', class_name = '计科2301班' WHERE username = 'student001' AND (college IS NULL OR college = '');
UPDATE sys_user SET college = '计算机科学与技术学院', class_name = '计科2301班' WHERE username = 'student002' AND (college IS NULL OR college = '');
UPDATE sys_user SET college = '计算机科学与技术学院', class_name = '计科2302班' WHERE username = 'student003' AND (college IS NULL OR college = '');
UPDATE sys_user SET college = '电子信息工程学院', class_name = '电信2301班' WHERE username = 'student004' AND (college IS NULL OR college = '');
UPDATE sys_user SET college = '电子信息工程学院', class_name = '电信2301班' WHERE username = 'student005' AND (college IS NULL OR college = '');

-- 3. 插入辅导员账号（密码：123456，BCrypt加密）
-- 如果已存在则跳过
INSERT INTO sys_user (username, password, real_name, gender, phone, role, user_code, college, status)
SELECT 'counselor1', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '陈辅导员', 0, '13800000009', 'COUNSELOR', 'CS001', '计算机科学与技术学院', 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM sys_user WHERE username = 'counselor1');

INSERT INTO sys_user (username, password, real_name, gender, phone, role, user_code, college, status)
SELECT 'counselor2', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '周辅导员', 1, '13800000010', 'COUNSELOR', 'CS002', '电子信息工程学院', 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM sys_user WHERE username = 'counselor2');

-- 4. 验证数据
SELECT '=== 辅导员账号 ===' AS info;
SELECT id, username, real_name, role, college, user_code, status FROM sys_user WHERE role = 'COUNSELOR';

SELECT '=== 学生数据 ===' AS info;
SELECT id, username, real_name, role, college, class_name FROM sys_user WHERE role = 'STUDENT';

SELECT '数据库更新完成！' AS message;
