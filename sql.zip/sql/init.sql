-- =============================================
-- 智能宿舍管理系统数据库初始化脚本
-- Smart Dormitory Management System
-- =============================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS sushe_system DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE sushe_system;

-- =============================================
-- 1. 用户表
-- =============================================
DROP TABLE IF EXISTS sys_user;
CREATE TABLE sys_user (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '用户ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(100) NOT NULL COMMENT '密码',
    real_name VARCHAR(50) COMMENT '真实姓名',
    gender TINYINT DEFAULT 0 COMMENT '性别：0-女 1-男',
    phone VARCHAR(20) COMMENT '手机号',
    email VARCHAR(100) COMMENT '邮箱',
    avatar VARCHAR(255) COMMENT '头像',
    role VARCHAR(20) NOT NULL DEFAULT 'STUDENT' COMMENT '角色：ADMIN-管理员 DORM_ADMIN-宿管员 COUNSELOR-辅导员 STUDENT-学生',
    user_code VARCHAR(50) COMMENT '学号/工号',
    id_card VARCHAR(20) COMMENT '身份证号',
    college VARCHAR(100) COMMENT '所属学院',
    class_name VARCHAR(50) COMMENT '所属班级',
    status TINYINT DEFAULT 1 COMMENT '账号状态：0-禁用 1-正常',
    last_login_time DATETIME COMMENT '最后登录时间',
    last_login_ip VARCHAR(50) COMMENT '最后登录IP',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志：0-未删除 1-已删除',
    INDEX idx_username (username),
    INDEX idx_user_code (user_code),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- =============================================
-- 2. 宿舍楼表
-- =============================================
DROP TABLE IF EXISTS dorm_building;
CREATE TABLE dorm_building (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '楼栋ID',
    name VARCHAR(50) NOT NULL COMMENT '楼栋名称',
    code VARCHAR(20) NOT NULL UNIQUE COMMENT '楼栋编号',
    floor_count INT DEFAULT 6 COMMENT '楼层数',
    room_count INT DEFAULT 0 COMMENT '总房间数',
    occupied_count INT DEFAULT 0 COMMENT '已入住人数',
    type TINYINT DEFAULT 1 COMMENT '楼栋类型：1-男生宿舍 2-女生宿舍 3-混合宿舍',
    address VARCHAR(200) COMMENT '楼栋地址',
    longitude DECIMAL(10,7) COMMENT '经度',
    latitude DECIMAL(10,7) COMMENT '纬度',
    admin_id BIGINT COMMENT '宿管员ID',
    contact_phone VARCHAR(20) COMMENT '联系电话',
    remark VARCHAR(500) COMMENT '备注',
    status TINYINT DEFAULT 1 COMMENT '状态：0-停用 1-正常',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志',
    INDEX idx_code (code),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宿舍楼表';

-- =============================================
-- 3. 宿舍房间表
-- =============================================
DROP TABLE IF EXISTS dorm_room;
CREATE TABLE dorm_room (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '房间ID',
    building_id BIGINT NOT NULL COMMENT '所属楼栋ID',
    room_number VARCHAR(20) NOT NULL COMMENT '房间号',
    floor INT COMMENT '楼层',
    room_type TINYINT DEFAULT 1 COMMENT '房间类型：1-四人间 2-六人间 3-八人间 4-单人间',
    bed_count INT DEFAULT 4 COMMENT '床位数',
    occupied_count INT DEFAULT 0 COMMENT '已入住人数',
    area DECIMAL(6,2) COMMENT '房间面积（平方米）',
    status TINYINT DEFAULT 1 COMMENT '房间状态：0-空闲 1-正常 2-维修中 3-已满',
    has_bathroom TINYINT DEFAULT 0 COMMENT '是否有独立卫生间：0-否 1-是',
    has_aircon TINYINT DEFAULT 0 COMMENT '是否有空调：0-否 1-是',
    has_water_heater TINYINT DEFAULT 0 COMMENT '是否有热水器：0-否 1-是',
    price DECIMAL(10,2) COMMENT '每学年费用',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志',
    UNIQUE KEY uk_building_room (building_id, room_number),
    INDEX idx_building_id (building_id),
    INDEX idx_floor (floor),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宿舍房间表';

-- =============================================
-- 4. 床位表
-- =============================================
DROP TABLE IF EXISTS dorm_bed;
CREATE TABLE dorm_bed (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '床位ID',
    room_id BIGINT NOT NULL COMMENT '所属房间ID',
    bed_number INT NOT NULL COMMENT '床位号',
    position VARCHAR(20) COMMENT '床位位置描述',
    status TINYINT DEFAULT 0 COMMENT '状态：0-空闲 1-已分配 2-维修中',
    student_id BIGINT COMMENT '入住学生ID',
    check_in_time DATETIME COMMENT '入住时间',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志',
    INDEX idx_room_id (room_id),
    INDEX idx_student_id (student_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='床位表';

-- =============================================
-- 5. 入住记录表
-- =============================================
DROP TABLE IF EXISTS dorm_check_in;
CREATE TABLE dorm_check_in (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '记录ID',
    student_id BIGINT NOT NULL COMMENT '学生ID',
    room_id BIGINT NOT NULL COMMENT '房间ID',
    bed_id BIGINT NOT NULL COMMENT '床位ID',
    building_id BIGINT NOT NULL COMMENT '楼栋ID',
    academic_year VARCHAR(20) COMMENT '学年',
    check_in_time DATETIME COMMENT '入住时间',
    check_out_time DATETIME COMMENT '退宿时间',
    status TINYINT DEFAULT 1 COMMENT '状态：0-已退宿 1-在住',
    check_in_type TINYINT DEFAULT 1 COMMENT '入住类型：1-正常入住 2-调宿 3-临时入住',
    remark VARCHAR(500) COMMENT '备注',
    operator_id BIGINT COMMENT '操作人ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_student_id (student_id),
    INDEX idx_room_id (room_id),
    INDEX idx_building_id (building_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='入住记录表';

-- =============================================
-- 6. 门禁通行记录表
-- =============================================
DROP TABLE IF EXISTS dorm_access_record;
CREATE TABLE dorm_access_record (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '记录ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    building_id BIGINT NOT NULL COMMENT '楼栋ID',
    direction TINYINT NOT NULL COMMENT '通行方向：1-进入 2-离开',
    verify_type TINYINT DEFAULT 1 COMMENT '验证方式：1-人脸识别 2-刷卡 3-密码 4-手机',
    verify_result TINYINT DEFAULT 1 COMMENT '验证结果：0-失败 1-成功',
    fail_reason VARCHAR(200) COMMENT '失败原因',
    temperature DECIMAL(4,1) COMMENT '体温',
    capture_image VARCHAR(255) COMMENT '抓拍图片',
    device_code VARCHAR(50) COMMENT '设备编号',
    pass_time DATETIME NOT NULL COMMENT '通行时间',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user_id (user_id),
    INDEX idx_building_id (building_id),
    INDEX idx_pass_time (pass_time),
    INDEX idx_verify_result (verify_result)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='门禁通行记录表';

-- =============================================
-- 7. 能耗记录表
-- =============================================
DROP TABLE IF EXISTS dorm_energy_record;
CREATE TABLE dorm_energy_record (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '记录ID',
    room_id BIGINT NOT NULL COMMENT '房间ID',
    building_id BIGINT NOT NULL COMMENT '楼栋ID',
    energy_type TINYINT NOT NULL COMMENT '能耗类型：1-用电 2-用水',
    meter_reading DECIMAL(12,2) COMMENT '读数',
    consumption DECIMAL(10,2) COMMENT '用量',
    cost DECIMAL(10,2) COMMENT '费用',
    record_date DATE NOT NULL COMMENT '记录日期',
    record_time DATETIME COMMENT '记录时间',
    device_code VARCHAR(50) COMMENT '设备编号',
    is_abnormal TINYINT DEFAULT 0 COMMENT '是否异常：0-正常 1-异常',
    abnormal_reason VARCHAR(200) COMMENT '异常原因',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_room_id (room_id),
    INDEX idx_building_id (building_id),
    INDEX idx_record_date (record_date),
    INDEX idx_energy_type (energy_type),
    INDEX idx_is_abnormal (is_abnormal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='能耗记录表';

-- =============================================
-- 8. 报修工单表
-- =============================================
DROP TABLE IF EXISTS dorm_repair;
CREATE TABLE dorm_repair (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '工单ID',
    order_no VARCHAR(50) NOT NULL UNIQUE COMMENT '工单编号',
    user_id BIGINT NOT NULL COMMENT '报修人ID',
    room_id BIGINT COMMENT '房间ID',
    building_id BIGINT COMMENT '楼栋ID',
    repair_type TINYINT NOT NULL COMMENT '报修类型：1-水电维修 2-家具维修 3-门窗维修 4-网络故障 5-其他',
    title VARCHAR(100) NOT NULL COMMENT '报修标题',
    description TEXT COMMENT '问题描述',
    images VARCHAR(1000) COMMENT '报修图片',
    priority TINYINT DEFAULT 2 COMMENT '优先级：1-低 2-中 3-高 4-紧急',
    status TINYINT DEFAULT 0 COMMENT '状态：0-待处理 1-已派单 2-维修中 3-已完成 4-已评价 5-已取消',
    repairer_id BIGINT COMMENT '维修人员ID',
    repairer_name VARCHAR(50) COMMENT '维修人员姓名',
    appointment_time DATETIME COMMENT '预约维修时间',
    start_time DATETIME COMMENT '开始维修时间',
    complete_time DATETIME COMMENT '完成时间',
    result TEXT COMMENT '维修结果描述',
    cost DECIMAL(10,2) COMMENT '维修费用',
    rating TINYINT COMMENT '评价评分：1-5星',
    comment TEXT COMMENT '评价内容',
    remark TEXT COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_order_no (order_no),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_repair_type (repair_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报修工单表';

-- =============================================
-- 9. 卫生检查表
-- =============================================
DROP TABLE IF EXISTS dorm_hygiene_check;
CREATE TABLE dorm_hygiene_check (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '检查ID',
    room_id BIGINT NOT NULL COMMENT '房间ID',
    building_id BIGINT NOT NULL COMMENT '楼栋ID',
    check_date DATE NOT NULL COMMENT '检查日期',
    check_type TINYINT DEFAULT 1 COMMENT '检查类型：1-日常检查 2-专项检查 3-突击检查',
    score INT COMMENT '整体评分：0-100分',
    grade CHAR(1) COMMENT '等级：A-优秀 B-良好 C-合格 D-不合格',
    floor_score INT COMMENT '地面清洁评分',
    desk_score INT COMMENT '桌面整洁评分',
    bed_score INT COMMENT '床铺整洁评分',
    bathroom_score INT COMMENT '卫生间评分',
    balcony_score INT COMMENT '阳台评分',
    has_contraband TINYINT DEFAULT 0 COMMENT '是否有违禁品：0-否 1-是',
    contraband_detail VARCHAR(500) COMMENT '违禁品说明',
    images VARCHAR(1000) COMMENT '检查图片',
    checker_id BIGINT COMMENT '检查人ID',
    checker_name VARCHAR(50) COMMENT '检查人姓名',
    rectification TEXT COMMENT '整改要求',
    rectification_deadline DATE COMMENT '整改期限',
    rectification_status TINYINT DEFAULT 0 COMMENT '整改状态：0-无需整改 1-待整改 2-已整改 3-已验收',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_room_id (room_id),
    INDEX idx_building_id (building_id),
    INDEX idx_check_date (check_date),
    INDEX idx_grade (grade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='卫生检查表';

-- =============================================
-- 10. 通知公告表
-- =============================================
DROP TABLE IF EXISTS dorm_notice;
CREATE TABLE dorm_notice (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '通知ID',
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content TEXT NOT NULL COMMENT '内容',
    type TINYINT DEFAULT 1 COMMENT '通知类型：1-系统通知 2-楼栋通知 3-宿舍通知 4-活动通知',
    priority TINYINT DEFAULT 1 COMMENT '优先级：1-普通 2-重要 3-紧急',
    target_range TINYINT DEFAULT 0 COMMENT '目标范围：0-全部 1-指定楼栋 2-指定房间',
    target_buildings VARCHAR(500) COMMENT '目标楼栋ID',
    target_rooms VARCHAR(500) COMMENT '目标房间ID',
    is_top TINYINT DEFAULT 0 COMMENT '是否置顶：0-否 1-是',
    attachment VARCHAR(255) COMMENT '附件地址',
    publisher_id BIGINT COMMENT '发布人ID',
    publisher_name VARCHAR(50) COMMENT '发布人姓名',
    status TINYINT DEFAULT 1 COMMENT '状态：0-草稿 1-已发布 2-已撤回',
    publish_time DATETIME COMMENT '发布时间',
    read_count INT DEFAULT 0 COMMENT '阅读人数',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志',
    INDEX idx_type (type),
    INDEX idx_status (status),
    INDEX idx_publish_time (publish_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知公告表';

-- =============================================
-- 11. 社区帖子表
-- =============================================
DROP TABLE IF EXISTS dorm_post;
CREATE TABLE dorm_post (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '帖子ID',
    user_id BIGINT NOT NULL COMMENT '发帖人ID',
    user_name VARCHAR(50) COMMENT '发帖人姓名',
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content TEXT NOT NULL COMMENT '内容',
    images VARCHAR(1000) COMMENT '图片',
    type TINYINT DEFAULT 1 COMMENT '帖子类型：1-失物招领 2-二手交易 3-拼车出行 4-学习交流 5-生活求助 6-其他',
    building_id BIGINT COMMENT '楼栋ID',
    view_count INT DEFAULT 0 COMMENT '浏览数',
    like_count INT DEFAULT 0 COMMENT '点赞数',
    comment_count INT DEFAULT 0 COMMENT '评论数',
    is_top TINYINT DEFAULT 0 COMMENT '是否置顶：0-否 1-是',
    status TINYINT DEFAULT 1 COMMENT '状态：0-隐藏 1-正常 2-置顶',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志',
    INDEX idx_user_id (user_id),
    INDEX idx_type (type),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社区帖子表';

-- =============================================
-- 12. 评论表
-- =============================================
DROP TABLE IF EXISTS dorm_comment;
CREATE TABLE dorm_comment (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '评论ID',
    post_id BIGINT NOT NULL COMMENT '帖子ID',
    user_id BIGINT NOT NULL COMMENT '评论人ID',
    user_name VARCHAR(50) COMMENT '评论人姓名',
    content TEXT NOT NULL COMMENT '评论内容',
    parent_id BIGINT COMMENT '父评论ID',
    reply_user_id BIGINT COMMENT '回复用户ID',
    reply_user_name VARCHAR(50) COMMENT '回复用户姓名',
    like_count INT DEFAULT 0 COMMENT '点赞数',
    status TINYINT DEFAULT 1 COMMENT '状态：0-隐藏 1-正常',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标志',
    INDEX idx_post_id (post_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评论表';

-- =============================================
-- 13. 操作日志表
-- =============================================
DROP TABLE IF EXISTS sys_oper_log;
CREATE TABLE sys_oper_log (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '日志ID',
    module VARCHAR(50) COMMENT '模块名称',
    oper_type TINYINT COMMENT '操作类型：1-新增 2-修改 3-删除 4-查询 5-导出 6-导入',
    description VARCHAR(200) COMMENT '操作描述',
    method VARCHAR(200) COMMENT '请求方法',
    url VARCHAR(200) COMMENT '请求URL',
    request_method VARCHAR(10) COMMENT '请求方式',
    request_param TEXT COMMENT '请求参数',
    result TEXT COMMENT '返回结果',
    status TINYINT DEFAULT 1 COMMENT '操作状态：0-失败 1-成功',
    error_msg TEXT COMMENT '错误信息',
    oper_user_id BIGINT COMMENT '操作人ID',
    oper_user_name VARCHAR(50) COMMENT '操作人姓名',
    oper_ip VARCHAR(50) COMMENT '操作IP',
    oper_location VARCHAR(100) COMMENT '操作地点',
    cost_time BIGINT COMMENT '操作耗时（毫秒）',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_module (module),
    INDEX idx_oper_type (oper_type),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';

-- =============================================
-- 初始化数据
-- =============================================

-- 插入管理员账号（密码：123456，BCrypt加密）
INSERT INTO sys_user (username, password, real_name, gender, phone, role, user_code, college, class_name, status) VALUES
('admin', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '系统管理员', 1, '13800000001', 'ADMIN', 'ADMIN001', NULL, NULL, 1),
('dorm_admin1', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '张宿管', 0, '13800000002', 'DORM_ADMIN', 'DA001', NULL, NULL, 1),
('dorm_admin2', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '李宿管', 0, '13800000003', 'DORM_ADMIN', 'DA002', NULL, NULL, 1),
('counselor1', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '陈辅导员', 0, '13800000009', 'COUNSELOR', 'CS001', '计算机科学与技术学院', NULL, 1),
('counselor2', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '周辅导员', 1, '13800000010', 'COUNSELOR', 'CS002', '电子信息工程学院', NULL, 1),
('student001', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '王小明', 1, '13800000004', 'STUDENT', '2023001001', '计算机科学与技术学院', '计科2301班', 1),
('student002', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '李小红', 0, '13800000005', 'STUDENT', '2023001002', '计算机科学与技术学院', '计科2301班', 1),
('student003', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '张小刚', 1, '13800000006', 'STUDENT', '2023001003', '计算机科学与技术学院', '计科2302班', 1),
('student004', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '赵小丽', 0, '13800000007', 'STUDENT', '2023001004', '电子信息工程学院', '电信2301班', 1),
('student005', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '刘小伟', 1, '13800000008', 'STUDENT', '2023001005', '电子信息工程学院', '电信2301班', 1);

-- 插入宿舍楼数据
INSERT INTO dorm_building (name, code, floor_count, room_count, type, address, admin_id, contact_phone, status) VALUES
('1号楼', 'B001', 6, 120, 1, '校区东侧', 2, '0571-88888001', 1),
('2号楼', 'B002', 6, 120, 1, '校区东侧', 2, '0571-88888002', 1),
('3号楼', 'B003', 6, 120, 2, '校区西侧', 3, '0571-88888003', 1),
('4号楼', 'B004', 6, 120, 2, '校区西侧', 3, '0571-88888004', 1),
('5号楼', 'B005', 6, 120, 1, '校区南侧', 2, '0571-88888005', 1);

-- 插入房间数据（1号楼1层示例）
INSERT INTO dorm_room (building_id, room_number, floor, room_type, bed_count, area, has_bathroom, has_aircon, has_water_heater, price, status) VALUES
(1, '101', 1, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '102', 1, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '103', 1, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '104', 1, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '105', 1, 2, 6, 35.00, 1, 1, 1, 1000.00, 1),
(1, '106', 1, 2, 6, 35.00, 1, 1, 1, 1000.00, 1),
(1, '201', 2, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '202', 2, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '203', 2, 1, 4, 25.00, 1, 1, 1, 1200.00, 1),
(1, '204', 2, 1, 4, 25.00, 1, 1, 1, 1200.00, 1);

-- 插入床位数据（101房间示例）
INSERT INTO dorm_bed (room_id, bed_number, position, status) VALUES
(1, 1, '上铺', 1),
(1, 2, '下铺', 1),
(1, 3, '上铺', 0),
(1, 4, '下铺', 0);

-- 插入住户记录
INSERT INTO dorm_check_in (student_id, room_id, bed_id, building_id, academic_year, check_in_time, status, check_in_type) VALUES
(4, 1, 1, 1, '2023-2024', '2023-09-01 10:00:00', 1, 1),
(5, 1, 2, 1, '2023-2024', '2023-09-01 10:30:00', 1, 1);

-- 插入通知公告
INSERT INTO dorm_notice (title, content, type, priority, target_range, publisher_id, publisher_name, status, publish_time, read_count) VALUES
('欢迎入住智能宿舍', '欢迎各位同学入住智能宿舍管理系统管理的宿舍楼，本系统提供智能化的宿舍管理服务，包括门禁管理、能耗监测、在线报修等功能。', 1, 1, 0, 1, '系统管理员', 1, NOW(), 156),
('2024年春季学期宿舍安全检查通知', '为确保宿舍安全，学校将于3月15日-3月20日进行宿舍安全大检查，请各位同学提前做好准备。', 1, 2, 0, 1, '系统管理员', 1, NOW(), 89),
('1号楼停水通知', '因水管维修，1号楼将于3月10日8:00-18:00停水，请各位同学提前做好储水准备。', 2, 3, 1, 2, '张宿管', 1, NOW(), 234),
('宿舍文化节活动报名', '一年一度的宿舍文化节即将开始，欢迎各宿舍报名参加宿舍装饰大赛、才艺展示等活动。', 4, 1, 0, 1, '系统管理员', 1, NOW(), 67);

-- 插入能耗数据示例
INSERT INTO dorm_energy_record (room_id, building_id, energy_type, meter_reading, consumption, cost, record_date, record_time, is_abnormal) VALUES
(1, 1, 1, 1000.00, 15.50, 8.53, '2024-03-01', '2024-03-01 23:59:59', 0),
(1, 1, 1, 1015.50, 12.30, 6.77, '2024-03-02', '2024-03-02 23:59:59', 0),
(1, 1, 1, 1027.80, 18.70, 10.29, '2024-03-03', '2024-03-03 23:59:59', 0),
(1, 1, 2, 500.00, 3.20, 9.60, '2024-03-01', '2024-03-01 23:59:59', 0),
(1, 1, 2, 503.20, 2.80, 8.40, '2024-03-02', '2024-03-02 23:59:59', 0),
(1, 1, 2, 506.00, 4.50, 13.50, '2024-03-03', '2024-03-03 23:59:59', 1);

-- 插入报修工单示例
INSERT INTO dorm_repair (order_no, user_id, room_id, building_id, repair_type, title, description, contact_phone, priority, status, create_time) VALUES
('RX20240301001', 4, 1, 1, 1, '水龙头漏水', '卫生间水龙头一直滴水，请尽快维修', '13800000004', 3, 0, NOW()),
('RX20240301002', 5, 1, 1, 2, '桌子腿松了', '书桌的一条腿松动了，需要修理', '13800000005', 2, 1, NOW()),
('RX20240301003', 4, 1, 1, 4, '网络连接不上', '从昨天开始就无法连接宿舍WiFi', '13800000004', 3, 2, NOW());

-- 插入卫生检查记录
INSERT INTO dorm_hygiene_check (room_id, building_id, check_date, check_type, score, grade, floor_score, desk_score, bed_score, bathroom_score, balcony_score, has_contraband, checker_id, checker_name, remark) VALUES
(1, 1, '2024-03-01', 1, 92, 'A', 18, 19, 18, 19, 18, 0, 2, '张宿管', '卫生情况优秀，继续保持'),
(2, 1, '2024-03-01', 1, 85, 'B', 17, 17, 17, 17, 17, 0, 2, '张宿管', '整体良好，桌面需要整理'),
(3, 1, '2024-03-01', 1, 78, 'C', 16, 15, 16, 16, 15, 1, 2, '张宿管', '发现违规电器，请整改');

-- 插入门禁记录
INSERT INTO dorm_access_record (user_id, building_id, direction, verify_type, verify_result, temperature, pass_time) VALUES
(4, 1, 1, 1, 1, 36.5, '2024-03-01 08:00:00'),
(4, 1, 2, 1, 1, 36.3, '2024-03-01 12:00:00'),
(4, 1, 1, 1, 1, 36.4, '2024-03-01 14:00:00'),
(4, 1, 2, 1, 1, 36.6, '2024-03-01 18:00:00'),
(5, 1, 1, 1, 1, 36.2, '2024-03-01 09:00:00'),
(5, 1, 2, 1, 1, 36.5, '2024-03-01 17:00:00');

-- =============================================
-- 创建视图
-- =============================================

-- 房间使用情况视图
CREATE OR REPLACE VIEW v_room_usage AS
SELECT
    r.id AS room_id,
    r.room_number,
    r.floor,
    r.bed_count,
    r.occupied_count,
    r.status,
    b.name AS building_name,
    b.code AS building_code,
    ROUND(r.occupied_count / r.bed_count * 100, 2) AS usage_rate
FROM dorm_room r
LEFT JOIN dorm_building b ON r.building_id = b.id
WHERE r.deleted = 0;

-- 学生住宿信息视图
CREATE OR REPLACE VIEW v_student_accommodation AS
SELECT
    u.id AS student_id,
    u.real_name AS student_name,
    u.user_code AS student_code,
    u.college,
    u.class_name,
    ci.room_id,
    r.room_number,
    ci.bed_id,
    bed.bed_number,
    ci.building_id,
    b.name AS building_name,
    ci.academic_year,
    ci.check_in_time
FROM sys_user u
INNER JOIN dorm_check_in ci ON u.id = ci.student_id AND ci.status = 1
LEFT JOIN dorm_room r ON ci.room_id = r.id
LEFT JOIN dorm_bed bed ON ci.bed_id = bed.id
LEFT JOIN dorm_building b ON ci.building_id = b.id
WHERE u.role = 'STUDENT' AND u.deleted = 0;

-- 报修统计视图
CREATE OR REPLACE VIEW v_repair_statistics AS
SELECT
    DATE(create_time) AS repair_date,
    repair_type,
    COUNT(*) AS total_count,
    SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) AS pending_count,
    SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS assigned_count,
    SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END) AS processing_count,
    SUM(CASE WHEN status = 3 THEN 1 ELSE 0 END) AS completed_count,
    SUM(CASE WHEN status = 4 THEN 1 ELSE 0 END) AS evaluated_count
FROM dorm_repair
GROUP BY DATE(create_time), repair_type;

-- =============================================
-- 创建存储过程
-- =============================================

-- 自动分配床位存储过程
DELIMITER //
CREATE PROCEDURE sp_auto_assign_bed(
    IN p_student_id BIGINT,
    IN p_building_id BIGINT,
    IN p_room_type TINYINT,
    OUT p_room_id BIGINT,
    OUT p_bed_id BIGINT,
    OUT p_result VARCHAR(100)
)
BEGIN
    DECLARE v_room_id BIGINT;
    DECLARE v_bed_id BIGINT;

    -- 查找有空床位的房间
    SELECT r.id INTO v_room_id
    FROM dorm_room r
    WHERE r.building_id = p_building_id
      AND r.room_type = p_room_type
      AND r.status IN (0, 1)
      AND r.occupied_count < r.bed_count
    ORDER BY r.occupied_count DESC
    LIMIT 1;

    IF v_room_id IS NULL THEN
        SET p_result = '没有可用的房间';
        SET p_room_id = NULL;
        SET p_bed_id = NULL;
    ELSE
        -- 查找空床位
        SELECT id INTO v_bed_id
        FROM dorm_bed
        WHERE room_id = v_room_id
          AND status = 0
        ORDER BY bed_number
        LIMIT 1;

        IF v_bed_id IS NULL THEN
            SET p_result = '房间没有可用床位';
            SET p_room_id = NULL;
            SET p_bed_id = NULL;
        ELSE
            SET p_room_id = v_room_id;
            SET p_bed_id = v_bed_id;
            SET p_result = '分配成功';
        END IF;
    END IF;
END //
DELIMITER ;

-- =============================================
-- 创建触发器
-- =============================================

-- 入住时更新房间和楼栋入住人数
DELIMITER //
CREATE TRIGGER trg_check_in_after_insert
AFTER INSERT ON dorm_check_in
FOR EACH ROW
BEGIN
    IF NEW.status = 1 THEN
        -- 更新房间入住人数
        UPDATE dorm_room
        SET occupied_count = occupied_count + 1,
            status = CASE
                WHEN occupied_count + 1 >= bed_count THEN 3
                ELSE status
            END
        WHERE id = NEW.room_id;

        -- 更新楼栋入住人数
        UPDATE dorm_building
        SET occupied_count = occupied_count + 1
        WHERE id = NEW.building_id;

        -- 更新床位状态
        UPDATE dorm_bed
        SET status = 1,
            student_id = NEW.student_id,
            check_in_time = NEW.check_in_time
        WHERE id = NEW.bed_id;
    END IF;
END //
DELIMITER ;

-- 退宿时更新房间和楼栋入住人数
DELIMITER //
CREATE TRIGGER trg_check_in_after_update
AFTER UPDATE ON dorm_check_in
FOR EACH ROW
BEGIN
    IF OLD.status = 1 AND NEW.status = 0 THEN
        -- 更新房间入住人数
        UPDATE dorm_room
        SET occupied_count = occupied_count - 1,
            status = CASE
                WHEN status = 3 THEN 1
                ELSE status
            END
        WHERE id = OLD.room_id;

        -- 更新楼栋入住人数
        UPDATE dorm_building
        SET occupied_count = occupied_count - 1
        WHERE id = OLD.building_id;

        -- 更新床位状态
        UPDATE dorm_bed
        SET status = 0,
            student_id = NULL,
            check_in_time = NULL
        WHERE id = OLD.bed_id;
    END IF;
END //
DELIMITER ;

-- =============================================
-- 完成
-- =============================================
SELECT '数据库初始化完成！' AS message;



