-- =============================================
-- 修复入住记录中的 bed_id 数据
-- 将 bed_id 从床位号转换为 dorm_bed 表的主键 ID
-- =============================================

USE sushe_system;

-- 查看当前数据情况
SELECT
    ci.id AS check_in_id,
    ci.student_id,
    u.real_name,
    ci.room_id,
    r.room_number,
    ci.bed_id AS current_bed_id,
    bd.id AS correct_bed_id,
    bd.bed_number
FROM dorm_check_in ci
JOIN sys_user u ON ci.student_id = u.id
JOIN dorm_room r ON ci.room_id = r.id
LEFT JOIN dorm_bed bd ON ci.room_id = bd.room_id AND ci.bed_id = bd.bed_number
WHERE ci.status = 1;

-- 修复 bed_id：将床位号转换为 dorm_bed 表的主键 ID
UPDATE dorm_check_in ci
INNER JOIN dorm_bed bd ON ci.room_id = bd.room_id AND ci.bed_id = bd.bed_number
SET ci.bed_id = bd.id
WHERE ci.status = 1;

-- 验证修复结果
SELECT
    ci.id AS check_in_id,
    u.real_name,
    r.room_number,
    ci.bed_id,
    bd.bed_number
FROM dorm_check_in ci
JOIN sys_user u ON ci.student_id = u.id
JOIN dorm_room r ON ci.room_id = r.id
LEFT JOIN dorm_bed bd ON ci.bed_id = bd.id
WHERE ci.status = 1;

SELECT '入住记录 bed_id 修复完成！' AS message;
