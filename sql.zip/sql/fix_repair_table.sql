-- =============================================
-- 修复 dorm_repair 表：添加缺失的列以匹配 Java 实体 Repair.java
-- 请在已有的数据库上执行此脚本
-- =============================================

-- 添加预约维修时间列（对应实体字段 appointmentTime）
ALTER TABLE dorm_repair ADD COLUMN appointment_time DATETIME COMMENT '预约维修时间' AFTER repairer_name;

-- 添加开始维修时间列（对应实体字段 startTime）
ALTER TABLE dorm_repair ADD COLUMN start_time DATETIME COMMENT '开始维修时间' AFTER appointment_time;

-- 添加维修结果描述列（对应实体字段 result）
ALTER TABLE dorm_repair ADD COLUMN result TEXT COMMENT '维修结果描述' AFTER complete_time;

-- 添加评价内容列（对应实体字段 comment）
ALTER TABLE dorm_repair ADD COLUMN comment TEXT COMMENT '评价内容' AFTER rating;

-- 添加备注列（对应实体字段 remark）
ALTER TABLE dorm_repair ADD COLUMN remark TEXT COMMENT '备注' AFTER comment;
