-- =============================================
-- 插入学生示例数据
-- Smart Dormitory Management System
-- =============================================

USE sushe_system;

-- 插入学生用户数据（密码均为：123456，BCrypt加密）
INSERT INTO sys_user (username, password, real_name, gender, phone, email, role, user_code, college, class_name, id_card, status) VALUES
-- 计算机学院学生
('student006', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '陈小明', 1, '13900000001', 'chenxm@example.com', 'STUDENT', '2023001006', '计算机科学与技术学院', '计科2301班', '330102200301011234', 1),
('student007', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '王小花', 0, '13900000002', 'wangxh@example.com', 'STUDENT', '2023001007', '计算机科学与技术学院', '计科2301班', '330102200301021234', 1),
('student008', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '李小龙', 1, '13900000003', 'lixl@example.com', 'STUDENT', '2023001008', '计算机科学与技术学院', '计科2302班', '330102200301031234', 1),
('student009', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '赵小雪', 0, '13900000004', 'zhaoxx@example.com', 'STUDENT', '2023001009', '计算机科学与技术学院', '计科2302班', '330102200301041234', 1),

-- 电子信息学院学生
('student010', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '孙小伟', 1, '13900000005', 'sunxw@example.com', 'STUDENT', '2023002001', '电子信息工程学院', '电信2301班', '330102200301051234', 1),
('student011', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '周小红', 0, '13900000006', 'zhouxh@example.com', 'STUDENT', '2023002002', '电子信息工程学院', '电信2301班', '330102200301061234', 1),
('student012', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '吴小刚', 1, '13900000007', 'wuxg@example.com', 'STUDENT', '2023002003', '电子信息工程学院', '电信2302班', '330102200301071234', 1),
('student013', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '郑小美', 0, '13900000008', 'zhengxm@example.com', 'STUDENT', '2023002004', '电子信息工程学院', '电信2302班', '330102200301081234', 1),

-- 外语学院学生
('student014', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '冯小强', 1, '13900000009', 'fengxq@example.com', 'STUDENT', '2023003001', '外国语学院', '英语2301班', '330102200301091234', 1),
('student015', '$2b$10$ooC9Fpc8WdlVjHbDtH34qeIbbhcZhTfk86TGygtJKiV0MZKpWDTLO', '杨小丽', 0, '13900000010', 'yangxl@example.com', 'STUDENT', '2023003002', '外国语学院', '英语2301班', '330102200301101234', 1);

-- 插入住户记录（为新学生分配宿舍）
-- 学生student006-009 分配到 1号楼 102房间
INSERT INTO dorm_check_in (student_id, room_id, bed_id, building_id, academic_year, check_in_time, status, check_in_type) VALUES
(11, 2, 5, 1, '2023-2024', '2023-09-01 11:00:00', 1, 1),  -- 陈小明 102-1号床
(12, 2, 6, 1, '2023-2024', '2023-09-01 11:30:00', 1, 1),  -- 王小花 102-2号床
(13, 2, 7, 1, '2023-2024', '2023-09-01 12:00:00', 1, 1),  -- 李小龙 102-3号床
(14, 2, 8, 1, '2023-2024', '2023-09-01 12:30:00', 1, 1);  -- 赵小雪 102-4号床

-- 更新102房间的床位状态
UPDATE dorm_bed SET status = 1, student_id = 11, check_in_time = '2023-09-01 11:00:00' WHERE room_id = 2 AND bed_number = 1;
UPDATE dorm_bed SET status = 1, student_id = 12, check_in_time = '2023-09-01 11:30:00' WHERE room_id = 2 AND bed_number = 2;
UPDATE dorm_bed SET status = 1, student_id = 13, check_in_time = '2023-09-01 12:00:00' WHERE room_id = 2 AND bed_number = 3;
UPDATE dorm_bed SET status = 1, student_id = 14, check_in_time = '2023-09-01 12:30:00' WHERE room_id = 2 AND bed_number = 4;

-- 学生student010-011 分配到 1号楼 103房间（部分入住）
INSERT INTO dorm_check_in (student_id, room_id, bed_id, building_id, academic_year, check_in_time, status, check_in_type) VALUES
(15, 3, 9, 1, '2023-2024', '2023-09-01 14:00:00', 1, 1),  -- 孙小伟 103-1号床
(16, 3, 10, 1, '2023-2024', '2023-09-01 14:30:00', 1, 1); -- 周小红 103-2号床

-- 更新103房间的床位状态
UPDATE dorm_bed SET status = 1, student_id = 15, check_in_time = '2023-09-01 14:00:00' WHERE room_id = 3 AND bed_number = 1;
UPDATE dorm_bed SET status = 1, student_id = 16, check_in_time = '2023-09-01 14:30:00' WHERE room_id = 3 AND bed_number = 2;

-- 插入104房间的床位数据并分配学生
INSERT INTO dorm_bed (room_id, bed_number, position, status, student_id, check_in_time) VALUES
(4, 1, '上铺', 1, 17, '2023-09-01 15:00:00'),
(4, 2, '下铺', 1, 18, '2023-09-01 15:30:00'),
(4, 3, '上铺', 0, NULL, NULL),
(4, 4, '下铺', 0, NULL, NULL);

INSERT INTO dorm_check_in (student_id, room_id, bed_id, building_id, academic_year, check_in_time, status, check_in_type) VALUES
(17, 4, 13, 1, '2023-2024', '2023-09-01 15:00:00', 1, 1),  -- 吴小刚 104-1号床
(18, 4, 14, 1, '2023-2024', '2023-09-01 15:30:00', 1, 1);  -- 郑小美 104-2号床

-- 插入105房间的床位数据并分配学生
INSERT INTO dorm_bed (room_id, bed_number, position, status, student_id, check_in_time) VALUES
(5, 1, '上铺', 1, 19, '2023-09-01 16:00:00'),
(5, 2, '下铺', 1, 20, '2023-09-01 16:30:00'),
(5, 3, '上铺', 0, NULL, NULL),
(5, 4, '下铺', 0, NULL, NULL),
(5, 5, '上铺', 0, NULL, NULL),
(5, 6, '下铺', 0, NULL, NULL);

INSERT INTO dorm_check_in (student_id, room_id, bed_id, building_id, academic_year, check_in_time, status, check_in_type) VALUES
(19, 5, 15, 1, '2023-2024', '2023-09-01 16:00:00', 1, 1),  -- 冯小强 105-1号床
(20, 5, 16, 1, '2023-2024', '2023-09-01 16:30:00', 1, 1);  -- 杨小丽 105-2号床

-- 更新房间入住人数
UPDATE dorm_room SET occupied_count = 4 WHERE id IN (2);      -- 102房间已住4人
UPDATE dorm_room SET occupied_count = 2 WHERE id IN (3);      -- 103房间已住2人
UPDATE dorm_room SET occupied_count = 2 WHERE id IN (4, 5);   -- 104、105房间各住2人

-- 更新楼栋入住人数
UPDATE dorm_building SET occupied_count = 14 WHERE id = 1;    -- 1号楼共14人入住

SELECT '学生示例数据插入完成！' AS message;
SELECT COUNT(*) AS '学生总数' FROM sys_user WHERE role = 'STUDENT' AND deleted = 0;
SELECT COUNT(*) AS '在住学生数' FROM dorm_check_in WHERE status = 1;
