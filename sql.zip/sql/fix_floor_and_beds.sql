-- =============================================
-- 修复楼层和床位数据
-- 执行时间：2026-06-23
-- =============================================

USE sushe_system;

-- 1. 修复楼层为空的房间，根据房间号自动设置楼层
UPDATE dorm_room
SET floor = CASE
    WHEN LENGTH(REPLACE(room_number, REGEXP_REPLACE(room_number, '[0-9]', ''), '')) >= 3
    THEN CAST(SUBSTRING(REPLACE(room_number, REGEXP_REPLACE(room_number, '[0-9]', ''), ''), 1, 1) AS UNSIGNED)
    WHEN LENGTH(REPLACE(room_number, REGEXP_REPLACE(room_number, '[0-9]', ''), '')) = 2
    THEN CAST(SUBSTRING(REPLACE(room_number, REGEXP_REPLACE(room_number, '[0-9]', ''), ''), 1, 1) AS UNSIGNED)
    ELSE 1
END
WHERE floor IS NULL OR floor = 0;

-- 2. 为没有床位的房间自动创建床位
-- 先找出没有床位的房间
INSERT INTO dorm_bed (room_id, bed_number, position, status, deleted, create_time, update_time)
SELECT r.id, seq.bed_num,
    CASE WHEN seq.bed_num <= r.bed_count / 2 THEN '上铺' ELSE '下铺' END,
    0, 0, NOW(), NOW()
FROM dorm_room r
JOIN (
    SELECT 1 AS bed_num UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
    UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8
) seq ON seq.bed_num <= r.bed_count
LEFT JOIN dorm_bed b ON b.room_id = r.id
WHERE b.id IS NULL
AND r.deleted = 0;

-- 验证修复结果
SELECT r.id, r.room_number, r.floor, r.bed_count,
    (SELECT COUNT(*) FROM dorm_bed WHERE room_id = r.id) AS bed_count_actual
FROM dorm_room r
WHERE r.deleted = 0
ORDER BY r.room_number;
