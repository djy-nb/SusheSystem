package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.CheckIn;
import com.sushe.system.service.CheckInService;
import com.sushe.system.vo.CheckInVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 入住管理控制器
 */
@Tag(name = "入住管理", description = "学生入住、退宿、调宿管理接口")
@RestController
@RequestMapping("/checkin")
@RequiredArgsConstructor
public class CheckInController {

    private final CheckInService checkInService;

    @Operation(summary = "分页查询入住记录")
    @GetMapping("/page")
    public Result<Page<CheckInVO>> getCheckInPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Integer status) {
        Page<CheckInVO> page = checkInService.getCheckInPage(pageNum, pageSize, buildingId, roomId, status);
        return Result.success(page);
    }

    @Operation(summary = "学生入住")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> checkIn(@RequestBody CheckIn checkIn) {
        checkInService.checkIn(checkIn);
        return Result.success();
    }

    @Operation(summary = "学生退宿")
    @PutMapping("/{id}/checkout")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> checkOut(@PathVariable Long id) {
        checkInService.checkOut(id);
        return Result.success();
    }

    @Operation(summary = "调宿")
    @PutMapping("/{id}/change-room")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> changeRoom(@PathVariable Long id,
                                    @RequestParam Long newRoomId,
                                    @RequestParam Long newBedId) {
        checkInService.changeRoom(id, newRoomId, newBedId);
        return Result.success();
    }
}
