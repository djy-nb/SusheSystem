package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.HygieneCheck;
import com.sushe.system.service.HygieneService;
import com.sushe.system.vo.HygieneCheckVO;
import com.sushe.system.vo.HygieneStatisticsVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 卫生检查控制器
 */
@Tag(name = "卫生检查", description = "卫生检查管理接口")
@RestController
@RequestMapping("/hygiene")
@RequiredArgsConstructor
public class HygieneController {

    private final HygieneService hygieneService;

    @Operation(summary = "分页查询卫生检查记录")
    @GetMapping("/page")
    public Result<Page<HygieneCheckVO>> getHygienePage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Integer checkType,
            @RequestParam(required = false) String grade,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        Page<HygieneCheckVO> page = hygieneService.getHygienePage(pageNum, pageSize, buildingId, roomId, checkType, grade, startDate, endDate);
        return Result.success(page);
    }

    @Operation(summary = "获取卫生检查详情")
    @GetMapping("/{id}")
    public Result<HygieneCheckVO> getHygieneDetail(@PathVariable Long id) {
        HygieneCheckVO hygieneCheckVO = hygieneService.getHygieneDetail(id);
        return Result.success(hygieneCheckVO);
    }

    @Operation(summary = "提交卫生检查")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> submitCheck(@RequestBody HygieneCheck check) {
        hygieneService.submitCheck(check);
        return Result.success();
    }

    @Operation(summary = "更新卫生检查")
    @PutMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> updateCheck(@RequestBody HygieneCheck check) {
        hygieneService.updateCheck(check);
        return Result.success();
    }

    @Operation(summary = "获取卫生统计")
    @GetMapping("/statistics")
    public Result<HygieneStatisticsVO> getHygieneStatistics(
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        HygieneStatisticsVO statistics = hygieneService.getHygieneStatistics(buildingId, startDate, endDate);
        return Result.success(statistics);
    }

    @Operation(summary = "获取各楼栋卫生排名")
    @GetMapping("/ranking")
    public Result<List<HygieneStatisticsVO>> getBuildingRanking(
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        List<HygieneStatisticsVO> ranking = hygieneService.getBuildingRanking(startDate, endDate);
        return Result.success(ranking);
    }

    @Operation(summary = "提交整改")
    @PutMapping("/{id}/rectification")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> submitRectification(@PathVariable Long id) {
        hygieneService.submitRectification(id);
        return Result.success();
    }

    @Operation(summary = "验收整改")
    @PutMapping("/{id}/verify")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> verifyRectification(@PathVariable Long id, @RequestParam Integer status) {
        hygieneService.verifyRectification(id, status);
        return Result.success();
    }
}
