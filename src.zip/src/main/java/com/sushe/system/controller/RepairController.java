package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.Repair;
import com.sushe.system.service.RepairService;
import com.sushe.system.vo.RepairVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 报修管理控制器
 */
@Tag(name = "报修管理", description = "报修工单管理接口")
@RestController
@RequestMapping("/repair")
@RequiredArgsConstructor
public class RepairController {

    private final RepairService repairService;

    @Operation(summary = "分页查询报修工单")
    @GetMapping("/page")
    public Result<Page<RepairVO>> getRepairPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Integer status,
            @RequestParam(required = false) Integer repairType) {
        Page<RepairVO> page = repairService.getRepairPage(pageNum, pageSize, status, repairType);
        return Result.success(page);
    }

    @Operation(summary = "获取报修详情")
    @GetMapping("/{id}")
    public Result<RepairVO> getRepairDetail(@PathVariable Long id) {
        RepairVO repairVO = repairService.getRepairDetail(id);
        return Result.success(repairVO);
    }

    @Operation(summary = "提交报修")
    @PostMapping
    public Result<Void> submitRepair(@RequestBody Repair repair) {
        repairService.submitRepair(repair);
        return Result.success();
    }

    @Operation(summary = "派单")
    @PutMapping("/{id}/assign")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> assignRepair(@PathVariable Long id, @RequestParam Long repairerId) {
        repairService.assignRepair(id, repairerId);
        return Result.success();
    }

    @Operation(summary = "开始维修")
    @PutMapping("/{id}/start")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> startRepair(@PathVariable Long id) {
        repairService.startRepair(id);
        return Result.success();
    }

    @Operation(summary = "完成维修")
    @PutMapping("/{id}/complete")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> completeRepair(@PathVariable Long id, @RequestParam String result) {
        repairService.completeRepair(id, result);
        return Result.success();
    }

    @Operation(summary = "评价")
    @PutMapping("/{id}/evaluate")
    public Result<Void> evaluateRepair(@PathVariable Long id,
                                        @RequestParam Integer rating,
                                        @RequestParam(required = false) String comment) {
        repairService.evaluateRepair(id, rating, comment);
        return Result.success();
    }
}
