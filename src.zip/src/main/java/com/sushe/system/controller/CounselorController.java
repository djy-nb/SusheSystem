package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.service.CounselorService;
import com.sushe.system.vo.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 辅导员管理控制器
 */
@Tag(name = "辅导员管理", description = "辅导员端宿舍管理接口")
@RestController
@RequestMapping("/counselor")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN', 'COUNSELOR')")
public class CounselorController {

    private final CounselorService counselorService;

    @Operation(summary = "获取辅导员首页统计数据")
    @GetMapping("/statistics")
    public Result<CounselorVO> getCounselorStatistics() {
        CounselorVO statistics = counselorService.getCounselorStatistics();
        return Result.success(statistics);
    }

    @Operation(summary = "分页查询所辖学生住宿信息")
    @GetMapping("/students")
    public Result<Page<CheckInVO>> getCounselorStudents(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword) {
        Page<CheckInVO> page = counselorService.getCounselorStudents(pageNum, pageSize, keyword);
        return Result.success(page);
    }

    @Operation(summary = "分页查询所辖学生报修工单")
    @GetMapping("/repairs")
    public Result<Page<RepairVO>> getCounselorRepairs(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Integer status) {
        Page<RepairVO> page = counselorService.getCounselorRepairs(pageNum, pageSize, status);
        return Result.success(page);
    }

    @Operation(summary = "分页查询所辖学生卫生检查记录")
    @GetMapping("/hygiene")
    public Result<Page<HygieneCheckVO>> getCounselorHygiene(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String grade) {
        Page<HygieneCheckVO> page = counselorService.getCounselorHygiene(pageNum, pageSize, grade);
        return Result.success(page);
    }

    @Operation(summary = "分页查询所辖学生门禁记录")
    @GetMapping("/access")
    public Result<Page<AccessRecordVO>> getCounselorAccess(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Integer direction) {
        Page<AccessRecordVO> page = counselorService.getCounselorAccess(pageNum, pageSize, direction);
        return Result.success(page);
    }
}
