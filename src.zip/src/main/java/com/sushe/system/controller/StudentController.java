package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.OperLogAnnotation;
import com.sushe.system.common.Result;
import com.sushe.system.dto.StudentDTO;
import com.sushe.system.service.StudentService;
import com.sushe.system.vo.StudentVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 学生管理控制器
 */
@Tag(name = "学生管理", description = "学生信息管理接口")
@RestController
@RequestMapping("/student")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @Operation(summary = "分页查询学生列表")
    @GetMapping("/page")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN', 'COUNSELOR')")
    public Result<Page<StudentVO>> getStudentPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String studentNo,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Integer status) {
        Page<StudentVO> page = studentService.getStudentPage(
                pageNum, pageSize, studentNo, name, buildingId, roomId, status
        );
        return Result.success(page);
    }

    @Operation(summary = "获取学生详情")
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN', 'COUNSELOR')")
    public Result<StudentVO> getStudentDetail(@PathVariable Long id) {
        StudentVO studentVO = studentService.getStudentDetail(id);
        return Result.success(studentVO);
    }

    @Operation(summary = "新增学生")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> addStudent(@Valid @RequestBody StudentDTO studentDTO) {
        studentService.addStudent(studentDTO);
        return Result.success();
    }

    @Operation(summary = "更新学生信息")
    @PutMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> updateStudent(@Valid @RequestBody StudentDTO studentDTO) {
        studentService.updateStudent(studentDTO);
        return Result.success();
    }

    @Operation(summary = "删除学生")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperLogAnnotation(module = "学生管理", operType = "DELETE", description = "删除学生")
    public Result<Void> deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return Result.success();
    }

    @Operation(summary = "重置学生密码")
    @PutMapping("/{id}/reset-password")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> resetStudentPassword(@PathVariable Long id) {
        studentService.resetStudentPassword(id);
        return Result.success();
    }

    @Operation(summary = "更新学生状态")
    @PutMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> updateStudentStatus(
            @PathVariable Long id,
            @RequestParam Integer status) {
        studentService.updateStudentStatus(id, status);
        return Result.success();
    }
}
