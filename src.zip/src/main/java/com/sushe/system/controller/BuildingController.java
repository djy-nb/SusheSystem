package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.Building;
import com.sushe.system.service.BuildingService;
import com.sushe.system.vo.BuildingVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 宿舍楼管理控制器
 */
@Tag(name = "宿舍楼管理", description = "宿舍楼信息管理接口")
@RestController
@RequestMapping("/building")
@RequiredArgsConstructor
public class BuildingController {

    private final BuildingService buildingService;

    @Operation(summary = "分页查询宿舍楼列表")
    @GetMapping("/page")
    public Result<Page<BuildingVO>> getBuildingPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword) {
        Page<BuildingVO> page = buildingService.getBuildingPage(pageNum, pageSize, keyword);
        return Result.success(page);
    }

    @Operation(summary = "获取所有宿舍楼列表")
    @GetMapping("/list")
    public Result<List<BuildingVO>> getAllBuildings() {
        List<BuildingVO> list = buildingService.getAllBuildings();
        return Result.success(list);
    }

    @Operation(summary = "获取宿舍楼详情")
    @GetMapping("/{id}")
    public Result<BuildingVO> getBuildingDetail(@PathVariable Long id) {
        BuildingVO buildingVO = buildingService.getBuildingDetail(id);
        return Result.success(buildingVO);
    }

    @Operation(summary = "新增宿舍楼")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> addBuilding(@RequestBody Building building) {
        buildingService.addBuilding(building);
        return Result.success();
    }

    @Operation(summary = "更新宿舍楼信息")
    @PutMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> updateBuilding(@RequestBody Building building) {
        buildingService.updateBuilding(building);
        return Result.success();
    }

    @Operation(summary = "删除宿舍楼")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteBuilding(@PathVariable Long id) {
        buildingService.deleteBuilding(id);
        return Result.success();
    }
}
