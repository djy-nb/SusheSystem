package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.EnergyRecord;
import com.sushe.system.service.EnergyService;
import com.sushe.system.vo.EnergyRecordVO;
import com.sushe.system.vo.EnergyStatisticsVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 能耗管理控制器
 */
@Tag(name = "能耗管理", description = "能耗监测与管理接口")
@RestController
@RequestMapping("/energy")
@RequiredArgsConstructor
public class EnergyController {

    private final EnergyService energyService;

    @Operation(summary = "分页查询能耗记录")
    @GetMapping("/page")
    public Result<Page<EnergyRecordVO>> getEnergyPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Integer energyType,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        Page<EnergyRecordVO> page = energyService.getEnergyPage(pageNum, pageSize, buildingId, roomId, energyType, startDate, endDate);
        return Result.success(page);
    }

    @Operation(summary = "获取能耗统计")
    @GetMapping("/statistics")
    public Result<EnergyStatisticsVO> getEnergyStatistics(
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        EnergyStatisticsVO statistics = energyService.getEnergyStatistics(buildingId, roomId, startDate, endDate);
        return Result.success(statistics);
    }

    @Operation(summary = "获取每日能耗趋势")
    @GetMapping("/trend")
    public Result<List<EnergyStatisticsVO>> getDailyTrend(
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        List<EnergyStatisticsVO> trend = energyService.getDailyTrend(buildingId, roomId, startDate, endDate);
        return Result.success(trend);
    }

    @Operation(summary = "添加能耗记录")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> addEnergyRecord(@RequestBody EnergyRecord record) {
        energyService.addEnergyRecord(record);
        return Result.success();
    }

    @Operation(summary = "获取异常能耗记录")
    @GetMapping("/abnormal")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Page<EnergyRecordVO>> getAbnormalRecords(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId) {
        Page<EnergyRecordVO> page = energyService.getAbnormalRecords(pageNum, pageSize, buildingId);
        return Result.success(page);
    }
}
