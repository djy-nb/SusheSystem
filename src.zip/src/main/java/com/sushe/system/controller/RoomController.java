package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.OperLogAnnotation;
import com.sushe.system.common.Result;
import com.sushe.system.entity.Room;
import com.sushe.system.service.RoomService;
import jakarta.validation.Valid;
import com.sushe.system.vo.BedVO;
import com.sushe.system.vo.RoomVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 房间管理控制器
 */
@Tag(name = "房间管理", description = "宿舍房间信息管理接口")
@RestController
@RequestMapping("/room")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @Operation(summary = "分页查询房间列表")
    @GetMapping("/page")
    public Result<Page<RoomVO>> getRoomPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Integer floor,
            @RequestParam(required = false) Integer status) {
        Page<RoomVO> page = roomService.getRoomPage(pageNum, pageSize, buildingId, floor, status);
        return Result.success(page);
    }

    @Operation(summary = "获取房间详情")
    @GetMapping("/{id}")
    public Result<RoomVO> getRoomDetail(@PathVariable Long id) {
        RoomVO roomVO = roomService.getRoomDetail(id);
        return Result.success(roomVO);
    }

    @Operation(summary = "获取指定楼栋的房间列表")
    @GetMapping("/building/{buildingId}")
    public Result<List<RoomVO>> getRoomsByBuilding(@PathVariable Long buildingId) {
        List<RoomVO> list = roomService.getRoomsByBuilding(buildingId);
        return Result.success(list);
    }

    @Operation(summary = "新增房间")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    @OperLogAnnotation(module = "房间管理", operType = "CREATE", description = "新增房间")
    public Result<Void> addRoom(@Valid @RequestBody Room room) {
        roomService.addRoom(room);
        return Result.success();
    }

    @Operation(summary = "更新房间信息")
    @PutMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    @OperLogAnnotation(module = "房间管理", operType = "UPDATE", description = "更新房间信息")
    public Result<Void> updateRoom(@Valid @RequestBody Room room) {
        roomService.updateRoom(room);
        return Result.success();
    }

    @Operation(summary = "删除房间")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
        return Result.success();
    }

    @Operation(summary = "重新生成房间床位")
    @PutMapping("/{id}/regenerate-beds")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> regenerateBeds(@PathVariable Long id) {
        roomService.regenerateBeds(id);
        return Result.success();
    }

    @Operation(summary = "获取房间的床位列表")
    @GetMapping("/{roomId}/beds")
    public Result<List<BedVO>> getRoomBeds(@PathVariable Long roomId) {
        List<BedVO> list = roomService.getRoomBeds(roomId);
        return Result.success(list);
    }
}
