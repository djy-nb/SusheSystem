package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.Notice;
import com.sushe.system.service.NoticeService;
import com.sushe.system.vo.NoticeVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 通知公告控制器
 */
@Tag(name = "通知公告", description = "通知公告管理接口")
@RestController
@RequestMapping("/notice")
@RequiredArgsConstructor
public class NoticeController {

    private final NoticeService noticeService;

    @Operation(summary = "分页查询通知公告")
    @GetMapping("/page")
    public Result<Page<NoticeVO>> getNoticePage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Integer type,
            @RequestParam(required = false) Integer status) {
        Page<NoticeVO> page = noticeService.getNoticePage(pageNum, pageSize, type, status);
        return Result.success(page);
    }

    @Operation(summary = "获取通知详情")
    @GetMapping("/{id}")
    public Result<NoticeVO> getNoticeDetail(@PathVariable Long id) {
        NoticeVO noticeVO = noticeService.getNoticeDetail(id);
        return Result.success(noticeVO);
    }

    @Operation(summary = "发布通知")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN', 'COUNSELOR')")
    public Result<Void> publishNotice(@RequestBody Notice notice) {
        noticeService.publishNotice(notice);
        return Result.success();
    }

    @Operation(summary = "更新通知")
    @PutMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN', 'COUNSELOR')")
    public Result<Void> updateNotice(@RequestBody Notice notice) {
        noticeService.updateNotice(notice);
        return Result.success();
    }

    @Operation(summary = "删除通知")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN', 'COUNSELOR')")
    public Result<Void> deleteNotice(@PathVariable Long id) {
        noticeService.deleteNotice(id);
        return Result.success();
    }

    @Operation(summary = "撤回通知")
    @PutMapping("/{id}/withdraw")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN', 'COUNSELOR')")
    public Result<Void> withdrawNotice(@PathVariable Long id) {
        noticeService.withdrawNotice(id);
        return Result.success();
    }
}
