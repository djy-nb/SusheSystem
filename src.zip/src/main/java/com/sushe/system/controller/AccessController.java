package com.sushe.system.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.common.Result;
import com.sushe.system.entity.AccessRecord;
import com.sushe.system.service.AccessService;
import com.sushe.system.vo.AccessRecordVO;
import com.sushe.system.vo.AccessStatisticsVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 门禁管理控制器
 */
@Tag(name = "门禁管理", description = "门禁通行记录管理接口")
@RestController
@RequestMapping("/access")
@RequiredArgsConstructor
public class AccessController {

    private final AccessService accessService;

    @Operation(summary = "分页查询门禁记录")
    @GetMapping("/page")
    public Result<Page<AccessRecordVO>> getAccessPage(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Integer direction,
            @RequestParam(required = false) Integer verifyResult,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        Page<AccessRecordVO> page = accessService.getAccessPage(pageNum, pageSize, buildingId, userId, direction, verifyResult, startDate, endDate);
        return Result.success(page);
    }

    @Operation(summary = "添加门禁记录")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Void> addAccessRecord(@RequestBody AccessRecord record) {
        accessService.addAccessRecord(record);
        return Result.success();
    }

    @Operation(summary = "获取门禁统计")
    @GetMapping("/statistics")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<AccessStatisticsVO> getAccessStatistics(
            @RequestParam(required = false) Long buildingId,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) {
        AccessStatisticsVO statistics = accessService.getAccessStatistics(buildingId, date);
        return Result.success(statistics);
    }

    @Operation(summary = "获取每日进出趋势")
    @GetMapping("/trend")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<List<AccessStatisticsVO>> getDailyTrend(
            @RequestParam(required = false) Long buildingId,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
        List<AccessStatisticsVO> trend = accessService.getDailyTrend(buildingId, startDate, endDate);
        return Result.success(trend);
    }

    @Operation(summary = "获取异常记录")
    @GetMapping("/abnormal")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_ADMIN')")
    public Result<Page<AccessRecordVO>> getAbnormalRecords(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long buildingId) {
        Page<AccessRecordVO> page = accessService.getAbnormalRecords(pageNum, pageSize, buildingId);
        return Result.success(page);
    }
}
