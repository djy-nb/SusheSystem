package com.sushe.system.controller;

import com.sushe.system.common.Result;
import com.sushe.system.service.*;
import com.sushe.system.vo.DashboardVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 首页仪表盘控制器
 */
@Tag(name = "首页仪表盘", description = "首页统计数据接口")
@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final UserService userService;
    private final BuildingService buildingService;
    private final RoomService roomService;
    private final CheckInService checkInService;
    private final RepairService repairService;
    private final NoticeService noticeService;

    @Operation(summary = "获取首页统计数据")
    @GetMapping("/statistics")
    public Result<DashboardVO> getDashboardStatistics() {
        DashboardVO dashboard = new DashboardVO();

        // 学生总数
        dashboard.setStudentCount(userService.count());

        // 楼栋总数
        dashboard.setBuildingCount(buildingService.count());

        // 房间总数
        dashboard.setRoomCount(roomService.count());

        // 在住人数（只统计status=1的在住学生）
        dashboard.setCheckInCount(checkInService.countCheckedIn());

        // 待处理报修
        dashboard.setPendingRepairCount(repairService.count());

        // 最新通知
        dashboard.setLatestNotices(noticeService.getNoticePage(1, 5, null, 1).getRecords());

        return Result.success(dashboard);
    }
}
