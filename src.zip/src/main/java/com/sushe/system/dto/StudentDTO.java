package com.sushe.system.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.io.Serializable;

/**
 * 学生数据传输对象
 */
@Data
public class StudentDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 学生ID（编辑时必填） */
    private Long id;

    /** 学号 */
    @NotBlank(message = "学号不能为空")
    private String studentNo;

    /** 真实姓名 */
    @NotBlank(message = "姓名不能为空")
    private String name;

    /** 性别：男/女 */
    @NotBlank(message = "性别不能为空")
    private String gender;

    /** 联系电话 */
    @NotBlank(message = "联系电话不能为空")
    private String phone;

    /** 邮箱 */
    private String email;

    /** 所属学院 */
    @NotBlank(message = "学院不能为空")
    private String college;

    /** 所属班级 */
    @NotBlank(message = "班级不能为空")
    private String className;

    /** 身份证号 */
    private String idCard;

    /** 宿舍楼ID */
    private Long buildingId;

    /** 房间ID */
    private Long roomId;

    /** 床位表主键ID */
    private Long bedId;

    /** 床位号（1、2、3等） */
    private Integer bedNo;
}
