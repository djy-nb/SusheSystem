 package com.sushe.system;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 智能宿舍管理系统启动类
 * Smart Dormitory Management System
 */
@SpringBootApplication
@MapperScan("com.sushe.system.mapper")
@EnableAsync
@EnableScheduling
public class SusheSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(SusheSystemApplication.class, args);
        System.out.println("============================================");
        System.out.println("   智能宿舍管理系统启动成功!");
        System.out.println("   Smart Dormitory Management System");
        System.out.println("   接口文档: http://localhost:8080/api/doc.html");
        System.out.println("============================================");
    }
}
