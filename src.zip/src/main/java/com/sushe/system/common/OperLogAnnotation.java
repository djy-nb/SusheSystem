package com.sushe.system.common;

import java.lang.annotation.*;

/**
 * 操作日志注解 - 标记需要记录日志的方法
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OperLogAnnotation {

    /** 模块名称 */
    String module() default "";

    /** 操作类型：CREATE, UPDATE, DELETE, LOGIN, LOGOUT, EXPORT */
    String operType() default "";

    /** 操作描述 */
    String description() default "";
}
