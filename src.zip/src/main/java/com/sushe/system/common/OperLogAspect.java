package com.sushe.system.common;

import com.sushe.system.entity.OperLog;
import com.sushe.system.mapper.OperLogMapper;
import com.sushe.system.security.LoginUser;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.LocalDateTime;

/**
 * 操作日志切面 - 自动记录标注了 @OperLogAnnotation 的方法调用
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class OperLogAspect {

    private final OperLogMapper operLogMapper;

    @Pointcut("@annotation(com.sushe.system.common.OperLogAnnotation)")
    public void operLogPointcut() {}

    @Around("operLogPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = null;
        String errorMsg = null;
        int status = 1; // 1=成功（OperLog约定：1成功 0失败）

        try {
            result = joinPoint.proceed();
            return result;
        } catch (Throwable e) {
            status = 0; // 失败
            errorMsg = e.getMessage();
            throw e;
        } finally {
            try {
                recordLog(joinPoint, startTime, status, errorMsg);
            } catch (Exception e) {
                log.error("记录操作日志失败: {}", e.getMessage());
            }
        }
    }

    private void recordLog(ProceedingJoinPoint joinPoint, long startTime, int status, String errorMsg) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        OperLogAnnotation annotation = signature.getMethod().getAnnotation(OperLogAnnotation.class);
        if (annotation == null) return;

        OperLog operLog = new OperLog();
        operLog.setModule(annotation.module());
        // operType 是 Integer 类型，注解中用 String 描述，这里做简单映射
        operLog.setOperType(mapOperType(annotation.operType()));
        operLog.setDescription(annotation.description());
        operLog.setStatus(status);
        operLog.setErrorMsg(errorMsg);
        operLog.setCreateTime(LocalDateTime.now());
        operLog.setCostTime(System.currentTimeMillis() - startTime);

        // 方法信息
        operLog.setMethod(signature.getDeclaringTypeName() + "." + signature.getName());

        // 请求信息
        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes != null) {
                HttpServletRequest request = attributes.getRequest();
                operLog.setOperIp(getClientIp(request));
                operLog.setUrl(request.getRequestURI());
                operLog.setRequestMethod(request.getMethod());
            }
        } catch (Exception ignored) {}

        // 操作人信息
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof LoginUser loginUser) {
                operLog.setOperUserId(loginUser.getUserId());
                operLog.setOperUserName(loginUser.getUsername());
            }
        } catch (Exception ignored) {}

        // 保存日志
        try {
            operLogMapper.insert(operLog);
        } catch (Exception e) {
            log.error("保存操作日志到数据库失败: {}", e.getMessage());
        }
    }

    /**
     * 将操作类型字符串映射为数字
     */
    private Integer mapOperType(String operType) {
        if (operType == null) return null;
        return switch (operType.toUpperCase()) {
            case "CREATE", "LOGIN" -> 1;
            case "UPDATE" -> 2;
            case "DELETE", "LOGOUT" -> 3;
            case "QUERY" -> 4;
            case "EXPORT" -> 5;
            case "IMPORT" -> 6;
            default -> null;
        };
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }
}
