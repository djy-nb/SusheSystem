package com.sushe.system.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 登录频率限制器
 * 防止暴力破解攻击，基于IP和用户名双重限制
 */
@Slf4j
@Component
public class LoginRateLimiter {

    /** 最大失败次数 */
    private static final int MAX_ATTEMPTS = 5;

    /** 锁定时间（毫秒）：15分钟 */
    private static final long LOCK_DURATION_MS = 15 * 60 * 1000L;

    /** IP级别尝试记录: key=ip, value=AttemptInfo */
    private final ConcurrentHashMap<String, AttemptInfo> ipAttempts = new ConcurrentHashMap<>();

    /** 用户名级别尝试记录: key=username, value=AttemptInfo */
    private final ConcurrentHashMap<String, AttemptInfo> userAttempts = new ConcurrentHashMap<>();

    /**
     * 检查是否被限制
     * @param ip 客户端IP
     * @param username 用户名
     * @return 如果被限制返回错误信息，否则返回null
     */
    public String checkRateLimit(String ip, String username) {
        // 检查IP限制
        String ipBlock = checkAttempts(ipAttempts, ip, "IP");
        if (ipBlock != null) {
            return ipBlock;
        }
        // 检查用户名限制
        if (username != null) {
            String userBlock = checkAttempts(userAttempts, username, "账号");
            if (userBlock != null) {
                return userBlock;
            }
        }
        return null;
    }

    /**
     * 记录登录失败
     */
    public void recordFailure(String ip, String username) {
        recordAttempt(ipAttempts, ip);
        if (username != null) {
            recordAttempt(userAttempts, username);
        }
        log.warn("登录失败 - IP: {}, 用户名: {}", ip, username);
    }

    /**
     * 登录成功后清除记录
     */
    public void recordSuccess(String ip, String username) {
        ipAttempts.remove(ip);
        if (username != null) {
            userAttempts.remove(username);
        }
    }

    private String checkAttempts(ConcurrentHashMap<String, AttemptInfo> map, String key, String label) {
        AttemptInfo info = map.get(key);
        if (info == null) {
            return null;
        }
        // 检查锁定是否已过期
        if (System.currentTimeMillis() - info.lastAttemptTime > LOCK_DURATION_MS) {
            map.remove(key);
            return null;
        }
        if (info.attempts.get() >= MAX_ATTEMPTS) {
            long remainingSec = (LOCK_DURATION_MS - (System.currentTimeMillis() - info.lastAttemptTime)) / 1000;
            return label + "已被锁定，请" + remainingSec + "秒后再试";
        }
        return null;
    }

    private void recordAttempt(ConcurrentHashMap<String, AttemptInfo> map, String key) {
        AttemptInfo info = map.computeIfAbsent(key, k -> new AttemptInfo());
        info.attempts.incrementAndGet();
        info.lastAttemptTime = System.currentTimeMillis();
    }

    private static class AttemptInfo {
        final AtomicInteger attempts = new AtomicInteger(0);
        volatile long lastAttemptTime = System.currentTimeMillis();
    }
}
