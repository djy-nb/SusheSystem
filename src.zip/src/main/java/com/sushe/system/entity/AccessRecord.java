package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 门禁通行记录实体类
 */
@Data
@TableName("dorm_access_record")
public class AccessRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 用户ID */
    private Long userId;

    /** 楼栋ID */
    private Long buildingId;

    /** 通行方向：1-进入 2-离开 */
    private Integer direction;

    /** 验证方式：1-人脸识别 2-刷卡 3-密码 4-手机 */
    private Integer verifyType;

    /** 验证结果：0-失败 1-成功 */
    private Integer verifyResult;

    /** 失败原因 */
    private String failReason;

    /** 体温 */
    private Double temperature;

    /** 抓拍图片 */
    private String captureImage;

    /** 设备编号 */
    private String deviceCode;

    /** 通行时间 */
    private LocalDateTime passTime;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
