package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 通知公告实体类
 */
@Data
@TableName("dorm_notice")
public class Notice implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 通知ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 标题 */
    private String title;

    /** 内容 */
    private String content;

    /** 通知类型：1-系统通知 2-楼栋通知 3-宿舍通知 4-活动通知 */
    private Integer type;

    /** 优先级：1-普通 2-重要 3-紧急 */
    private Integer priority;

    /** 目标范围：0-全部 1-指定楼栋 2-指定房间 */
    private Integer targetRange;

    /** 目标楼栋ID（逗号分隔） */
    private String targetBuildings;

    /** 目标房间ID（逗号分隔） */
    private String targetRooms;

    /** 是否置顶：0-否 1-是 */
    private Integer isTop;

    /** 附件地址 */
    private String attachment;

    /** 发布人ID */
    private Long publisherId;

    /** 发布人姓名 */
    private String publisherName;

    /** 状态：0-草稿 1-已发布 2-已撤回 */
    private Integer status;

    /** 发布时间 */
    private LocalDateTime publishTime;

    /** 阅读人数 */
    private Integer readCount;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /** 删除标志 */
    @TableLogic
    private Integer deleted;
}
