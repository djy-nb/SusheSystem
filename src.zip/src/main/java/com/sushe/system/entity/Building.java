package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 宿舍楼实体类
 */
@Data
@TableName("dorm_building")
public class Building implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 楼栋ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 楼栋名称 */
    private String name;

    /** 楼栋编号 */
    private String code;

    /** 楼层数 */
    private Integer floorCount;

    /** 总房间数 */
    private Integer roomCount;

    /** 已入住人数 */
    private Integer occupiedCount;

    /** 楼栋类型：1-男生宿舍 2-女生宿舍 3-混合宿舍 */
    private Integer type;

    /** 楼栋地址 */
    private String address;

    /** 经度 */
    private Double longitude;

    /** 纬度 */
    private Double latitude;

    /** 宿管员ID */
    private Long adminId;

    /** 联系电话 */
    private String contactPhone;

    /** 备注 */
    private String remark;

    /** 状态：0-停用 1-正常 */
    private Integer status;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /** 删除标志 */
    @TableLogic
    private Integer deleted;
}
