package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 访客记录实体类
 */
@Data
@TableName("dorm_visitor")
public class Visitor implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 访客姓名 */
    private String visitorName;

    /** 访客身份证号 */
    private String idCard;

    /** 访客手机号 */
    private String phone;

    /** 访客性别：0-女 1-男 */
    private Integer gender;

    /** 来访原因 */
    private String reason;

    /** 被访学生ID */
    private Long studentId;

    /** 被访学生姓名 */
    private String studentName;

    /** 访问房间ID */
    private Long roomId;

    /** 楼栋ID */
    private Long buildingId;

    /** 预约来访时间 */
    private LocalDateTime appointmentTime;

    /** 实际到达时间 */
    private LocalDateTime arrivalTime;

    /** 离开时间 */
    private LocalDateTime leaveTime;

    /** 状态：0-待审核 1-已审核 2-已到达 3-已离开 4-已拒绝 */
    private Integer status;

    /** 审核人ID */
    private Long approverId;

    /** 审核意见 */
    private String approveRemark;

    /** 访客照片 */
    private String visitorPhoto;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
