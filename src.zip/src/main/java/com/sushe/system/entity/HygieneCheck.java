package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 卫生检查实体类
 */
@Data
@TableName("dorm_hygiene_check")
public class HygieneCheck implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 检查ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 房间ID */
    private Long roomId;

    /** 楼栋ID */
    private Long buildingId;

    /** 检查日期 */
    private LocalDate checkDate;

    /** 检查类型：1-日常检查 2-专项检查 3-突击检查 */
    private Integer checkType;

    /** 整体评分：1-5分 */
    private Integer score;

    /** 等级：A-优秀 B-良好 C-一般 D-较差 */
    private String grade;

    /** 地面清洁评分 */
    private Integer floorScore;

    /** 桌面整洁评分 */
    private Integer deskScore;

    /** 床铺整洁评分 */
    private Integer bedScore;

    /** 卫生间评分 */
    private Integer bathroomScore;

    /** 阳台评分 */
    private Integer balconyScore;

    /** 是否有违禁品：0-否 1-是 */
    private Integer hasContraband;

    /** 违禁品详情 */
    private String contrabandDetail;

    /** 检查图片（逗号分隔） */
    private String images;

    /** 检查人ID */
    private Long checkerId;

    /** 检查人姓名 */
    private String checkerName;

    /** 备注 */
    private String remark;

    /** 整改要求 */
    private String rectification;

    /** 整改截止日期 */
    private LocalDate rectificationDeadline;

    /** 整改状态：0-无需整改 1-待整改 2-已整改 3-已验收 */
    private Integer rectificationStatus;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
