package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 宿舍房间实体类
 */
@Data
@TableName("dorm_room")
public class Room implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 房间ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属楼栋ID */
    private Long buildingId;

    /** 房间号 */
    private String roomNumber;

    /** 楼层 */
    private Integer floor;

    /** 房间类型：1-四人间 2-六人间 3-八人间 4-单人间 */
    private Integer roomType;

    /** 床位数 */
    private Integer bedCount;

    /** 已入住人数 */
    private Integer occupiedCount;

    /** 房间面积（平方米） */
    private BigDecimal area;

    /** 房间状态：0-空闲 1-正常 2-维修中 3-已满 */
    private Integer status;

    /** 是否有独立卫生间：0-否 1-是 */
    private Integer hasBathroom;

    /** 是否有空调：0-否 1-是 */
    private Integer hasAircon;

    /** 是否有热水器：0-否 1-是 */
    private Integer hasWaterHeater;

    /** 每学年费用 */
    private BigDecimal price;

    /** 备注 */
    private String remark;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /** 删除标志 */
    @TableLogic
    private Integer deleted;
}
