package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 报修工单实体类
 */
@Data
@TableName("dorm_repair_order")
public class RepairOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 工单ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 工单编号 */
    private String orderNo;

    /** 报修人ID */
    private Long userId;

    /** 报修人姓名 */
    private String userName;

    /** 房间ID */
    private Long roomId;

    /** 楼栋ID */
    private Long buildingId;

    /** 报修类型：1-水电维修 2-家具维修 3-门窗维修 4-网络故障 5-其他 */
    private Integer repairType;

    /** 报修标题 */
    private String title;

    /** 问题描述 */
    private String description;

    /** 图片（逗号分隔） */
    private String images;

    /** 联系电话 */
    private String contactPhone;

    /** 期望维修时间 */
    private LocalDateTime expectTime;

    /** 优先级：1-低 2-中 3-高 4-紧急 */
    private Integer priority;

    /** 状态：0-待处理 1-已派单 2-维修中 3-已完成 4-已评价 5-已取消 */
    private Integer status;

    /** 维修人员ID */
    private Long repairerId;

    /** 维修人员姓名 */
    private String repairerName;

    /** 维修说明 */
    private String repairNote;

    /** 维修图片（逗号分隔） */
    private String repairImages;

    /** 维修费用 */
    private java.math.BigDecimal cost;

    /** 评价评分：1-5星 */
    private Integer rating;

    /** 评价内容 */
    private String evaluateContent;

    /** 完成时间 */
    private LocalDateTime completeTime;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
