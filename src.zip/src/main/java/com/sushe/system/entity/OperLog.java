package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 操作日志实体类
 */
@Data
@TableName("sys_oper_log")
public class OperLog implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 日志ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 模块名称 */
    private String module;

    /** 操作类型：1-新增 2-修改 3-删除 4-查询 5-导出 6-导入 */
    private Integer operType;

    /** 操作描述 */
    private String description;

    /** 请求方法 */
    private String method;

    /** 请求URL */
    private String url;

    /** 请求方式：GET/POST/PUT/DELETE */
    private String requestMethod;

    /** 请求参数 */
    private String requestParam;

    /** 返回结果 */
    private String result;

    /** 操作状态：0-失败 1-成功 */
    private Integer status;

    /** 错误信息 */
    private String errorMsg;

    /** 操作人ID */
    private Long operUserId;

    /** 操作人姓名 */
    private String operUserName;

    /** 操作IP */
    private String operIp;

    /** 操作地点 */
    private String operLocation;

    /** 操作耗时（毫秒） */
    private Long costTime;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
