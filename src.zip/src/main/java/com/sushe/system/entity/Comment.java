package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 评论实体类
 */
@Data
@TableName("dorm_comment")
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 评论ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 帖子ID */
    private Long postId;

    /** 评论人ID */
    private Long userId;

    /** 评论人姓名 */
    private String userName;

    /** 评论内容 */
    private String content;

    /** 父评论ID */
    private Long parentId;

    /** 回复用户ID */
    private Long replyUserId;

    /** 回复用户姓名 */
    private String replyUserName;

    /** 点赞数 */
    private Integer likeCount;

    /** 状态：0-隐藏 1-正常 */
    private Integer status;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 删除标志 */
    @TableLogic
    private Integer deleted;
}
