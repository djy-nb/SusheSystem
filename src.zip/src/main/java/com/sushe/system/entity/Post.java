package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 社区帖子实体类
 */
@Data
@TableName("dorm_post")
public class Post implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 帖子ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 发帖人ID */
    private Long userId;

    /** 发帖人姓名 */
    private String userName;

    /** 标题 */
    private String title;

    /** 内容 */
    private String content;

    /** 图片（逗号分隔） */
    private String images;

    /** 帖子类型：1-失物招领 2-二手交易 3-拼车出行 4-学习交流 5-生活求助 6-其他 */
    private Integer type;

    /** 楼栋ID */
    private Long buildingId;

    /** 浏览数 */
    private Integer viewCount;

    /** 点赞数 */
    private Integer likeCount;

    /** 评论数 */
    private Integer commentCount;

    /** 是否置顶：0-否 1-是 */
    private Integer isTop;

    /** 状态：0-隐藏 1-正常 2-置顶 */
    private Integer status;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /** 删除标志 */
    @TableLogic
    private Integer deleted;
}
