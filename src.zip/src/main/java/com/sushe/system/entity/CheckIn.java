package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 入住记录实体类
 */
@Data
@TableName("dorm_check_in")
public class CheckIn implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 学生ID */
    private Long studentId;

    /** 房间ID */
    private Long roomId;

    /** 床位ID */
    private Long bedId;

    /** 楼栋ID */
    private Long buildingId;

    /** 学年 */
    private String academicYear;

    /** 入住时间 */
    private LocalDateTime checkInTime;

    /** 退宿时间 */
    private LocalDateTime checkOutTime;

    /** 状态：0-已退宿 1-在住 */
    private Integer status;

    /** 入住类型：1-正常入住 2-调宿 3-临时入住 */
    private Integer checkInType;

    /** 备注 */
    private String remark;

    /** 操作人ID */
    private Long operatorId;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
