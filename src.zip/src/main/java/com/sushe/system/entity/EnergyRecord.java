package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 能耗记录实体类
 */
@Data
@TableName("dorm_energy_record")
public class EnergyRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 房间ID */
    private Long roomId;

    /** 楼栋ID */
    private Long buildingId;

    /** 能耗类型：1-用电 2-用水 */
    private Integer energyType;

    /** 读数 */
    private BigDecimal meterReading;

    /** 用量 */
    private BigDecimal consumption;

    /** 费用 */
    private BigDecimal cost;

    /** 记录日期 */
    private LocalDate recordDate;

    /** 记录时间 */
    private LocalDateTime recordTime;

    /** 设备编号 */
    private String deviceCode;

    /** 是否异常：0-正常 1-异常 */
    private Integer isAbnormal;

    /** 异常原因 */
    private String abnormalReason;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
