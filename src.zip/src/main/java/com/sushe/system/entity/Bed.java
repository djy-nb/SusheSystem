package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 床位实体类
 */
@Data
@TableName("dorm_bed")
public class Bed implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 床位ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属房间ID */
    private Long roomId;

    /** 床位号：1-上铺 2-下铺 */
    private Integer bedNumber;

    /** 床位位置描述 */
    private String position;

    /** 状态：0-空闲 1-已分配 2-维修中 */
    private Integer status;

    /** 入住学生ID */
    private Long studentId;

    /** 入住时间 */
    private LocalDateTime checkInTime;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    /** 删除标志 */
    @TableLogic
    private Integer deleted;
}
