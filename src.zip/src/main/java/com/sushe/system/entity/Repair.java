package com.sushe.system.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 报修工单实体类
 */
@Data
@TableName("dorm_repair")
public class Repair implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 工单ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 工单编号 */
    private String orderNo;

    /** 报修人ID */
    private Long userId;

    /** 房间ID */
    private Long roomId;

    /** 楼栋ID */
    private Long buildingId;

    /** 报修类型：1-水电维修 2-家具维修 3-门窗维修 4-网络维修 5-其他 */
    private Integer repairType;

    /** 报修标题 */
    private String title;

    /** 报修描述 */
    private String description;

    /** 报修图片（逗号分隔） */
    private String images;

    /** 优先级：1-低 2-中 3-高 4-紧急 */
    private Integer priority;

    /** 状态：0-待处理 1-已派单 2-维修中 3-已完成 4-已评价 5-已关闭 */
    private Integer status;

    /** 维修人员ID */
    private Long repairerId;

    /** 维修人员姓名 */
    private String repairerName;

    /** 预约维修时间 */
    private LocalDateTime appointmentTime;

    /** 开始维修时间 */
    private LocalDateTime startTime;

    /** 完成时间 */
    private LocalDateTime completeTime;

    /** 维修结果描述 */
    private String result;

    /** 维修费用 */
    private java.math.BigDecimal cost;

    /** 评价分数：1-5 */
    private Integer rating;

    /** 评价内容 */
    private String comment;

    /** 备注 */
    private String remark;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
