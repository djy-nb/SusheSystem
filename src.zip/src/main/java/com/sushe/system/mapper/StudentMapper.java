package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.User;
import com.sushe.system.vo.StudentVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 学生Mapper接口
 */
@Mapper
public interface StudentMapper extends BaseMapper<User> {

    /**
     * 查询学生列表（包含宿舍信息）
     */
    @Select("<script>" +
            "SELECT " +
            "  u.id, u.username, u.real_name AS name, " +
            "  CASE WHEN u.gender = 1 THEN '男' ELSE '女' END AS gender, " +
            "  u.phone, u.email, u.user_code AS student_no, " +
            "  u.college, u.class_name, u.id_card, " +
            "  u.status, " +
            "  CASE " +
            "    WHEN u.status = 1 THEN '在住' " +
            "    WHEN u.status = 2 THEN '已退宿' " +
            "    WHEN u.status = 3 THEN '休学' " +
            "    ELSE '未知' " +
            "  END AS status_name, " +
            "  c.building_id, " +
            "  b.name AS building_name, " +
            "  c.room_id, " +
            "  r.room_number, " +
            "  c.bed_id, " +
            "  bd.bed_number, " +
            "  c.check_in_time, " +
            "  u.create_time " +
            "FROM sys_user u " +
            "LEFT JOIN dorm_check_in c ON u.id = c.student_id AND c.status = 1 " +
            "LEFT JOIN dorm_building b ON c.building_id = b.id " +
            "LEFT JOIN dorm_room r ON c.room_id = r.id " +
            "LEFT JOIN dorm_bed bd ON c.bed_id = bd.id " +
            "WHERE u.role = 'STUDENT' AND u.deleted = 0 " +
            "<if test='studentNo != null and studentNo != \"\"'>" +
            "  AND u.user_code LIKE CONCAT('%', #{studentNo}, '%') " +
            "</if>" +
            "<if test='name != null and name != \"\"'>" +
            "  AND u.real_name LIKE CONCAT('%', #{name}, '%') " +
            "</if>" +
            "<if test='buildingId != null'>" +
            "  AND c.building_id = #{buildingId} " +
            "</if>" +
            "<if test='roomId != null'>" +
            "  AND c.room_id = #{roomId} " +
            "</if>" +
            "<if test='status != null'>" +
            "  AND u.status = #{status} " +
            "</if>" +
            "ORDER BY u.create_time DESC" +
            "</script>")
    List<StudentVO> selectStudentList(
            @Param("studentNo") String studentNo,
            @Param("name") String name,
            @Param("buildingId") Long buildingId,
            @Param("roomId") Long roomId,
            @Param("status") Integer status
    );

    /**
     * 查询学生详情（包含宿舍信息）
     */
    @Select("SELECT " +
            "  u.id, u.username, u.real_name AS name, " +
            "  CASE WHEN u.gender = 1 THEN '男' ELSE '女' END AS gender, " +
            "  u.phone, u.email, u.user_code AS student_no, " +
            "  u.college, u.class_name, u.id_card, " +
            "  u.status, " +
            "  CASE " +
            "    WHEN u.status = 1 THEN '在住' " +
            "    WHEN u.status = 2 THEN '已退宿' " +
            "    WHEN u.status = 3 THEN '休学' " +
            "    ELSE '未知' " +
            "  END AS status_name, " +
            "  c.building_id, " +
            "  b.name AS building_name, " +
            "  c.room_id, " +
            "  r.room_number, " +
            "  c.bed_id, " +
            "  bd.bed_number, " +
            "  c.check_in_time, " +
            "  u.create_time " +
            "FROM sys_user u " +
            "LEFT JOIN dorm_check_in c ON u.id = c.student_id AND c.status = 1 " +
            "LEFT JOIN dorm_building b ON c.building_id = b.id " +
            "LEFT JOIN dorm_room r ON c.room_id = r.id " +
            "LEFT JOIN dorm_bed bd ON c.bed_id = bd.id " +
            "WHERE u.id = #{id} AND u.deleted = 0")
    StudentVO selectStudentDetail(@Param("id") Long id);

    /**
     * 检查学号是否已存在
     */
    @Select("SELECT COUNT(*) FROM sys_user WHERE user_code = #{studentNo} AND deleted = 0")
    int countByStudentNo(@Param("studentNo") String studentNo);

    /**
     * 检查学号是否已存在（排除指定ID）
     */
    @Select("SELECT COUNT(*) FROM sys_user WHERE user_code = #{studentNo} AND id != #{id} AND deleted = 0")
    int countByStudentNoExcludeId(@Param("studentNo") String studentNo, @Param("id") Long id);
}
