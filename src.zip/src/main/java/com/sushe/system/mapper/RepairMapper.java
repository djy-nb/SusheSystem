package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.Repair;
import org.apache.ibatis.annotations.Mapper;

/**
 * 报修Mapper接口
 */
@Mapper
public interface RepairMapper extends BaseMapper<Repair> {
}
