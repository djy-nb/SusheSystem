package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.Building;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宿舍楼Mapper接口
 */
@Mapper
public interface BuildingMapper extends BaseMapper<Building> {
}
