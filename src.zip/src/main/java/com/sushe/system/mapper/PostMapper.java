package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.Post;
import org.apache.ibatis.annotations.Mapper;

/**
 * 社区帖子Mapper接口
 */
@Mapper
public interface PostMapper extends BaseMapper<Post> {
}
