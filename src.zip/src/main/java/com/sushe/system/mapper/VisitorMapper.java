package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.Visitor;
import org.apache.ibatis.annotations.Mapper;

/**
 * 访客记录Mapper接口
 */
@Mapper
public interface VisitorMapper extends BaseMapper<Visitor> {
}
