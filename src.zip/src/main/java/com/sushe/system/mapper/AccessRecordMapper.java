package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.AccessRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 门禁记录Mapper接口
 */
@Mapper
public interface AccessRecordMapper extends BaseMapper<AccessRecord> {
}
