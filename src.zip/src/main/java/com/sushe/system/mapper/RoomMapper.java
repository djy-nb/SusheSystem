package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.Room;
import org.apache.ibatis.annotations.Mapper;

/**
 * 房间Mapper接口
 */
@Mapper
public interface RoomMapper extends BaseMapper<Room> {
}
