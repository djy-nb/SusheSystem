package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.EnergyRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 能耗记录Mapper接口
 */
@Mapper
public interface EnergyRecordMapper extends BaseMapper<EnergyRecord> {
}
