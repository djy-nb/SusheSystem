package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.CheckIn;
import org.apache.ibatis.annotations.Mapper;

/**
 * 入住记录Mapper接口
 */
@Mapper
public interface CheckInMapper extends BaseMapper<CheckIn> {
}
