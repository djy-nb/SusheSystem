package com.sushe.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sushe.system.entity.EnergyConsumption;
import org.apache.ibatis.annotations.Mapper;

/**
 * 能耗记录Mapper接口
 */
@Mapper
public interface EnergyConsumptionMapper extends BaseMapper<EnergyConsumption> {
}
