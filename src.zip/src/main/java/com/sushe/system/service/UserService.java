package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.User;
import com.sushe.system.dto.LoginDTO;
import com.sushe.system.dto.UserDTO;
import com.sushe.system.vo.LoginVO;
import com.sushe.system.vo.UserVO;

/**
 * 用户Service接口
 */
public interface UserService extends IService<User> {

    /**
     * 用户登录
     */
    LoginVO login(LoginDTO loginDTO);

    /**
     * 用户登出
     */
    void logout();

    /**
     * 获取当前登录用户信息
     */
    UserVO getCurrentUser();

    /**
     * 用户注册
     */
    void register(UserDTO userDTO);

    /**
     * 分页查询用户列表
     */
    Page<UserVO> getUserPage(Integer pageNum, Integer pageSize, String keyword, String role);

    /**
     * 更新用户信息
     */
    void updateUser(UserDTO userDTO);

    /**
     * 修改密码
     */
    void changePassword(String oldPassword, String newPassword);

    /**
     * 重置密码
     */
    void resetPassword(Long userId);

    /**
     * 更新用户状态
     */
    void updateStatus(Long userId, Integer status);

    /**
     * 新增用户
     */
    void addUser(UserDTO userDTO);
}
