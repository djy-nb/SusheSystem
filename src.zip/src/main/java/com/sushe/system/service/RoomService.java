package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.Room;
import com.sushe.system.vo.BedVO;
import com.sushe.system.vo.RoomVO;

import java.util.List;

/**
 * 房间Service接口
 */
public interface RoomService extends IService<Room> {

    /**
     * 分页查询房间列表
     */
    Page<RoomVO> getRoomPage(Integer pageNum, Integer pageSize, Long buildingId, Integer floor, Integer status);

    /**
     * 获取房间详情
     */
    RoomVO getRoomDetail(Long id);

    /**
     * 获取指定楼栋的房间列表
     */
    List<RoomVO> getRoomsByBuilding(Long buildingId);

    /**
     * 新增房间
     */
    void addRoom(Room room);

    /**
     * 更新房间信息
     */
    void updateRoom(Room room);

    /**
     * 删除房间
     */
    void deleteRoom(Long id);

    /**
     * 重新生成房间床位
     */
    void regenerateBeds(Long roomId);

    /**
     * 获取房间的床位列表
     */
    List<BedVO> getRoomBeds(Long roomId);
}
