package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.Building;
import com.sushe.system.vo.BuildingVO;

import java.util.List;

/**
 * 宿舍楼Service接口
 */
public interface BuildingService extends IService<Building> {

    /**
     * 分页查询宿舍楼列表
     */
    Page<BuildingVO> getBuildingPage(Integer pageNum, Integer pageSize, String keyword);

    /**
     * 获取所有宿舍楼列表
     */
    List<BuildingVO> getAllBuildings();

    /**
     * 获取宿舍楼详情
     */
    BuildingVO getBuildingDetail(Long id);

    /**
     * 新增宿舍楼
     */
    void addBuilding(Building building);

    /**
     * 更新宿舍楼信息
     */
    void updateBuilding(Building building);

    /**
     * 删除宿舍楼
     */
    void deleteBuilding(Long id);
}
