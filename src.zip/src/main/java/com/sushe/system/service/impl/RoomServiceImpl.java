package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.Bed;
import com.sushe.system.entity.Building;
import com.sushe.system.entity.Room;
import com.sushe.system.entity.User;
import com.sushe.system.mapper.BedMapper;
import com.sushe.system.mapper.BuildingMapper;
import com.sushe.system.mapper.RoomMapper;
import com.sushe.system.mapper.UserMapper;
import com.sushe.system.service.RoomService;
import com.sushe.system.vo.BedVO;
import com.sushe.system.vo.RoomVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.sushe.system.common.BusinessException;

import java.util.List;

/**
 * 房间Service实现类
 */
@Service
@RequiredArgsConstructor
public class RoomServiceImpl extends ServiceImpl<RoomMapper, Room> implements RoomService {

    private final BuildingMapper buildingMapper;
    private final BedMapper bedMapper;
    private final UserMapper userMapper;

    @Override
    public Page<RoomVO> getRoomPage(Integer pageNum, Integer pageSize, Long buildingId, Integer floor, Integer status) {
        Page<Room> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Room> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(Room::getBuildingId, buildingId);
        }
        if (floor != null) {
            wrapper.eq(Room::getFloor, floor);
        }
        if (status != null) {
            wrapper.eq(Room::getStatus, status);
        }
        wrapper.orderByAsc(Room::getRoomNumber);

        Page<Room> roomPage = this.page(page, wrapper);

        // 转换为VO
        Page<RoomVO> voPage = new Page<>(roomPage.getCurrent(), roomPage.getSize(), roomPage.getTotal());
        voPage.setRecords(roomPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public RoomVO getRoomDetail(Long id) {
        Room room = this.getById(id);
        if (room == null) {
            throw new BusinessException("房间不存在");
        }

        RoomVO vo = convertToVO(room);

        // 获取床位信息，如果没有床位则自动创建
        List<Bed> beds = bedMapper.selectList(new LambdaQueryWrapper<Bed>()
            .eq(Bed::getRoomId, id)
            .orderByAsc(Bed::getBedNumber));

        if (beds.isEmpty() && room.getBedCount() != null && room.getBedCount() > 0) {
            // 自动创建床位
            for (int i = 1; i <= room.getBedCount(); i++) {
                Bed bed = new Bed();
                bed.setRoomId(id);
                bed.setBedNumber(i);
                bed.setPosition(i <= room.getBedCount() / 2 ? "上铺" : "下铺");
                bed.setStatus(0);
                bed.setDeleted(0);
                bedMapper.insert(bed);
            }
            // 重新查询床位
            beds = bedMapper.selectList(new LambdaQueryWrapper<Bed>()
                .eq(Bed::getRoomId, id)
                .orderByAsc(Bed::getBedNumber));
        }

        List<BedVO> bedVOs = beds.stream().map(bed -> {
            BedVO bedVO = new BedVO();
            BeanUtil.copyProperties(bed, bedVO);

            // 设置状态名称
            switch (bed.getStatus()) {
                case 0 -> bedVO.setStatusName("空闲");
                case 1 -> bedVO.setStatusName("已分配");
                case 2 -> bedVO.setStatusName("维修中");
            }

            // 获取学生信息
            if (bed.getStudentId() != null) {
                User student = userMapper.selectById(bed.getStudentId());
                if (student != null) {
                    bedVO.setStudentName(student.getRealName());
                    bedVO.setStudentCode(student.getUserCode());
                }
            }

            return bedVO;
        }).toList();

        vo.setBeds(bedVOs);

        return vo;
    }

    @Override
    public List<RoomVO> getRoomsByBuilding(Long buildingId) {
        List<Room> rooms = this.list(new LambdaQueryWrapper<Room>()
            .eq(Room::getBuildingId, buildingId)
            .eq(Room::getStatus, 1)
            .orderByAsc(Room::getRoomNumber));
        return rooms.stream().map(this::convertToVO).toList();
    }

    @Override
    public void addRoom(Room room) {
        // 检查房间号是否重复
        long count = this.count(new LambdaQueryWrapper<Room>()
            .eq(Room::getBuildingId, room.getBuildingId())
            .eq(Room::getRoomNumber, room.getRoomNumber()));
        if (count > 0) {
            throw new BusinessException("该楼栋已存在相同房间号");
        }

        // 如果楼层未设置，根据房间号自动计算楼层
        if (room.getFloor() == null && room.getRoomNumber() != null) {
            room.setFloor(parseFloorFromRoomNumber(room.getRoomNumber()));
        }

        room.setOccupiedCount(0);
        room.setStatus(1);
        room.setDeleted(0);
        this.save(room);

        // 创建床位
        for (int i = 1; i <= room.getBedCount(); i++) {
            Bed bed = new Bed();
            bed.setRoomId(room.getId());
            bed.setBedNumber(i);
            bed.setPosition(i <= room.getBedCount() / 2 ? "上铺" : "下铺");
            bed.setStatus(0);
            bed.setDeleted(0);
            bedMapper.insert(bed);
        }
    }

    @Override
    public void updateRoom(Room room) {
        Room existing = this.getById(room.getId());
        if (existing == null) {
            throw new BusinessException("房间不存在");
        }

        // 如果楼层未设置，根据房间号自动计算楼层
        if (room.getFloor() == null && room.getRoomNumber() != null) {
            room.setFloor(parseFloorFromRoomNumber(room.getRoomNumber()));
        }

        this.updateById(room);
    }

    @Override
    public void deleteRoom(Long id) {
        Room room = this.getById(id);
        if (room == null) {
            throw new BusinessException("房间不存在");
        }

        if (room.getOccupiedCount() > 0) {
            throw new BusinessException("该房间还有学生入住，无法删除");
        }

        this.removeById(id);

        // 删除相关床位
        bedMapper.delete(new LambdaQueryWrapper<Bed>()
            .eq(Bed::getRoomId, id));
    }

    @Override
    public void regenerateBeds(Long roomId) {
        Room room = this.getById(roomId);
        if (room == null) {
            throw new BusinessException("房间不存在");
        }

        // 删除现有床位
        bedMapper.delete(new LambdaQueryWrapper<Bed>()
            .eq(Bed::getRoomId, roomId));

        // 重新创建床位
        for (int i = 1; i <= room.getBedCount(); i++) {
            Bed bed = new Bed();
            bed.setRoomId(roomId);
            bed.setBedNumber(i);
            bed.setPosition(i <= room.getBedCount() / 2 ? "上铺" : "下铺");
            bed.setStatus(0);
            bed.setDeleted(0);
            bedMapper.insert(bed);
        }
    }

    @Override
    public List<BedVO> getRoomBeds(Long roomId) {
        List<Bed> beds = bedMapper.selectList(new LambdaQueryWrapper<Bed>()
            .eq(Bed::getRoomId, roomId)
            .eq(Bed::getDeleted, 0)
            .orderByAsc(Bed::getBedNumber));

        return beds.stream().map(bed -> {
            BedVO bedVO = new BedVO();
            BeanUtil.copyProperties(bed, bedVO);

            switch (bed.getStatus()) {
                case 0 -> bedVO.setStatusName("空闲");
                case 1 -> bedVO.setStatusName("已分配");
                case 2 -> bedVO.setStatusName("维修中");
                default -> bedVO.setStatusName("未知");
            }

            if (bed.getStudentId() != null) {
                User student = userMapper.selectById(bed.getStudentId());
                if (student != null) {
                    bedVO.setStudentName(student.getRealName());
                    bedVO.setStudentCode(student.getUserCode());
                }
            }

            return bedVO;
        }).toList();
    }

    /**
     * 根据房间号解析楼层
     * 例如：318 → 3楼，102 → 1楼，18 → 1楼
     */
    private int parseFloorFromRoomNumber(String roomNumber) {
        String numStr = roomNumber.replaceAll("[^0-9]", "");
        if (numStr.isEmpty()) {
            return 1;
        }
        if (numStr.length() >= 3) {
            return Integer.parseInt(numStr.substring(0, 1));
        } else {
            return Integer.parseInt(numStr.substring(0, 1));
        }
    }

    /**
     * 转换为VO
     */
    private RoomVO convertToVO(Room room) {
        RoomVO vo = new RoomVO();
        BeanUtil.copyProperties(room, vo);

        // 设置楼栋名称
        Building building = buildingMapper.selectById(room.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        // 设置房间类型名称
        switch (room.getRoomType()) {
            case 1 -> vo.setRoomTypeName("四人间");
            case 2 -> vo.setRoomTypeName("六人间");
            case 3 -> vo.setRoomTypeName("八人间");
            case 4 -> vo.setRoomTypeName("单人间");
            default -> vo.setRoomTypeName("未知");
        }

        // 设置状态名称
        switch (room.getStatus()) {
            case 0 -> vo.setStatusName("空闲");
            case 1 -> vo.setStatusName("正常");
            case 2 -> vo.setStatusName("维修中");
            case 3 -> vo.setStatusName("已满");
            default -> vo.setStatusName("未知");
        }

        return vo;
    }
}
