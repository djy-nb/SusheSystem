package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.CheckIn;
import com.sushe.system.vo.CheckInVO;

/**
 * 入住记录Service接口
 */
public interface CheckInService extends IService<CheckIn> {

    /**
     * 统计在住学生人数（status=1）
     */
    long countCheckedIn();

    /**
     * 分页查询入住记录
     */
    Page<CheckInVO> getCheckInPage(Integer pageNum, Integer pageSize, Long buildingId, Long roomId, Integer status);

    /**
     * 学生入住
     */
    void checkIn(CheckIn checkIn);

    /**
     * 学生退宿
     */
    void checkOut(Long id);

    /**
     * 调宿
     */
    void changeRoom(Long id, Long newRoomId, Long newBedId);
}
