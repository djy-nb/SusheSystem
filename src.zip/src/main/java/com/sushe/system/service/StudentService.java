package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.dto.StudentDTO;
import com.sushe.system.entity.User;
import com.sushe.system.vo.StudentVO;

/**
 * 学生Service接口
 */
public interface StudentService extends IService<User> {

    /**
     * 分页查询学生列表
     */
    Page<StudentVO> getStudentPage(
            Integer pageNum,
            Integer pageSize,
            String studentNo,
            String name,
            Long buildingId,
            Long roomId,
            Integer status
    );

    /**
     * 获取学生详情
     */
    StudentVO getStudentDetail(Long id);

    /**
     * 新增学生
     */
    void addStudent(StudentDTO studentDTO);

    /**
     * 更新学生信息
     */
    void updateStudent(StudentDTO studentDTO);

    /**
     * 删除学生
     */
    void deleteStudent(Long id);

    /**
     * 重置学生密码
     */
    void resetStudentPassword(Long id);

    /**
     * 更新学生状态
     */
    void updateStudentStatus(Long id, Integer status);
}
