package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.vo.*;

import java.util.List;

/**
 * 辅导员Service接口
 */
public interface CounselorService {

    /**
     * 获取辅导员首页统计数据
     */
    CounselorVO getCounselorStatistics();

    /**
     * 分页查询所辖学生的住宿信息
     */
    Page<CheckInVO> getCounselorStudents(Integer pageNum, Integer pageSize, String keyword);

    /**
     * 分页查询所辖学生的报修工单
     */
    Page<RepairVO> getCounselorRepairs(Integer pageNum, Integer pageSize, Integer status);

    /**
     * 分页查询所辖学生的卫生检查记录
     */
    Page<HygieneCheckVO> getCounselorHygiene(Integer pageNum, Integer pageSize, String grade);

    /**
     * 分页查询所辖学生的门禁记录
     */
    Page<AccessRecordVO> getCounselorAccess(Integer pageNum, Integer pageSize, Integer direction);
}
