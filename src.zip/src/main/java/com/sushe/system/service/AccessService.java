package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.AccessRecord;
import com.sushe.system.vo.AccessRecordVO;
import com.sushe.system.vo.AccessStatisticsVO;

import java.time.LocalDate;
import java.util.List;

/**
 * 门禁Service接口
 */
public interface AccessService extends IService<AccessRecord> {

    /**
     * 分页查询门禁记录
     */
    Page<AccessRecordVO> getAccessPage(Integer pageNum, Integer pageSize, Long buildingId, Long userId,
                                        Integer direction, Integer verifyResult, LocalDate startDate, LocalDate endDate);

    /**
     * 添加门禁记录
     */
    void addAccessRecord(AccessRecord record);

    /**
     * 获取门禁统计
     */
    AccessStatisticsVO getAccessStatistics(Long buildingId, LocalDate date);

    /**
     * 获取每日进出趋势
     */
    List<AccessStatisticsVO> getDailyTrend(Long buildingId, LocalDate startDate, LocalDate endDate);

    /**
     * 获取异常记录
     */
    Page<AccessRecordVO> getAbnormalRecords(Integer pageNum, Integer pageSize, Long buildingId);
}
