package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.Notice;
import com.sushe.system.mapper.NoticeMapper;
import com.sushe.system.security.LoginUser;
import com.sushe.system.service.NoticeService;
import com.sushe.system.vo.NoticeVO;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.sushe.system.common.BusinessException;

import java.time.LocalDateTime;

/**
 * 通知公告Service实现类
 */
@Service
@RequiredArgsConstructor
public class NoticeServiceImpl extends ServiceImpl<NoticeMapper, Notice> implements NoticeService {

    @Override
    public Page<NoticeVO> getNoticePage(Integer pageNum, Integer pageSize, Integer type, Integer status) {
        Page<Notice> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Notice> wrapper = new LambdaQueryWrapper<>();

        if (type != null) {
            wrapper.eq(Notice::getType, type);
        }
        if (status != null) {
            wrapper.eq(Notice::getStatus, status);
        }
        wrapper.orderByDesc(Notice::getIsTop).orderByDesc(Notice::getCreateTime);

        Page<Notice> noticePage = this.page(page, wrapper);

        // 转换为VO
        Page<NoticeVO> voPage = new Page<>(noticePage.getCurrent(), noticePage.getSize(), noticePage.getTotal());
        voPage.setRecords(noticePage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public NoticeVO getNoticeDetail(Long id) {
        Notice notice = this.getById(id);
        if (notice == null) {
            throw new BusinessException("通知不存在");
        }

        // 增加阅读数
        notice.setReadCount(notice.getReadCount() + 1);
        this.updateById(notice);

        return convertToVO(notice);
    }

    @Override
    public void publishNotice(Notice notice) {
        // 获取当前登录用户
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        LoginUser loginUser = (LoginUser) authentication.getPrincipal();

        notice.setPublisherId(loginUser.getUserId());
        notice.setPublisherName(loginUser.getUsername());
        notice.setStatus(1); // 已发布
        notice.setPublishTime(LocalDateTime.now());
        notice.setReadCount(0);
        notice.setDeleted(0);
        this.save(notice);
    }

    @Override
    public void updateNotice(Notice notice) {
        Notice existing = this.getById(notice.getId());
        if (existing == null) {
            throw new BusinessException("通知不存在");
        }
        this.updateById(notice);
    }

    @Override
    public void deleteNotice(Long id) {
        Notice notice = this.getById(id);
        if (notice == null) {
            throw new BusinessException("通知不存在");
        }
        this.removeById(id);
    }

    @Override
    public void withdrawNotice(Long id) {
        Notice notice = this.getById(id);
        if (notice == null) {
            throw new BusinessException("通知不存在");
        }

        notice.setStatus(2); // 已撤回
        this.updateById(notice);
    }

    /**
     * 转换为VO
     */
    private NoticeVO convertToVO(Notice notice) {
        NoticeVO vo = new NoticeVO();
        BeanUtil.copyProperties(notice, vo);

        // 设置类型名称
        switch (notice.getType()) {
            case 1 -> vo.setTypeName("系统通知");
            case 2 -> vo.setTypeName("楼栋通知");
            case 3 -> vo.setTypeName("宿舍通知");
            case 4 -> vo.setTypeName("活动通知");
            default -> vo.setTypeName("未知");
        }

        // 设置优先级名称
        switch (notice.getPriority()) {
            case 1 -> vo.setPriorityName("普通");
            case 2 -> vo.setPriorityName("重要");
            case 3 -> vo.setPriorityName("紧急");
            default -> vo.setPriorityName("未知");
        }

        // 设置目标范围名称
        switch (notice.getTargetRange()) {
            case 0 -> vo.setTargetRangeName("全部");
            case 1 -> vo.setTargetRangeName("指定楼栋");
            case 2 -> vo.setTargetRangeName("指定房间");
            default -> vo.setTargetRangeName("未知");
        }

        // 设置状态名称
        switch (notice.getStatus()) {
            case 0 -> vo.setStatusName("草稿");
            case 1 -> vo.setStatusName("已发布");
            case 2 -> vo.setStatusName("已撤回");
            default -> vo.setStatusName("未知");
        }

        return vo;
    }
}
