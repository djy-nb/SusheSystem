package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.common.BusinessException;
import com.sushe.system.entity.Building;
import com.sushe.system.entity.Repair;
import com.sushe.system.entity.Room;
import com.sushe.system.entity.User;
import com.sushe.system.mapper.BuildingMapper;
import com.sushe.system.mapper.RepairMapper;
import com.sushe.system.mapper.RoomMapper;
import com.sushe.system.mapper.UserMapper;
import com.sushe.system.security.LoginUser;
import com.sushe.system.service.RepairService;
import com.sushe.system.vo.RepairVO;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * 报修Service实现类
 */
@Service
@RequiredArgsConstructor
public class RepairServiceImpl extends ServiceImpl<RepairMapper, Repair> implements RepairService {

    private final UserMapper userMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;

    @Override
    public Page<RepairVO> getRepairPage(Integer pageNum, Integer pageSize, Integer status, Integer repairType) {
        Page<Repair> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Repair> wrapper = new LambdaQueryWrapper<>();

        // 安全：学生只能查看自己的报修工单
        LoginUser loginUser = getCurrentLoginUser();
        if ("STUDENT".equals(loginUser.getRole())) {
            wrapper.eq(Repair::getUserId, loginUser.getUserId());
        }

        if (status != null) {
            wrapper.eq(Repair::getStatus, status);
        }
        if (repairType != null) {
            wrapper.eq(Repair::getRepairType, repairType);
        }
        wrapper.orderByDesc(Repair::getCreateTime);

        Page<Repair> repairPage = this.page(page, wrapper);

        // 转换为VO
        Page<RepairVO> voPage = new Page<>(repairPage.getCurrent(), repairPage.getSize(), repairPage.getTotal());
        voPage.setRecords(repairPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public RepairVO getRepairDetail(Long id) {
        Repair repair = this.getById(id);
        if (repair == null) {
            throw new BusinessException("报修工单不存在");
        }
        return convertToVO(repair);
    }

    @Override
    public void submitRepair(Repair repair) {
        // 生成工单编号
        repair.setOrderNo("RX" + System.currentTimeMillis());
        repair.setStatus(0); // 待处理
        repair.setPriority(2); // 默认中等优先级
        this.save(repair);
    }

    @Override
    public void assignRepair(Long id, Long repairerId) {
        Repair repair = this.getById(id);
        if (repair == null) {
            throw new BusinessException("报修工单不存在");
        }

        User repairer = userMapper.selectById(repairerId);
        if (repairer == null) {
            throw new BusinessException("维修人员不存在");
        }

        repair.setStatus(1); // 已派单
        repair.setRepairerId(repairerId);
        repair.setRepairerName(repairer.getRealName());
        this.updateById(repair);
    }

    @Override
    public void startRepair(Long id) {
        Repair repair = this.getById(id);
        if (repair == null) {
            throw new BusinessException("报修工单不存在");
        }

        repair.setStatus(2); // 维修中
        repair.setStartTime(LocalDateTime.now());
        this.updateById(repair);
    }

    @Override
    public void completeRepair(Long id, String result) {
        Repair repair = this.getById(id);
        if (repair == null) {
            throw new BusinessException("报修工单不存在");
        }

        repair.setStatus(3); // 已完成
        repair.setResult(result);
        repair.setCompleteTime(LocalDateTime.now());
        this.updateById(repair);
    }

    @Override
    public void evaluateRepair(Long id, Integer rating, String comment) {
        Repair repair = this.getById(id);
        if (repair == null) {
            throw new BusinessException("报修工单不存在");
        }

        // 安全：学生只能评价自己的工单
        LoginUser loginUser = getCurrentLoginUser();
        if ("STUDENT".equals(loginUser.getRole()) && !repair.getUserId().equals(loginUser.getUserId())) {
            throw new BusinessException("无权评价他人的报修工单");
        }

        repair.setStatus(4); // 已评价
        repair.setRating(rating);
        repair.setComment(comment);
        this.updateById(repair);
    }

    /**
     * 获取当前登录用户
     */
    private LoginUser getCurrentLoginUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new BusinessException("用户未登录");
        }
        return (LoginUser) authentication.getPrincipal();
    }

    /**
     * 转换为VO
     */
    private RepairVO convertToVO(Repair repair) {
        RepairVO vo = new RepairVO();
        BeanUtil.copyProperties(repair, vo);

        // 获取报修人信息
        User user = userMapper.selectById(repair.getUserId());
        if (user != null) {
            vo.setUserName(user.getRealName());
        }

        // 获取房间信息
        Room room = roomMapper.selectById(repair.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        // 获取楼栋信息
        Building building = buildingMapper.selectById(repair.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        // 设置报修类型名称
        switch (repair.getRepairType()) {
            case 1 -> vo.setRepairTypeName("水电维修");
            case 2 -> vo.setRepairTypeName("家具维修");
            case 3 -> vo.setRepairTypeName("门窗维修");
            case 4 -> vo.setRepairTypeName("网络故障");
            case 5 -> vo.setRepairTypeName("其他");
            default -> vo.setRepairTypeName("未知");
        }

        // 设置优先级名称
        switch (repair.getPriority()) {
            case 1 -> vo.setPriorityName("低");
            case 2 -> vo.setPriorityName("中");
            case 3 -> vo.setPriorityName("高");
            case 4 -> vo.setPriorityName("紧急");
            default -> vo.setPriorityName("未知");
        }

        // 设置状态名称
        switch (repair.getStatus()) {
            case 0 -> vo.setStatusName("待处理");
            case 1 -> vo.setStatusName("已派单");
            case 2 -> vo.setStatusName("维修中");
            case 3 -> vo.setStatusName("已完成");
            case 4 -> vo.setStatusName("已评价");
            case 5 -> vo.setStatusName("已取消");
            default -> vo.setStatusName("未知");
        }

        return vo;
    }
}
