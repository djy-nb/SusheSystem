package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.Notice;
import com.sushe.system.vo.NoticeVO;

/**
 * 通知公告Service接口
 */
public interface NoticeService extends IService<Notice> {

    /**
     * 分页查询通知公告
     */
    Page<NoticeVO> getNoticePage(Integer pageNum, Integer pageSize, Integer type, Integer status);

    /**
     * 获取通知详情
     */
    NoticeVO getNoticeDetail(Long id);

    /**
     * 发布通知
     */
    void publishNotice(Notice notice);

    /**
     * 更新通知
     */
    void updateNotice(Notice notice);

    /**
     * 删除通知
     */
    void deleteNotice(Long id);

    /**
     * 撤回通知
     */
    void withdrawNotice(Long id);
}
