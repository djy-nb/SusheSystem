package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.AccessRecord;
import com.sushe.system.entity.Building;
import com.sushe.system.entity.User;
import com.sushe.system.mapper.AccessRecordMapper;
import com.sushe.system.mapper.BuildingMapper;
import com.sushe.system.mapper.UserMapper;
import com.sushe.system.service.AccessService;
import com.sushe.system.vo.AccessRecordVO;
import com.sushe.system.vo.AccessStatisticsVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 门禁Service实现类
 */
@Service
@RequiredArgsConstructor
public class AccessServiceImpl extends ServiceImpl<AccessRecordMapper, AccessRecord> implements AccessService {

    private final UserMapper userMapper;
    private final BuildingMapper buildingMapper;

    @Override
    public Page<AccessRecordVO> getAccessPage(Integer pageNum, Integer pageSize, Long buildingId, Long userId,
                                               Integer direction, Integer verifyResult, LocalDate startDate, LocalDate endDate) {
        Page<AccessRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<AccessRecord> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(AccessRecord::getBuildingId, buildingId);
        }
        if (userId != null) {
            wrapper.eq(AccessRecord::getUserId, userId);
        }
        if (direction != null) {
            wrapper.eq(AccessRecord::getDirection, direction);
        }
        if (verifyResult != null) {
            wrapper.eq(AccessRecord::getVerifyResult, verifyResult);
        }
        if (startDate != null) {
            wrapper.ge(AccessRecord::getPassTime, startDate.atStartOfDay());
        }
        if (endDate != null) {
            wrapper.le(AccessRecord::getPassTime, endDate.plusDays(1).atStartOfDay());
        }
        wrapper.orderByDesc(AccessRecord::getPassTime);

        Page<AccessRecord> accessPage = this.page(page, wrapper);

        // 转换为VO
        Page<AccessRecordVO> voPage = new Page<>(accessPage.getCurrent(), accessPage.getSize(), accessPage.getTotal());
        voPage.setRecords(accessPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public void addAccessRecord(AccessRecord record) {
        // 检查体温是否异常
        if (record.getTemperature() != null && record.getTemperature() > 37.3) {
            record.setVerifyResult(0); // 体温异常不允许进入
            record.setFailReason("体温异常: " + record.getTemperature() + "°C");
        }

        this.save(record);
    }

    @Override
    public AccessStatisticsVO getAccessStatistics(Long buildingId, LocalDate date) {
        LambdaQueryWrapper<AccessRecord> wrapper = new LambdaQueryWrapper<>();
        if (buildingId != null) {
            wrapper.eq(AccessRecord::getBuildingId, buildingId);
        }
        wrapper.ge(AccessRecord::getPassTime, date.atStartOfDay());
        wrapper.lt(AccessRecord::getPassTime, date.plusDays(1).atStartOfDay());

        List<AccessRecord> records = this.list(wrapper);
        AccessStatisticsVO statistics = new AccessStatisticsVO();
        statistics.setDate(date);

        // 统计进入人数
        statistics.setEnterCount((int) records.stream()
            .filter(r -> r.getDirection() == 1)
            .count());

        // 统计离开人数
        statistics.setLeaveCount((int) records.stream()
            .filter(r -> r.getDirection() == 2)
            .count());

        // 总通行次数
        statistics.setTotalCount(records.size());

        // 验证成功次数
        statistics.setSuccessCount((int) records.stream()
            .filter(r -> r.getVerifyResult() == 1)
            .count());

        // 验证失败次数
        statistics.setFailCount(records.size() - statistics.getSuccessCount());

        // 成功率
        if (records.size() > 0) {
            statistics.setSuccessRate(statistics.getSuccessCount() * 100.0 / records.size());
        } else {
            statistics.setSuccessRate(0.0);
        }

        // 异常体温人数
        statistics.setAbnormalTemperatureCount((int) records.stream()
            .filter(r -> r.getTemperature() != null && r.getTemperature() > 37.3)
            .count());

        return statistics;
    }

    @Override
    public List<AccessStatisticsVO> getDailyTrend(Long buildingId, LocalDate startDate, LocalDate endDate) {
        List<AccessStatisticsVO> trend = new ArrayList<>();

        LocalDate currentDate = startDate;
        while (!currentDate.isAfter(endDate)) {
            trend.add(getAccessStatistics(buildingId, currentDate));
            currentDate = currentDate.plusDays(1);
        }

        return trend;
    }

    @Override
    public Page<AccessRecordVO> getAbnormalRecords(Integer pageNum, Integer pageSize, Long buildingId) {
        Page<AccessRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<AccessRecord> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(AccessRecord::getBuildingId, buildingId);
        }
        wrapper.eq(AccessRecord::getVerifyResult, 0);
        wrapper.orderByDesc(AccessRecord::getPassTime);

        Page<AccessRecord> accessPage = this.page(page, wrapper);

        // 转换为VO
        Page<AccessRecordVO> voPage = new Page<>(accessPage.getCurrent(), accessPage.getSize(), accessPage.getTotal());
        voPage.setRecords(accessPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    /**
     * 转换为VO
     */
    private AccessRecordVO convertToVO(AccessRecord record) {
        AccessRecordVO vo = new AccessRecordVO();
        BeanUtil.copyProperties(record, vo);

        // 获取用户信息
        User user = userMapper.selectById(record.getUserId());
        if (user != null) {
            vo.setUserName(user.getRealName());
            vo.setUserCode(user.getUserCode());
        }

        // 获取楼栋信息
        Building building = buildingMapper.selectById(record.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        // 设置通行方向名称
        vo.setDirectionName(record.getDirection() == 1 ? "进入" : "离开");

        // 设置验证方式名称
        switch (record.getVerifyType()) {
            case 1 -> vo.setVerifyTypeName("人脸识别");
            case 2 -> vo.setVerifyTypeName("刷卡");
            case 3 -> vo.setVerifyTypeName("密码");
            case 4 -> vo.setVerifyTypeName("手机");
            default -> vo.setVerifyTypeName("未知");
        }

        // 设置验证结果名称
        vo.setVerifyResultName(record.getVerifyResult() == 1 ? "成功" : "失败");

        return vo;
    }
}
