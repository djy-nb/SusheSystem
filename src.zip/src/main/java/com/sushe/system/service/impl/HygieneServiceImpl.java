package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.Building;
import com.sushe.system.entity.HygieneCheck;
import com.sushe.system.entity.Room;
import com.sushe.system.mapper.BuildingMapper;
import com.sushe.system.mapper.HygieneCheckMapper;
import com.sushe.system.mapper.RoomMapper;
import com.sushe.system.service.HygieneService;
import com.sushe.system.vo.HygieneCheckVO;
import com.sushe.system.vo.HygieneStatisticsVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.sushe.system.common.BusinessException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 卫生检查Service实现类
 */
@Service
@RequiredArgsConstructor
public class HygieneServiceImpl extends ServiceImpl<HygieneCheckMapper, HygieneCheck> implements HygieneService {

    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;

    @Override
    public Page<HygieneCheckVO> getHygienePage(Integer pageNum, Integer pageSize, Long buildingId, Long roomId,
                                                Integer checkType, String grade, LocalDate startDate, LocalDate endDate) {
        Page<HygieneCheck> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<HygieneCheck> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(HygieneCheck::getBuildingId, buildingId);
        }
        if (roomId != null) {
            wrapper.eq(HygieneCheck::getRoomId, roomId);
        }
        if (checkType != null) {
            wrapper.eq(HygieneCheck::getCheckType, checkType);
        }
        if (grade != null) {
            wrapper.eq(HygieneCheck::getGrade, grade);
        }
        if (startDate != null) {
            wrapper.ge(HygieneCheck::getCheckDate, startDate);
        }
        if (endDate != null) {
            wrapper.le(HygieneCheck::getCheckDate, endDate);
        }
        wrapper.orderByDesc(HygieneCheck::getCheckDate);

        Page<HygieneCheck> hygienePage = this.page(page, wrapper);

        // 转换为VO
        Page<HygieneCheckVO> voPage = new Page<>(hygienePage.getCurrent(), hygienePage.getSize(), hygienePage.getTotal());
        voPage.setRecords(hygienePage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public HygieneCheckVO getHygieneDetail(Long id) {
        HygieneCheck check = this.getById(id);
        if (check == null) {
            throw new BusinessException("卫生检查记录不存在");
        }
        return convertToVO(check);
    }

    @Override
    public void submitCheck(HygieneCheck check) {
        // 计算等级
        check.setGrade(calculateGrade(check.getScore()));
        check.setRectificationStatus(0);
        this.save(check);
    }

    @Override
    public void updateCheck(HygieneCheck check) {
        HygieneCheck existing = this.getById(check.getId());
        if (existing == null) {
            throw new BusinessException("卫生检查记录不存在");
        }

        // 重新计算等级
        check.setGrade(calculateGrade(check.getScore()));
        this.updateById(check);
    }

    @Override
    public HygieneStatisticsVO getHygieneStatistics(Long buildingId, LocalDate startDate, LocalDate endDate) {
        LambdaQueryWrapper<HygieneCheck> wrapper = new LambdaQueryWrapper<>();
        if (buildingId != null) {
            wrapper.eq(HygieneCheck::getBuildingId, buildingId);
        }
        if (startDate != null) {
            wrapper.ge(HygieneCheck::getCheckDate, startDate);
        }
        if (endDate != null) {
            wrapper.le(HygieneCheck::getCheckDate, endDate);
        }

        List<HygieneCheck> checks = this.list(wrapper);
        HygieneStatisticsVO statistics = new HygieneStatisticsVO();

        if (checks.isEmpty()) {
            statistics.setCheckCount(0);
            statistics.setAverageScore(BigDecimal.ZERO);
            statistics.setExcellentRate(BigDecimal.ZERO);
            statistics.setPassRate(BigDecimal.ZERO);
            statistics.setFailCount(0);
            statistics.setContrabandCount(0);
            statistics.setPendingRectification(0);
            return statistics;
        }

        statistics.setCheckCount(checks.size());

        // 计算平均分
        BigDecimal totalScore = checks.stream()
            .map(c -> BigDecimal.valueOf(c.getScore()))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        statistics.setAverageScore(totalScore.divide(BigDecimal.valueOf(checks.size()), 2, RoundingMode.HALF_UP));

        // 计算优秀率
        long excellentCount = checks.stream()
            .filter(c -> "A".equals(c.getGrade()))
            .count();
        statistics.setExcellentRate(BigDecimal.valueOf(excellentCount * 100.0 / checks.size())
            .setScale(2, RoundingMode.HALF_UP));

        // 计算合格率
        long passCount = checks.stream()
            .filter(c -> !"D".equals(c.getGrade()))
            .count();
        statistics.setPassRate(BigDecimal.valueOf(passCount * 100.0 / checks.size())
            .setScale(2, RoundingMode.HALF_UP));

        // 不合格次数
        statistics.setFailCount((int) checks.stream()
            .filter(c -> "D".equals(c.getGrade()))
            .count());

        // 违禁品检出次数
        statistics.setContrabandCount((int) checks.stream()
            .filter(c -> c.getHasContraband() == 1)
            .count());

        // 待整改数量
        statistics.setPendingRectification((int) checks.stream()
            .filter(c -> c.getRectificationStatus() == 1)
            .count());

        return statistics;
    }

    @Override
    public List<HygieneStatisticsVO> getBuildingRanking(LocalDate startDate, LocalDate endDate) {
        // 获取所有楼栋
        List<Building> buildings = buildingMapper.selectList(new LambdaQueryWrapper<Building>()
            .eq(Building::getStatus, 1));

        List<HygieneStatisticsVO> ranking = new ArrayList<>();

        for (Building building : buildings) {
            HygieneStatisticsVO statistics = getHygieneStatistics(building.getId(), startDate, endDate);
            statistics.setBuildingId(building.getId());
            statistics.setBuildingName(building.getName());
            ranking.add(statistics);
        }

        // 按平均分排序
        ranking.sort((a, b) -> b.getAverageScore().compareTo(a.getAverageScore()));

        // 设置排名
        for (int i = 0; i < ranking.size(); i++) {
            ranking.get(i).setRanking(i + 1);
        }

        return ranking;
    }

    @Override
    public void submitRectification(Long id) {
        HygieneCheck check = this.getById(id);
        if (check == null) {
            throw new BusinessException("卫生检查记录不存在");
        }

        check.setRectificationStatus(2); // 已整改
        this.updateById(check);
    }

    @Override
    public void verifyRectification(Long id, Integer status) {
        HygieneCheck check = this.getById(id);
        if (check == null) {
            throw new BusinessException("卫生检查记录不存在");
        }

        check.setRectificationStatus(status); // 3-已验收
        this.updateById(check);
    }

    /**
     * 计算等级
     */
    private String calculateGrade(Integer score) {
        if (score >= 90) {
            return "A";
        } else if (score >= 80) {
            return "B";
        } else if (score >= 60) {
            return "C";
        } else {
            return "D";
        }
    }

    /**
     * 转换为VO
     */
    private HygieneCheckVO convertToVO(HygieneCheck check) {
        HygieneCheckVO vo = new HygieneCheckVO();
        BeanUtil.copyProperties(check, vo);

        // 获取房间信息
        Room room = roomMapper.selectById(check.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        // 获取楼栋信息
        Building building = buildingMapper.selectById(check.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        // 设置检查类型名称
        switch (check.getCheckType()) {
            case 1 -> vo.setCheckTypeName("日常检查");
            case 2 -> vo.setCheckTypeName("专项检查");
            case 3 -> vo.setCheckTypeName("突击检查");
            default -> vo.setCheckTypeName("未知");
        }

        // 设置整改状态名称
        switch (check.getRectificationStatus()) {
            case 0 -> vo.setRectificationStatusName("无需整改");
            case 1 -> vo.setRectificationStatusName("待整改");
            case 2 -> vo.setRectificationStatusName("已整改");
            case 3 -> vo.setRectificationStatusName("已验收");
            default -> vo.setRectificationStatusName("未知");
        }

        return vo;
    }
}
