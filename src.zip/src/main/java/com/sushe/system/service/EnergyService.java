package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.EnergyRecord;
import com.sushe.system.vo.EnergyRecordVO;
import com.sushe.system.vo.EnergyStatisticsVO;

import java.time.LocalDate;
import java.util.List;

/**
 * 能耗Service接口
 */
public interface EnergyService extends IService<EnergyRecord> {

    /**
     * 分页查询能耗记录
     */
    Page<EnergyRecordVO> getEnergyPage(Integer pageNum, Integer pageSize, Long buildingId, Long roomId,
                                        Integer energyType, LocalDate startDate, LocalDate endDate);

    /**
     * 获取能耗统计
     */
    EnergyStatisticsVO getEnergyStatistics(Long buildingId, Long roomId, LocalDate startDate, LocalDate endDate);

    /**
     * 获取每日能耗趋势
     */
    List<EnergyStatisticsVO> getDailyTrend(Long buildingId, Long roomId, LocalDate startDate, LocalDate endDate);

    /**
     * 添加能耗记录
     */
    void addEnergyRecord(EnergyRecord record);

    /**
     * 获取异常能耗记录
     */
    Page<EnergyRecordVO> getAbnormalRecords(Integer pageNum, Integer pageSize, Long buildingId);
}
