package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.Repair;
import com.sushe.system.vo.RepairVO;

/**
 * 报修Service接口
 */
public interface RepairService extends IService<Repair> {

    /**
     * 分页查询报修工单
     */
    Page<RepairVO> getRepairPage(Integer pageNum, Integer pageSize, Integer status, Integer repairType);

    /**
     * 获取报修详情
     */
    RepairVO getRepairDetail(Long id);

    /**
     * 提交报修
     */
    void submitRepair(Repair repair);

    /**
     * 派单
     */
    void assignRepair(Long id, Long repairerId);

    /**
     * 开始维修
     */
    void startRepair(Long id);

    /**
     * 完成维修
     */
    void completeRepair(Long id, String result);

    /**
     * 评价
     */
    void evaluateRepair(Long id, Integer rating, String comment);
}
