package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sushe.system.entity.*;
import com.sushe.system.mapper.*;
import com.sushe.system.security.LoginUser;
import com.sushe.system.service.CounselorService;
import com.sushe.system.vo.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.sushe.system.common.BusinessException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 辅导员Service实现类
 */
@Service
@RequiredArgsConstructor
public class CounselorServiceImpl implements CounselorService {

    private final UserMapper userMapper;
    private final CheckInMapper checkInMapper;
    private final RepairMapper repairMapper;
    private final HygieneCheckMapper hygieneCheckMapper;
    private final AccessRecordMapper accessRecordMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final BedMapper bedMapper;

    @Override
    public CounselorVO getCounselorStatistics() {
        User counselor = getCurrentUser();
        String college = counselor.getCollege();

        CounselorVO vo = new CounselorVO();
        vo.setCollegeName(college);
        vo.setCounselorName(counselor.getRealName());

        // 获取所辖学生ID列表
        List<Long> studentIds = getStudentIdsByCollege(college);
        if (studentIds.isEmpty()) {
            vo.setStudentCount(0L);
            vo.setCheckedInCount(0L);
            vo.setPendingRepairCount(0L);
            vo.setHygieneFailCount(0L);
            vo.setAbnormalAccessCount(0L);
            vo.setHygieneAvgScore(BigDecimal.ZERO);
            vo.setMonthlyRepairCount(0L);
            return vo;
        }

        // 学生总数
        vo.setStudentCount((long) studentIds.size());

        // 在住学生人数
        long checkedInCount = checkInMapper.selectCount(new LambdaQueryWrapper<CheckIn>()
            .in(CheckIn::getStudentId, studentIds)
            .eq(CheckIn::getStatus, 1));
        vo.setCheckedInCount(checkedInCount);

        // 待处理报修数
        long pendingRepairCount = repairMapper.selectCount(new LambdaQueryWrapper<Repair>()
            .in(Repair::getUserId, studentIds)
            .eq(Repair::getStatus, 0));
        vo.setPendingRepairCount(pendingRepairCount);

        // 获取所辖学生所在房间ID列表
        List<Long> roomIds = getRoomIdsByStudentIds(studentIds);

        // 卫生不合格房间数（D等级）
        if (!roomIds.isEmpty()) {
            long hygieneFailCount = hygieneCheckMapper.selectCount(new LambdaQueryWrapper<HygieneCheck>()
                .in(HygieneCheck::getRoomId, roomIds)
                .eq(HygieneCheck::getGrade, "D"));
            vo.setHygieneFailCount(hygieneFailCount);

            // 卫生平均分
            List<HygieneCheck> hygieneChecks = hygieneCheckMapper.selectList(new LambdaQueryWrapper<HygieneCheck>()
                .in(HygieneCheck::getRoomId, roomIds));
            if (!hygieneChecks.isEmpty()) {
                BigDecimal totalScore = hygieneChecks.stream()
                    .map(c -> BigDecimal.valueOf(c.getScore()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
                vo.setHygieneAvgScore(totalScore.divide(BigDecimal.valueOf(hygieneChecks.size()), 2, RoundingMode.HALF_UP));
            } else {
                vo.setHygieneAvgScore(BigDecimal.ZERO);
            }
        } else {
            vo.setHygieneFailCount(0L);
            vo.setHygieneAvgScore(BigDecimal.ZERO);
        }

        // 今日异常门禁数
        LocalDateTime todayStart = LocalDate.now().atStartOfDay();
        LocalDateTime todayEnd = LocalDate.now().plusDays(1).atStartOfDay();
        long abnormalAccessCount = accessRecordMapper.selectCount(new LambdaQueryWrapper<AccessRecord>()
            .in(AccessRecord::getUserId, studentIds)
            .eq(AccessRecord::getVerifyResult, 0)
            .ge(AccessRecord::getPassTime, todayStart)
            .lt(AccessRecord::getPassTime, todayEnd));
        vo.setAbnormalAccessCount(abnormalAccessCount);

        // 本月报修总数
        LocalDateTime monthStart = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        long monthlyRepairCount = repairMapper.selectCount(new LambdaQueryWrapper<Repair>()
            .in(Repair::getUserId, studentIds)
            .ge(Repair::getCreateTime, monthStart));
        vo.setMonthlyRepairCount(monthlyRepairCount);

        return vo;
    }

    @Override
    public Page<CheckInVO> getCounselorStudents(Integer pageNum, Integer pageSize, String keyword) {
        User counselor = getCurrentUser();
        String college = counselor.getCollege();

        // 获取所辖学生ID列表
        List<Long> studentIds = getStudentIdsByCollege(college);
        if (studentIds.isEmpty()) {
            return new Page<>(pageNum, pageSize);
        }

        // 如果有关键词搜索，进一步过滤学生ID
        if (StrUtil.isNotBlank(keyword)) {
            List<User> matchedStudents = userMapper.selectList(new LambdaQueryWrapper<User>()
                .in(User::getId, studentIds)
                .and(w -> w
                    .like(User::getRealName, keyword)
                    .or().like(User::getUserCode, keyword)
                    .or().like(User::getUsername, keyword)
                ));
            studentIds = matchedStudents.stream().map(User::getId).toList();
            if (studentIds.isEmpty()) {
                return new Page<>(pageNum, pageSize);
            }
        }

        // 查询入住记录
        Page<CheckIn> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<CheckIn> wrapper = new LambdaQueryWrapper<CheckIn>()
            .in(CheckIn::getStudentId, studentIds)
            .eq(CheckIn::getStatus, 1)
            .orderByDesc(CheckIn::getCreateTime);

        Page<CheckIn> checkInPage = checkInMapper.selectPage(page, wrapper);

        // 转换为VO
        Page<CheckInVO> voPage = new Page<>(checkInPage.getCurrent(), checkInPage.getSize(), checkInPage.getTotal());
        voPage.setRecords(checkInPage.getRecords().stream()
            .map(this::convertCheckInToVO)
            .toList());

        return voPage;
    }

    @Override
    public Page<RepairVO> getCounselorRepairs(Integer pageNum, Integer pageSize, Integer status) {
        User counselor = getCurrentUser();
        String college = counselor.getCollege();

        List<Long> studentIds = getStudentIdsByCollege(college);
        if (studentIds.isEmpty()) {
            return new Page<>(pageNum, pageSize);
        }

        Page<Repair> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Repair> wrapper = new LambdaQueryWrapper<Repair>()
            .in(Repair::getUserId, studentIds);

        if (status != null) {
            wrapper.eq(Repair::getStatus, status);
        }
        wrapper.orderByDesc(Repair::getCreateTime);

        Page<Repair> repairPage = repairMapper.selectPage(page, wrapper);

        Page<RepairVO> voPage = new Page<>(repairPage.getCurrent(), repairPage.getSize(), repairPage.getTotal());
        voPage.setRecords(repairPage.getRecords().stream()
            .map(this::convertRepairToVO)
            .toList());

        return voPage;
    }

    @Override
    public Page<HygieneCheckVO> getCounselorHygiene(Integer pageNum, Integer pageSize, String grade) {
        User counselor = getCurrentUser();
        String college = counselor.getCollege();

        List<Long> studentIds = getStudentIdsByCollege(college);
        if (studentIds.isEmpty()) {
            return new Page<>(pageNum, pageSize);
        }

        List<Long> roomIds = getRoomIdsByStudentIds(studentIds);
        if (roomIds.isEmpty()) {
            return new Page<>(pageNum, pageSize);
        }

        Page<HygieneCheck> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<HygieneCheck> wrapper = new LambdaQueryWrapper<HygieneCheck>()
            .in(HygieneCheck::getRoomId, roomIds);

        if (StrUtil.isNotBlank(grade)) {
            wrapper.eq(HygieneCheck::getGrade, grade);
        }
        wrapper.orderByDesc(HygieneCheck::getCheckDate);

        Page<HygieneCheck> hygienePage = hygieneCheckMapper.selectPage(page, wrapper);

        Page<HygieneCheckVO> voPage = new Page<>(hygienePage.getCurrent(), hygienePage.getSize(), hygienePage.getTotal());
        voPage.setRecords(hygienePage.getRecords().stream()
            .map(this::convertHygieneToVO)
            .toList());

        return voPage;
    }

    @Override
    public Page<AccessRecordVO> getCounselorAccess(Integer pageNum, Integer pageSize, Integer direction) {
        User counselor = getCurrentUser();
        String college = counselor.getCollege();

        List<Long> studentIds = getStudentIdsByCollege(college);
        if (studentIds.isEmpty()) {
            return new Page<>(pageNum, pageSize);
        }

        Page<AccessRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<AccessRecord> wrapper = new LambdaQueryWrapper<AccessRecord>()
            .in(AccessRecord::getUserId, studentIds);

        if (direction != null) {
            wrapper.eq(AccessRecord::getDirection, direction);
        }
        wrapper.orderByDesc(AccessRecord::getPassTime);

        Page<AccessRecord> accessPage = accessRecordMapper.selectPage(page, wrapper);

        Page<AccessRecordVO> voPage = new Page<>(accessPage.getCurrent(), accessPage.getSize(), accessPage.getTotal());
        voPage.setRecords(accessPage.getRecords().stream()
            .map(this::convertAccessToVO)
            .toList());

        return voPage;
    }

    /**
     * 获取当前登录用户
     */
    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new BusinessException("用户未登录");
        }
        LoginUser loginUser = (LoginUser) authentication.getPrincipal();
        User user = userMapper.selectById(loginUser.getUserId());
        if (user == null || StrUtil.isBlank(user.getCollege())) {
            throw new BusinessException("辅导员信息不完整，请联系管理员设置所属学院");
        }
        return user;
    }

    /**
     * 获取所辖学院的学生ID列表
     */
    private List<Long> getStudentIdsByCollege(String college) {
        List<User> students = userMapper.selectList(new LambdaQueryWrapper<User>()
            .eq(User::getRole, "STUDENT")
            .eq(User::getCollege, college)
            .eq(User::getStatus, 1));
        return students.stream().map(User::getId).toList();
    }

    /**
     * 获取学生所在的房间ID列表
     */
    private List<Long> getRoomIdsByStudentIds(List<Long> studentIds) {
        if (studentIds.isEmpty()) {
            return List.of();
        }
        List<CheckIn> checkIns = checkInMapper.selectList(new LambdaQueryWrapper<CheckIn>()
            .in(CheckIn::getStudentId, studentIds)
            .eq(CheckIn::getStatus, 1));
        return checkIns.stream().map(CheckIn::getRoomId).distinct().toList();
    }

    /**
     * 转换入住记录为VO
     */
    private CheckInVO convertCheckInToVO(CheckIn checkIn) {
        CheckInVO vo = new CheckInVO();
        BeanUtil.copyProperties(checkIn, vo);

        User student = userMapper.selectById(checkIn.getStudentId());
        if (student != null) {
            vo.setStudentName(student.getRealName());
            vo.setStudentCode(student.getUserCode());
        }

        Room room = roomMapper.selectById(checkIn.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        Building building = buildingMapper.selectById(checkIn.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        Bed bed = bedMapper.selectById(checkIn.getBedId());
        if (bed != null) {
            vo.setBedNumber(bed.getBedNumber());
        }

        vo.setStatusName(checkIn.getStatus() == 1 ? "在住" : "已退宿");

        switch (checkIn.getCheckInType()) {
            case 1 -> vo.setCheckInTypeName("正常入住");
            case 2 -> vo.setCheckInTypeName("调宿");
            case 3 -> vo.setCheckInTypeName("临时入住");
            default -> vo.setCheckInTypeName("未知");
        }

        return vo;
    }

    /**
     * 转换报修为VO
     */
    private RepairVO convertRepairToVO(Repair repair) {
        RepairVO vo = new RepairVO();
        BeanUtil.copyProperties(repair, vo);

        User user = userMapper.selectById(repair.getUserId());
        if (user != null) {
            vo.setUserName(user.getRealName());
        }

        Room room = roomMapper.selectById(repair.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        Building building = buildingMapper.selectById(repair.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        switch (repair.getRepairType()) {
            case 1 -> vo.setRepairTypeName("水电维修");
            case 2 -> vo.setRepairTypeName("家具维修");
            case 3 -> vo.setRepairTypeName("门窗维修");
            case 4 -> vo.setRepairTypeName("网络故障");
            case 5 -> vo.setRepairTypeName("其他");
            default -> vo.setRepairTypeName("未知");
        }

        switch (repair.getPriority()) {
            case 1 -> vo.setPriorityName("低");
            case 2 -> vo.setPriorityName("中");
            case 3 -> vo.setPriorityName("高");
            case 4 -> vo.setPriorityName("紧急");
            default -> vo.setPriorityName("未知");
        }

        switch (repair.getStatus()) {
            case 0 -> vo.setStatusName("待处理");
            case 1 -> vo.setStatusName("已派单");
            case 2 -> vo.setStatusName("维修中");
            case 3 -> vo.setStatusName("已完成");
            case 4 -> vo.setStatusName("已评价");
            case 5 -> vo.setStatusName("已取消");
            default -> vo.setStatusName("未知");
        }

        return vo;
    }

    /**
     * 转换卫生检查为VO
     */
    private HygieneCheckVO convertHygieneToVO(HygieneCheck check) {
        HygieneCheckVO vo = new HygieneCheckVO();
        BeanUtil.copyProperties(check, vo);

        Room room = roomMapper.selectById(check.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        Building building = buildingMapper.selectById(check.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        switch (check.getCheckType()) {
            case 1 -> vo.setCheckTypeName("日常检查");
            case 2 -> vo.setCheckTypeName("专项检查");
            case 3 -> vo.setCheckTypeName("突击检查");
            default -> vo.setCheckTypeName("未知");
        }

        switch (check.getRectificationStatus()) {
            case 0 -> vo.setRectificationStatusName("无需整改");
            case 1 -> vo.setRectificationStatusName("待整改");
            case 2 -> vo.setRectificationStatusName("已整改");
            case 3 -> vo.setRectificationStatusName("已验收");
            default -> vo.setRectificationStatusName("未知");
        }

        return vo;
    }

    /**
     * 转换门禁记录为VO
     */
    private AccessRecordVO convertAccessToVO(AccessRecord record) {
        AccessRecordVO vo = new AccessRecordVO();
        BeanUtil.copyProperties(record, vo);

        User user = userMapper.selectById(record.getUserId());
        if (user != null) {
            vo.setUserName(user.getRealName());
            vo.setUserCode(user.getUserCode());
        }

        Building building = buildingMapper.selectById(record.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        vo.setDirectionName(record.getDirection() == 1 ? "进入" : "离开");

        switch (record.getVerifyType()) {
            case 1 -> vo.setVerifyTypeName("人脸识别");
            case 2 -> vo.setVerifyTypeName("刷卡");
            case 3 -> vo.setVerifyTypeName("密码");
            case 4 -> vo.setVerifyTypeName("手机");
            default -> vo.setVerifyTypeName("未知");
        }

        vo.setVerifyResultName(record.getVerifyResult() == 1 ? "成功" : "失败");

        return vo;
    }
}
