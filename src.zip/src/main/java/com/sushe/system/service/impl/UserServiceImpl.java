package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.common.BusinessException;
import com.sushe.system.dto.LoginDTO;
import com.sushe.system.dto.UserDTO;
import com.sushe.system.entity.User;
import com.sushe.system.mapper.UserMapper;
import com.sushe.system.security.LoginRateLimiter;
import com.sushe.system.security.LoginUser;
import com.sushe.system.service.UserService;
import com.sushe.system.utils.JwtUtils;
import com.sushe.system.vo.LoginVO;
import com.sushe.system.vo.UserVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 用户Service实现类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    private final JwtUtils jwtUtils;
    private final PasswordEncoder passwordEncoder;
    private final LoginRateLimiter loginRateLimiter;

    @Value("${jwt.expiration:7200000}")
    private Long jwtExpiration;

    @Override
    public LoginVO login(LoginDTO loginDTO) {
        // 安全：检查登录频率限制（基于IP和用户名）
        String rateLimitError = loginRateLimiter.checkRateLimit(loginDTO.getClientIp(), loginDTO.getUsername());
        if (rateLimitError != null) {
            throw new BusinessException(rateLimitError);
        }

        // 查询用户
        User user = this.getOne(new LambdaQueryWrapper<User>()
            .eq(User::getUsername, loginDTO.getUsername()));

        if (user == null) {
            loginRateLimiter.recordFailure(loginDTO.getClientIp(), loginDTO.getUsername());
            throw new BusinessException("用户名或密码错误");
        }

        // 验证密码
        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            loginRateLimiter.recordFailure(loginDTO.getClientIp(), loginDTO.getUsername());
            throw new BusinessException("用户名或密码错误");
        }

        // 检查状态
        if (user.getStatus() == 0) {
            throw new BusinessException("账号已被禁用");
        }

        // 登录成功，清除失败记录
        loginRateLimiter.recordSuccess(loginDTO.getClientIp(), loginDTO.getUsername());

        // 生成Token
        String token = jwtUtils.generateToken(user.getId(), user.getUsername(), user.getRole());

        // 更新登录时间
        user.setLastLoginTime(LocalDateTime.now());
        this.updateById(user);

        // 构建返回结果
        LoginVO loginVO = new LoginVO();
        loginVO.setToken(token);
        loginVO.setExpiresIn(jwtExpiration / 1000);
        loginVO.setUserInfo(convertToVO(user));

        return loginVO;
    }

    @Override
    public void logout() {
        SecurityContextHolder.clearContext();
    }

    @Override
    public UserVO getCurrentUser() {
        LoginUser loginUser = getLoginUser();
        User user = this.getById(loginUser.getUserId());
        return convertToVO(user);
    }

    @Override
    @Transactional
    public void register(UserDTO userDTO) {
        // 检查用户名是否已存在
        long count = this.count(new LambdaQueryWrapper<User>()
            .eq(User::getUsername, userDTO.getUsername()));
        if (count > 0) {
            throw new BusinessException("用户名已存在");
        }

        // 创建用户
        User user = new User();
        BeanUtil.copyProperties(userDTO, user);
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setStatus(1);
        user.setDeleted(0);
        // 安全：注册用户强制为学生角色，防止通过请求体篡改角色
        user.setRole("STUDENT");
        this.save(user);
    }

    @Override
    public Page<UserVO> getUserPage(Integer pageNum, Integer pageSize, String keyword, String role) {
        Page<User> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();

        if (StrUtil.isNotBlank(keyword)) {
            wrapper.and(w -> w
                .like(User::getUsername, keyword)
                .or().like(User::getRealName, keyword)
                .or().like(User::getUserCode, keyword)
            );
        }
        if (StrUtil.isNotBlank(role)) {
            wrapper.eq(User::getRole, role);
        }
        wrapper.orderByDesc(User::getCreateTime);

        Page<User> userPage = this.page(page, wrapper);

        // 转换为VO
        Page<UserVO> voPage = new Page<>(userPage.getCurrent(), userPage.getSize(), userPage.getTotal());
        voPage.setRecords(userPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    @Transactional
    public void updateUser(UserDTO userDTO) {
        User user = this.getById(userDTO.getId());
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        BeanUtil.copyProperties(userDTO, user, "password", "deleted");
        this.updateById(user);
    }

    @Override
    public void changePassword(String oldPassword, String newPassword) {
        LoginUser loginUser = getLoginUser();
        User user = this.getById(loginUser.getUserId());

        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            throw new BusinessException("原密码错误");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        this.updateById(user);
    }

    @Override
    public void resetPassword(Long userId) {
        User user = this.getById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        // 安全：生成随机临时密码，而非固定弱密码
        String tempPassword = generateTempPassword();
        user.setPassword(passwordEncoder.encode(tempPassword));
        this.updateById(user);
        // TODO: 将临时密码通过短信/邮件发送给用户，并强制首次登录修改密码
        log.info("用户 {} 密码已重置，临时密码: {}", user.getUsername(), tempPassword);
    }

    @Override
    public void updateStatus(Long userId, Integer status) {
        User user = this.getById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        user.setStatus(status);
        this.updateById(user);
    }

    @Override
    @Transactional
    public void addUser(UserDTO userDTO) {
        // 检查用户名是否已存在
        long count = this.count(new LambdaQueryWrapper<User>()
            .eq(User::getUsername, userDTO.getUsername()));
        if (count > 0) {
            throw new BusinessException("用户名已存在");
        }

        // 检查学号/工号是否已存在
        if (StrUtil.isNotBlank(userDTO.getUserCode())) {
            long codeCount = this.count(new LambdaQueryWrapper<User>()
                .eq(User::getUserCode, userDTO.getUserCode()));
            if (codeCount > 0) {
                throw new BusinessException("学号/工号已存在");
            }
        }

        // 创建用户
        User user = new User();
        BeanUtil.copyProperties(userDTO, user);
        // 安全：生成随机临时密码，而非固定弱密码
        String tempPassword = generateTempPassword();
        user.setPassword(passwordEncoder.encode(tempPassword));
        user.setStatus(1);
        user.setDeleted(0);
        this.save(user);
        log.info("新增用户 {}，临时密码: {}", user.getUsername(), tempPassword);
    }

    /**
     * 获取当前登录用户
     */
    private LoginUser getLoginUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new BusinessException("用户未登录");
        }
        return (LoginUser) authentication.getPrincipal();
    }

    /**
     * 转换为VO
     */
    private UserVO convertToVO(User user) {
        UserVO vo = new UserVO();
        BeanUtil.copyProperties(user, vo, "password");

        // 设置角色名称
        switch (user.getRole()) {
            case "ADMIN" -> vo.setRoleName("系统管理员");
            case "DORM_ADMIN" -> vo.setRoleName("宿管员");
            case "COUNSELOR" -> vo.setRoleName("辅导员");
            case "STUDENT" -> vo.setRoleName("学生");
            default -> vo.setRoleName("未知角色");
        }

        return vo;
    }

    /**
     * 生成8位随机临时密码（包含大小写字母和数字）
     */
    private String generateTempPassword() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
        StringBuilder sb = new StringBuilder(8);
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < 8; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }
}
