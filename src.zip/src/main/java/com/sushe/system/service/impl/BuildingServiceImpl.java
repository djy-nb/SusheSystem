package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.Building;
import com.sushe.system.entity.User;
import com.sushe.system.mapper.BuildingMapper;
import com.sushe.system.mapper.UserMapper;
import com.sushe.system.service.BuildingService;
import com.sushe.system.vo.BuildingVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.sushe.system.common.BusinessException;

import java.util.List;

/**
 * 宿舍楼Service实现类
 */
@Service
@RequiredArgsConstructor
public class BuildingServiceImpl extends ServiceImpl<BuildingMapper, Building> implements BuildingService {

    private final UserMapper userMapper;

    @Override
    public Page<BuildingVO> getBuildingPage(Integer pageNum, Integer pageSize, String keyword) {
        Page<Building> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Building> wrapper = new LambdaQueryWrapper<>();

        if (StrUtil.isNotBlank(keyword)) {
            wrapper.like(Building::getName, keyword)
                .or().like(Building::getCode, keyword);
        }
        wrapper.orderByDesc(Building::getCreateTime);

        Page<Building> buildingPage = this.page(page, wrapper);

        // 转换为VO
        Page<BuildingVO> voPage = new Page<>(buildingPage.getCurrent(), buildingPage.getSize(), buildingPage.getTotal());
        voPage.setRecords(buildingPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public List<BuildingVO> getAllBuildings() {
        List<Building> buildings = this.list(new LambdaQueryWrapper<Building>()
            .eq(Building::getStatus, 1)
            .orderByAsc(Building::getCode));
        return buildings.stream().map(this::convertToVO).toList();
    }

    @Override
    public BuildingVO getBuildingDetail(Long id) {
        Building building = this.getById(id);
        if (building == null) {
            throw new BusinessException("宿舍楼不存在");
        }
        return convertToVO(building);
    }

    @Override
    public void addBuilding(Building building) {
        // 检查编号是否重复
        long count = this.count(new LambdaQueryWrapper<Building>()
            .eq(Building::getCode, building.getCode()));
        if (count > 0) {
            throw new BusinessException("楼栋编号已存在");
        }

        building.setStatus(1);
        building.setDeleted(0);
        building.setOccupiedCount(0);
        this.save(building);
    }

    @Override
    public void updateBuilding(Building building) {
        Building existing = this.getById(building.getId());
        if (existing == null) {
            throw new BusinessException("宿舍楼不存在");
        }

        // 检查编号是否重复
        if (!existing.getCode().equals(building.getCode())) {
            long count = this.count(new LambdaQueryWrapper<Building>()
                .eq(Building::getCode, building.getCode()));
            if (count > 0) {
                throw new BusinessException("楼栋编号已存在");
            }
        }

        this.updateById(building);
    }

    @Override
    public void deleteBuilding(Long id) {
        Building building = this.getById(id);
        if (building == null) {
            throw new BusinessException("宿舍楼不存在");
        }

        if (building.getOccupiedCount() > 0) {
            throw new BusinessException("该楼栋还有学生入住，无法删除");
        }

        this.removeById(id);
    }

    /**
     * 转换为VO
     */
    private BuildingVO convertToVO(Building building) {
        BuildingVO vo = new BuildingVO();
        BeanUtil.copyProperties(building, vo);

        // 设置类型名称
        switch (building.getType()) {
            case 1 -> vo.setTypeName("男生宿舍");
            case 2 -> vo.setTypeName("女生宿舍");
            case 3 -> vo.setTypeName("混合宿舍");
            default -> vo.setTypeName("未知");
        }

        // 设置状态名称
        vo.setStatusName(building.getStatus() == 1 ? "正常" : "停用");

        // 获取宿管员姓名
        if (building.getAdminId() != null) {
            User admin = userMapper.selectById(building.getAdminId());
            if (admin != null) {
                vo.setAdminName(admin.getRealName());
            }
        }

        return vo;
    }
}
