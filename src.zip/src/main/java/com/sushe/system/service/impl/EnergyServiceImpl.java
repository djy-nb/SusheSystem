package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.Building;
import com.sushe.system.entity.EnergyRecord;
import com.sushe.system.entity.Room;
import com.sushe.system.mapper.BuildingMapper;
import com.sushe.system.mapper.EnergyRecordMapper;
import com.sushe.system.mapper.RoomMapper;
import com.sushe.system.service.EnergyService;
import com.sushe.system.vo.EnergyRecordVO;
import com.sushe.system.vo.EnergyStatisticsVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 能耗Service实现类
 */
@Service
@RequiredArgsConstructor
public class EnergyServiceImpl extends ServiceImpl<EnergyRecordMapper, EnergyRecord> implements EnergyService {

    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;

    @Override
    public Page<EnergyRecordVO> getEnergyPage(Integer pageNum, Integer pageSize, Long buildingId, Long roomId,
                                               Integer energyType, LocalDate startDate, LocalDate endDate) {
        Page<EnergyRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<EnergyRecord> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(EnergyRecord::getBuildingId, buildingId);
        }
        if (roomId != null) {
            wrapper.eq(EnergyRecord::getRoomId, roomId);
        }
        if (energyType != null) {
            wrapper.eq(EnergyRecord::getEnergyType, energyType);
        }
        if (startDate != null) {
            wrapper.ge(EnergyRecord::getRecordDate, startDate);
        }
        if (endDate != null) {
            wrapper.le(EnergyRecord::getRecordDate, endDate);
        }
        wrapper.orderByDesc(EnergyRecord::getRecordDate);

        Page<EnergyRecord> energyPage = this.page(page, wrapper);

        // 转换为VO
        Page<EnergyRecordVO> voPage = new Page<>(energyPage.getCurrent(), energyPage.getSize(), energyPage.getTotal());
        voPage.setRecords(energyPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    public EnergyStatisticsVO getEnergyStatistics(Long buildingId, Long roomId, LocalDate startDate, LocalDate endDate) {
        LambdaQueryWrapper<EnergyRecord> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(EnergyRecord::getBuildingId, buildingId);
        }
        if (roomId != null) {
            wrapper.eq(EnergyRecord::getRoomId, roomId);
        }
        if (startDate != null) {
            wrapper.ge(EnergyRecord::getRecordDate, startDate);
        }
        if (endDate != null) {
            wrapper.le(EnergyRecord::getRecordDate, endDate);
        }

        List<EnergyRecord> records = this.list(wrapper);

        EnergyStatisticsVO statistics = new EnergyStatisticsVO();
        BigDecimal electricityUsage = BigDecimal.ZERO;
        BigDecimal electricityCost = BigDecimal.ZERO;
        BigDecimal waterUsage = BigDecimal.ZERO;
        BigDecimal waterCost = BigDecimal.ZERO;

        for (EnergyRecord record : records) {
            if (record.getEnergyType() == 1) { // 用电
                electricityUsage = electricityUsage.add(record.getConsumption());
                electricityCost = electricityCost.add(record.getCost());
            } else { // 用水
                waterUsage = waterUsage.add(record.getConsumption());
                waterCost = waterCost.add(record.getCost());
            }
        }

        statistics.setElectricityUsage(electricityUsage);
        statistics.setElectricityCost(electricityCost);
        statistics.setWaterUsage(waterUsage);
        statistics.setWaterCost(waterCost);
        statistics.setTotalCost(electricityCost.add(waterCost));

        return statistics;
    }

    @Override
    public List<EnergyStatisticsVO> getDailyTrend(Long buildingId, Long roomId, LocalDate startDate, LocalDate endDate) {
        List<EnergyStatisticsVO> trend = new ArrayList<>();

        // 获取所有记录
        LambdaQueryWrapper<EnergyRecord> wrapper = new LambdaQueryWrapper<>();
        if (buildingId != null) {
            wrapper.eq(EnergyRecord::getBuildingId, buildingId);
        }
        if (roomId != null) {
            wrapper.eq(EnergyRecord::getRoomId, roomId);
        }
        if (startDate != null) {
            wrapper.ge(EnergyRecord::getRecordDate, startDate);
        }
        if (endDate != null) {
            wrapper.le(EnergyRecord::getRecordDate, endDate);
        }
        wrapper.orderByAsc(EnergyRecord::getRecordDate);

        List<EnergyRecord> records = this.list(wrapper);

        // 按日期分组统计
        LocalDate currentDate = null;
        EnergyStatisticsVO dayStatistics = null;

        for (EnergyRecord record : records) {
            if (!record.getRecordDate().equals(currentDate)) {
                if (dayStatistics != null) {
                    trend.add(dayStatistics);
                }
                currentDate = record.getRecordDate();
                dayStatistics = new EnergyStatisticsVO();
                dayStatistics.setDate(currentDate);
                dayStatistics.setElectricityUsage(BigDecimal.ZERO);
                dayStatistics.setElectricityCost(BigDecimal.ZERO);
                dayStatistics.setWaterUsage(BigDecimal.ZERO);
                dayStatistics.setWaterCost(BigDecimal.ZERO);
                dayStatistics.setTotalCost(BigDecimal.ZERO);
            }

            if (record.getEnergyType() == 1) {
                dayStatistics.setElectricityUsage(dayStatistics.getElectricityUsage().add(record.getConsumption()));
                dayStatistics.setElectricityCost(dayStatistics.getElectricityCost().add(record.getCost()));
            } else {
                dayStatistics.setWaterUsage(dayStatistics.getWaterUsage().add(record.getConsumption()));
                dayStatistics.setWaterCost(dayStatistics.getWaterCost().add(record.getCost()));
            }
            dayStatistics.setTotalCost(dayStatistics.getTotalCost().add(record.getCost()));
        }

        if (dayStatistics != null) {
            trend.add(dayStatistics);
        }

        return trend;
    }

    @Override
    public void addEnergyRecord(EnergyRecord record) {
        // 检查是否异常（简单规则：用量超过平均值的2倍视为异常）
        LambdaQueryWrapper<EnergyRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(EnergyRecord::getRoomId, record.getRoomId())
            .eq(EnergyRecord::getEnergyType, record.getEnergyType())
            .last("LIMIT 10");

        List<EnergyRecord> recentRecords = this.list(wrapper);
        if (!recentRecords.isEmpty()) {
            BigDecimal avgUsage = recentRecords.stream()
                .map(EnergyRecord::getConsumption)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(recentRecords.size()), 2, RoundingMode.HALF_UP);

            if (record.getConsumption().compareTo(avgUsage.multiply(BigDecimal.valueOf(2))) > 0) {
                record.setIsAbnormal(1);
                record.setAbnormalReason("用量超过近期平均值的2倍");
            }
        }

        this.save(record);
    }

    @Override
    public Page<EnergyRecordVO> getAbnormalRecords(Integer pageNum, Integer pageSize, Long buildingId) {
        Page<EnergyRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<EnergyRecord> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(EnergyRecord::getBuildingId, buildingId);
        }
        wrapper.eq(EnergyRecord::getIsAbnormal, 1);
        wrapper.orderByDesc(EnergyRecord::getRecordDate);

        Page<EnergyRecord> energyPage = this.page(page, wrapper);

        // 转换为VO
        Page<EnergyRecordVO> voPage = new Page<>(energyPage.getCurrent(), energyPage.getSize(), energyPage.getTotal());
        voPage.setRecords(energyPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    /**
     * 转换为VO
     */
    private EnergyRecordVO convertToVO(EnergyRecord record) {
        EnergyRecordVO vo = new EnergyRecordVO();
        BeanUtil.copyProperties(record, vo);

        // 获取房间信息
        Room room = roomMapper.selectById(record.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        // 获取楼栋信息
        Building building = buildingMapper.selectById(record.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        // 设置能耗类型名称
        vo.setEnergyTypeName(record.getEnergyType() == 1 ? "用电" : "用水");

        return vo;
    }
}
