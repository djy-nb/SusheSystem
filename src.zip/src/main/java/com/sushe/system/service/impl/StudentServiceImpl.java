package com.sushe.system.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.dto.StudentDTO;
import com.sushe.system.entity.CheckIn;
import com.sushe.system.entity.User;
import com.sushe.system.mapper.StudentMapper;
import com.sushe.system.service.CheckInService;
import com.sushe.system.service.StudentService;
import com.sushe.system.vo.StudentVO;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import com.sushe.system.common.BusinessException;

import java.util.List;

/**
 * 学生Service实现类
 */
@Service
@RequiredArgsConstructor
public class StudentServiceImpl extends ServiceImpl<StudentMapper, User> implements StudentService {

    private final PasswordEncoder passwordEncoder;
    private final CheckInService checkInService;

    @Override
    public Page<StudentVO> getStudentPage(
            Integer pageNum,
            Integer pageSize,
            String studentNo,
            String name,
            Long buildingId,
            Long roomId,
            Integer status
    ) {
        // 查询学生列表
        List<StudentVO> studentList = baseMapper.selectStudentList(
                studentNo, name, buildingId, roomId, status
        );

        // 手动分页
        int total = studentList.size();
        int fromIndex = (pageNum - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, total);

        List<StudentVO> pageRecords;
        if (fromIndex < total) {
            pageRecords = studentList.subList(fromIndex, toIndex);
        } else {
            pageRecords = List.of();
        }

        Page<StudentVO> page = new Page<>(pageNum, pageSize, total);
        page.setRecords(pageRecords);
        return page;
    }

    @Override
    public StudentVO getStudentDetail(Long id) {
        return baseMapper.selectStudentDetail(id);
    }

    @Override
    @Transactional
    public void addStudent(StudentDTO studentDTO) {
        // 检查学号是否已存在
        int count = baseMapper.countByStudentNo(studentDTO.getStudentNo());
        if (count > 0) {
            throw new BusinessException("学号已存在");
        }

        // 创建用户
        User user = new User();
        user.setUsername(studentDTO.getStudentNo());
        user.setRealName(studentDTO.getName());
        // 性别转换：男->1, 女->0
        user.setGender("男".equals(studentDTO.getGender()) ? 1 : 0);
        user.setPhone(studentDTO.getPhone());
        user.setEmail(studentDTO.getEmail());
        user.setUserCode(studentDTO.getStudentNo());
        user.setCollege(studentDTO.getCollege());
        user.setClassName(studentDTO.getClassName());
        user.setIdCard(studentDTO.getIdCard());
        user.setRole("STUDENT");
        // 设置默认密码为123456
        user.setPassword(passwordEncoder.encode("123456"));
        user.setStatus(1);
        user.setDeleted(0);

        this.save(user);

        // 如果指定了宿舍，创建入住记录
        if (studentDTO.getRoomId() != null) {
            CheckIn checkIn = new CheckIn();
            checkIn.setStudentId(user.getId());
            checkIn.setBuildingId(studentDTO.getBuildingId());
            checkIn.setRoomId(studentDTO.getRoomId());
            checkIn.setBedId(studentDTO.getBedId());
            checkIn.setStatus(1);
            checkIn.setCheckInType(1); // 正常入住
            checkIn.setCheckInTime(LocalDateTime.now());
            checkIn.setAcademicYear("2023-2024");
            checkInService.save(checkIn);
        }
    }

    @Override
    @Transactional
    public void updateStudent(StudentDTO studentDTO) {
        User user = this.getById(studentDTO.getId());
        if (user == null) {
            throw new BusinessException("学生不存在");
        }

        // 检查学号是否已存在（排除当前用户）
        int count = baseMapper.countByStudentNoExcludeId(studentDTO.getStudentNo(), studentDTO.getId());
        if (count > 0) {
            throw new BusinessException("学号已存在");
        }

        // 更新用户信息
        user.setRealName(studentDTO.getName());
        user.setGender("男".equals(studentDTO.getGender()) ? 1 : 0);
        user.setPhone(studentDTO.getPhone());
        user.setEmail(studentDTO.getEmail());
        user.setUserCode(studentDTO.getStudentNo());
        user.setCollege(studentDTO.getCollege());
        user.setClassName(studentDTO.getClassName());
        user.setIdCard(studentDTO.getIdCard());

        this.updateById(user);

        // 更新宿舍分配（简化处理：先删除旧入住记录，再创建新的）
        if (studentDTO.getRoomId() != null) {
            // 查找当前入住记录
            CheckIn currentCheckIn = checkInService.lambdaQuery()
                    .eq(CheckIn::getStudentId, user.getId())
                    .eq(CheckIn::getStatus, 1)
                    .one();

            if (currentCheckIn != null) {
                // 退掉旧房间
                currentCheckIn.setStatus(0);
                currentCheckIn.setCheckOutTime(LocalDateTime.now());
                checkInService.updateById(currentCheckIn);
            }

            // 入住新房间
            CheckIn newCheckIn = new CheckIn();
            newCheckIn.setStudentId(user.getId());
            newCheckIn.setBuildingId(studentDTO.getBuildingId());
            newCheckIn.setRoomId(studentDTO.getRoomId());
            newCheckIn.setBedId(studentDTO.getBedId());
            newCheckIn.setStatus(1);
            newCheckIn.setCheckInType(2); // 调宿
            newCheckIn.setCheckInTime(LocalDateTime.now());
            newCheckIn.setAcademicYear("2023-2024");
            checkInService.save(newCheckIn);
        }
    }

    @Override
    @Transactional
    public void deleteStudent(Long id) {
        User user = this.getById(id);
        if (user == null) {
            throw new BusinessException("学生不存在");
        }

        // 删除入住记录
        checkInService.lambdaUpdate()
                .eq(CheckIn::getStudentId, id)
                .eq(CheckIn::getStatus, 1)
                .set(CheckIn::getStatus, 0)
                .set(CheckIn::getCheckOutTime, LocalDateTime.now())
                .update();

        // 逻辑删除用户
        this.removeById(id);
    }

    @Override
    public void resetStudentPassword(Long id) {
        User user = this.getById(id);
        if (user == null) {
            throw new BusinessException("学生不存在");
        }

        // 重置为默认密码123456
        user.setPassword(passwordEncoder.encode("123456"));
        this.updateById(user);
    }

    @Override
    public void updateStudentStatus(Long id, Integer status) {
        User user = this.getById(id);
        if (user == null) {
            throw new BusinessException("学生不存在");
        }

        user.setStatus(status);
        this.updateById(user);

        // 如果是退宿状态，更新入住记录
        if (status == 2) {
            checkInService.lambdaUpdate()
                    .eq(CheckIn::getStudentId, id)
                    .eq(CheckIn::getStatus, 1)
                    .set(CheckIn::getStatus, 0)
                    .set(CheckIn::getCheckOutTime, LocalDateTime.now())
                    .update();
        }
    }
}
