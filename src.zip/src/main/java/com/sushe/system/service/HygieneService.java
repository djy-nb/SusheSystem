package com.sushe.system.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sushe.system.entity.HygieneCheck;
import com.sushe.system.vo.HygieneCheckVO;
import com.sushe.system.vo.HygieneStatisticsVO;

import java.time.LocalDate;
import java.util.List;

/**
 * 卫生检查Service接口
 */
public interface HygieneService extends IService<HygieneCheck> {

    /**
     * 分页查询卫生检查记录
     */
    Page<HygieneCheckVO> getHygienePage(Integer pageNum, Integer pageSize, Long buildingId, Long roomId,
                                         Integer checkType, String grade, LocalDate startDate, LocalDate endDate);

    /**
     * 获取卫生检查详情
     */
    HygieneCheckVO getHygieneDetail(Long id);

    /**
     * 提交卫生检查
     */
    void submitCheck(HygieneCheck check);

    /**
     * 更新卫生检查
     */
    void updateCheck(HygieneCheck check);

    /**
     * 获取卫生统计
     */
    HygieneStatisticsVO getHygieneStatistics(Long buildingId, LocalDate startDate, LocalDate endDate);

    /**
     * 获取各楼栋卫生排名
     */
    List<HygieneStatisticsVO> getBuildingRanking(LocalDate startDate, LocalDate endDate);

    /**
     * 提交整改
     */
    void submitRectification(Long id);

    /**
     * 验收整改
     */
    void verifyRectification(Long id, Integer status);
}
