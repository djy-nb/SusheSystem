package com.sushe.system.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sushe.system.entity.*;
import com.sushe.system.mapper.*;
import com.sushe.system.service.CheckInService;
import com.sushe.system.vo.CheckInVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sushe.system.common.BusinessException;

import java.time.LocalDateTime;

/**
 * 入住记录Service实现类
 */
@Service
@RequiredArgsConstructor
public class CheckInServiceImpl extends ServiceImpl<CheckInMapper, CheckIn> implements CheckInService {

    private final UserMapper userMapper;
    private final RoomMapper roomMapper;
    private final BedMapper bedMapper;
    private final BuildingMapper buildingMapper;

    @Override
    public long countCheckedIn() {
        return this.count(new LambdaQueryWrapper<CheckIn>().eq(CheckIn::getStatus, 1));
    }

    @Override
    public Page<CheckInVO> getCheckInPage(Integer pageNum, Integer pageSize, Long buildingId, Long roomId, Integer status) {
        Page<CheckIn> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<CheckIn> wrapper = new LambdaQueryWrapper<>();

        if (buildingId != null) {
            wrapper.eq(CheckIn::getBuildingId, buildingId);
        }
        if (roomId != null) {
            wrapper.eq(CheckIn::getRoomId, roomId);
        }
        if (status != null) {
            // 用户明确指定了状态筛选
            wrapper.eq(CheckIn::getStatus, status);
        } else {
            // 默认只显示在住学生（status=1）
            wrapper.eq(CheckIn::getStatus, 1);
        }
        wrapper.orderByDesc(CheckIn::getCreateTime);

        Page<CheckIn> checkInPage = this.page(page, wrapper);

        // 转换为VO
        Page<CheckInVO> voPage = new Page<>(checkInPage.getCurrent(), checkInPage.getSize(), checkInPage.getTotal());
        voPage.setRecords(checkInPage.getRecords().stream()
            .map(this::convertToVO)
            .toList());

        return voPage;
    }

    @Override
    @Transactional
    public void checkIn(CheckIn checkIn) {
        // 检查学生是否已入住
        long count = this.count(new LambdaQueryWrapper<CheckIn>()
            .eq(CheckIn::getStudentId, checkIn.getStudentId())
            .eq(CheckIn::getStatus, 1));
        if (count > 0) {
            throw new BusinessException("该学生已入住其他房间");
        }

        // 检查床位是否可用
        Bed bed = bedMapper.selectById(checkIn.getBedId());
        if (bed == null || bed.getStatus() != 0) {
            throw new BusinessException("该床位不可用");
        }

        // 更新床位状态
        bed.setStatus(1);
        bed.setStudentId(checkIn.getStudentId());
        bed.setCheckInTime(LocalDateTime.now());
        bedMapper.updateById(bed);

        // 更新房间入住人数
        Room room = roomMapper.selectById(checkIn.getRoomId());
        room.setOccupiedCount(room.getOccupiedCount() + 1);
        if (room.getOccupiedCount() >= room.getBedCount()) {
            room.setStatus(3); // 已满
        }
        roomMapper.updateById(room);

        // 更新楼栋入住人数
        Building building = buildingMapper.selectById(checkIn.getBuildingId());
        building.setOccupiedCount(building.getOccupiedCount() + 1);
        buildingMapper.updateById(building);

        // 保存入住记录
        checkIn.setCheckInTime(LocalDateTime.now());
        checkIn.setStatus(1);
        checkIn.setCheckInType(1);
        this.save(checkIn);
    }

    @Override
    @Transactional
    public void checkOut(Long id) {
        CheckIn checkIn = this.getById(id);
        if (checkIn == null || checkIn.getStatus() != 1) {
            throw new BusinessException("入住记录不存在或已退宿");
        }

        // 更新床位状态
        Bed bed = bedMapper.selectById(checkIn.getBedId());
        bed.setStatus(0);
        bed.setStudentId(null);
        bed.setCheckInTime(null);
        bedMapper.updateById(bed);

        // 更新房间入住人数
        Room room = roomMapper.selectById(checkIn.getRoomId());
        room.setOccupiedCount(room.getOccupiedCount() - 1);
        if (room.getStatus() == 3) {
            room.setStatus(1); // 恢复正常
        }
        roomMapper.updateById(room);

        // 更新楼栋入住人数
        Building building = buildingMapper.selectById(checkIn.getBuildingId());
        building.setOccupiedCount(building.getOccupiedCount() - 1);
        buildingMapper.updateById(building);

        // 更新入住记录
        checkIn.setCheckOutTime(LocalDateTime.now());
        checkIn.setStatus(0);
        this.updateById(checkIn);
    }

    @Override
    @Transactional
    public void changeRoom(Long id, Long newRoomId, Long newBedId) {
        CheckIn oldCheckIn = this.getById(id);
        if (oldCheckIn == null || oldCheckIn.getStatus() != 1) {
            throw new BusinessException("入住记录不存在或已退宿");
        }

        // 先退宿
        checkOut(id);

        // 再入住新房间
        CheckIn newCheckIn = new CheckIn();
        newCheckIn.setStudentId(oldCheckIn.getStudentId());
        newCheckIn.setRoomId(newRoomId);
        newCheckIn.setBedId(newBedId);

        Room newRoom = roomMapper.selectById(newRoomId);
        newCheckIn.setBuildingId(newRoom.getBuildingId());
        newCheckIn.setAcademicYear(oldCheckIn.getAcademicYear());
        newCheckIn.setCheckInType(2); // 调宿

        checkIn(newCheckIn);
    }

    /**
     * 转换为VO
     */
    private CheckInVO convertToVO(CheckIn checkIn) {
        CheckInVO vo = new CheckInVO();
        BeanUtil.copyProperties(checkIn, vo);

        // 获取学生信息
        User student = userMapper.selectById(checkIn.getStudentId());
        if (student != null) {
            vo.setStudentName(student.getRealName());
            vo.setStudentCode(student.getUserCode());
        }

        // 获取房间信息
        Room room = roomMapper.selectById(checkIn.getRoomId());
        if (room != null) {
            vo.setRoomNumber(room.getRoomNumber());
        }

        // 获取楼栋信息
        Building building = buildingMapper.selectById(checkIn.getBuildingId());
        if (building != null) {
            vo.setBuildingName(building.getName());
        }

        // 获取床位信息
        Bed bed = bedMapper.selectById(checkIn.getBedId());
        if (bed != null) {
            vo.setBedNumber(bed.getBedNumber());
        }

        // 设置状态名称
        vo.setStatusName(checkIn.getStatus() == 1 ? "在住" : "已退宿");

        // 设置入住类型名称
        switch (checkIn.getCheckInType()) {
            case 1 -> vo.setCheckInTypeName("正常入住");
            case 2 -> vo.setCheckInTypeName("调宿");
            case 3 -> vo.setCheckInTypeName("临时入住");
            default -> vo.setCheckInTypeName("未知");
        }

        return vo;
    }
}
