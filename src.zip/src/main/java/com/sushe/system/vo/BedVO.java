package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 床位VO
 */
@Data
public class BedVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 床位ID */
    private Long id;

    /** 房间ID */
    private Long roomId;

    /** 床位号 */
    private Integer bedNumber;

    /** 位置描述 */
    private String position;

    /** 状态 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 入住学生ID */
    private Long studentId;

    /** 学生姓名 */
    private String studentName;

    /** 学号 */
    private String studentCode;

    /** 入住时间 */
    private LocalDateTime checkInTime;
}
