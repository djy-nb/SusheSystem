package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 入住记录VO
 */
@Data
public class CheckInVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    private Long id;

    /** 学生ID */
    private Long studentId;

    /** 学生姓名 */
    private String studentName;

    /** 学号 */
    private String studentCode;

    /** 房间ID */
    private Long roomId;

    /** 房间号 */
    private String roomNumber;

    /** 床位ID */
    private Long bedId;

    /** 床位号 */
    private Integer bedNumber;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 学年 */
    private String academicYear;

    /** 入住时间 */
    private LocalDateTime checkInTime;

    /** 退宿时间 */
    private LocalDateTime checkOutTime;

    /** 状态 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 入住类型 */
    private Integer checkInType;

    /** 入住类型名称 */
    private String checkInTypeName;

    /** 备注 */
    private String remark;

    /** 创建时间 */
    private LocalDateTime createTime;
}
