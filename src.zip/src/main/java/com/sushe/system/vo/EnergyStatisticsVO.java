package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 能耗统计VO
 */
@Data
public class EnergyStatisticsVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 日期 */
    private LocalDate date;

    /** 用电量 */
    private BigDecimal electricityUsage;

    /** 用电费用 */
    private BigDecimal electricityCost;

    /** 用水量 */
    private BigDecimal waterUsage;

    /** 用水费用 */
    private BigDecimal waterCost;

    /** 总费用 */
    private BigDecimal totalCost;

    /** 同比增长（百分比） */
    private BigDecimal yearOverYear;

    /** 环比增长（百分比） */
    private BigDecimal monthOverMonth;
}
