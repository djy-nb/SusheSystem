package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 报修VO
 */
@Data
public class RepairVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 工单ID */
    private Long id;

    /** 工单编号 */
    private String orderNo;

    /** 报修人ID */
    private Long userId;

    /** 报修人姓名 */
    private String userName;

    /** 房间ID */
    private Long roomId;

    /** 房间号 */
    private String roomNumber;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 报修类型 */
    private Integer repairType;

    /** 报修类型名称 */
    private String repairTypeName;

    /** 报修标题 */
    private String title;

    /** 问题描述 */
    private String description;

    /** 图片 */
    private String images;

    /** 联系电话 */
    private String contactPhone;

    /** 优先级 */
    private Integer priority;

    /** 优先级名称 */
    private String priorityName;

    /** 状态 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 维修人员ID */
    private Long repairerId;

    /** 维修人员姓名 */
    private String repairerName;

    /** 维修说明 */
    private String repairNote;

    /** 维修图片 */
    private String repairImages;

    /** 维修费用 */
    private BigDecimal cost;

    /** 评价评分 */
    private Integer rating;

    /** 评价内容 */
    private String evaluateContent;

    /** 完成时间 */
    private LocalDateTime completeTime;

    /** 创建时间 */
    private LocalDateTime createTime;
}
