package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 卫生统计VO
 */
@Data
public class HygieneStatisticsVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 检查次数 */
    private Integer checkCount;

    /** 平均分 */
    private BigDecimal averageScore;

    /** 优秀率（A等级占比） */
    private BigDecimal excellentRate;

    /** 合格率（A+B+C等级占比） */
    private BigDecimal passRate;

    /** 不合格次数 */
    private Integer failCount;

    /** 违禁品检出次数 */
    private Integer contrabandCount;

    /** 待整改数量 */
    private Integer pendingRectification;

    /** 排名 */
    private Integer ranking;
}
