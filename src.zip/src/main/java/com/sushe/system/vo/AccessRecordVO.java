package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 门禁记录VO
 */
@Data
public class AccessRecordVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    private Long id;

    /** 用户ID */
    private Long userId;

    /** 用户姓名 */
    private String userName;

    /** 学号/工号 */
    private String userCode;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 通行方向 */
    private Integer direction;

    /** 通行方向名称 */
    private String directionName;

    /** 验证方式 */
    private Integer verifyType;

    /** 验证方式名称 */
    private String verifyTypeName;

    /** 验证结果 */
    private Integer verifyResult;

    /** 验证结果名称 */
    private String verifyResultName;

    /** 失败原因 */
    private String failReason;

    /** 体温 */
    private Double temperature;

    /** 抓拍图片 */
    private String captureImage;

    /** 设备编号 */
    private String deviceCode;

    /** 通行时间 */
    private LocalDateTime passTime;

    /** 创建时间 */
    private LocalDateTime createTime;
}
