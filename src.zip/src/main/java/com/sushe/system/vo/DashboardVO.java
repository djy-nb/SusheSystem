package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.util.List;

/**
 * 首页仪表盘VO
 */
@Data
public class DashboardVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 学生总数 */
    private Long studentCount;

    /** 楼栋总数 */
    private Long buildingCount;

    /** 房间总数 */
    private Long roomCount;

    /** 在住人数 */
    private Long checkInCount;

    /** 待处理报修数 */
    private Long pendingRepairCount;

    /** 最新通知 */
    private List<NoticeVO> latestNotices;
}
