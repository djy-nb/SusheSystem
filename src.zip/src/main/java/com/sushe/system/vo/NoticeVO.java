package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 通知公告VO
 */
@Data
public class NoticeVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 通知ID */
    private Long id;

    /** 标题 */
    private String title;

    /** 内容 */
    private String content;

    /** 类型 */
    private Integer type;

    /** 类型名称 */
    private String typeName;

    /** 优先级 */
    private Integer priority;

    /** 优先级名称 */
    private String priorityName;

    /** 目标范围 */
    private Integer targetRange;

    /** 目标范围名称 */
    private String targetRangeName;

    /** 是否置顶 */
    private Integer isTop;

    /** 附件 */
    private String attachment;

    /** 发布人姓名 */
    private String publisherName;

    /** 状态 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 发布时间 */
    private LocalDateTime publishTime;

    /** 阅读人数 */
    private Integer readCount;

    /** 创建时间 */
    private LocalDateTime createTime;
}
