package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * 门禁统计VO
 */
@Data
public class AccessStatisticsVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 日期 */
    private LocalDate date;

    /** 进入人数 */
    private Integer enterCount;

    /** 离开人数 */
    private Integer leaveCount;

    /** 总通行次数 */
    private Integer totalCount;

    /** 验证成功次数 */
    private Integer successCount;

    /** 验证失败次数 */
    private Integer failCount;

    /** 成功率 */
    private Double successRate;

    /** 异常体温人数 */
    private Integer abnormalTemperatureCount;
}
