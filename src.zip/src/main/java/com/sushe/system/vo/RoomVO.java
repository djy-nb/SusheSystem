package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 房间VO
 */
@Data
public class RoomVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 房间ID */
    private Long id;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 房间号 */
    private String roomNumber;

    /** 楼层 */
    private Integer floor;

    /** 房间类型 */
    private Integer roomType;

    /** 房间类型名称 */
    private String roomTypeName;

    /** 床位数 */
    private Integer bedCount;

    /** 已入住人数 */
    private Integer occupiedCount;

    /** 面积 */
    private BigDecimal area;

    /** 状态 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 是否有独立卫生间 */
    private Integer hasBathroom;

    /** 是否有空调 */
    private Integer hasAircon;

    /** 是否有热水器 */
    private Integer hasWaterHeater;

    /** 每学年费用 */
    private BigDecimal price;

    /** 备注 */
    private String remark;

    /** 床位列表 */
    private List<BedVO> beds;

    /** 创建时间 */
    private LocalDateTime createTime;
}
