package com.sushe.system.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 学生信息VO
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StudentVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 学生ID */
    private Long id;

    /** 用户名 */
    private String username;

    /** 真实姓名 */
    private String name;

    /** 性别 */
    private String gender;

    /** 联系电话 */
    private String phone;

    /** 邮箱 */
    private String email;

    /** 学号 */
    private String studentNo;

    /** 所属学院 */
    private String college;

    /** 所属班级 */
    private String className;

    /** 身份证号 */
    private String idCard;

    /** 账号状态：1-在住 2-已退宿 3-休学 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 房间ID */
    private Long roomId;

    /** 房间号 */
    private String roomNumber;

    /** 床位ID（用于编辑时的数据回填） */
    private Long bedId;

    /** 床位号（实际床位编号，如1、2、3） */
    private Integer bedNumber;

    /** 入住时间 */
    private LocalDateTime checkInTime;

    /** 创建时间 */
    private LocalDateTime createTime;

    /**
     * 获取宿舍信息描述
     */
    public String getRoomInfo() {
        if (buildingName == null && roomNumber == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        if (buildingName != null) {
            sb.append(buildingName);
        }
        if (roomNumber != null) {
            sb.append(" ").append(roomNumber);
        }
        if (bedNumber != null) {
            sb.append(" ").append(bedNumber).append("床");
        }
        return sb.toString();
    }
}
