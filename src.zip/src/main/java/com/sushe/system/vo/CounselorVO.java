package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 辅导员仪表盘统计VO
 */
@Data
public class CounselorVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 所辖学生总数 */
    private Long studentCount;

    /** 在住学生人数 */
    private Long checkedInCount;

    /** 待处理报修数 */
    private Long pendingRepairCount;

    /** 卫生不合格房间数 */
    private Long hygieneFailCount;

    /** 今日异常门禁数 */
    private Long abnormalAccessCount;

    /** 学院名称 */
    private String collegeName;

    /** 辅导员姓名 */
    private String counselorName;

    /** 卫生平均分 */
    private BigDecimal hygieneAvgScore;

    /** 本月报修总数 */
    private Long monthlyRepairCount;
}
