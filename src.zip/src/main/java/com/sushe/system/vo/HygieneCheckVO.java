package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 卫生检查VO
 */
@Data
public class HygieneCheckVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 检查ID */
    private Long id;

    /** 房间ID */
    private Long roomId;

    /** 房间号 */
    private String roomNumber;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 检查日期 */
    private LocalDate checkDate;

    /** 检查类型 */
    private Integer checkType;

    /** 检查类型名称 */
    private String checkTypeName;

    /** 整体评分 */
    private Integer score;

    /** 等级 */
    private String grade;

    /** 地面清洁评分 */
    private Integer floorScore;

    /** 桌面整洁评分 */
    private Integer deskScore;

    /** 床铺整洁评分 */
    private Integer bedScore;

    /** 卫生间评分 */
    private Integer bathroomScore;

    /** 阳台评分 */
    private Integer balconyScore;

    /** 是否有违禁品 */
    private Integer hasContraband;

    /** 违禁品说明 */
    private String contrabandDetail;

    /** 检查图片 */
    private String images;

    /** 检查人姓名 */
    private String checkerName;

    /** 整改要求 */
    private String rectification;

    /** 整改期限 */
    private LocalDate rectificationDeadline;

    /** 整改状态 */
    private Integer rectificationStatus;

    /** 整改状态名称 */
    private String rectificationStatusName;

    /** 备注 */
    private String remark;

    /** 创建时间 */
    private LocalDateTime createTime;
}
