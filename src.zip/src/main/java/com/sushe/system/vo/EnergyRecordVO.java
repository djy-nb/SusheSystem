package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 能耗记录VO
 */
@Data
public class EnergyRecordVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 记录ID */
    private Long id;

    /** 房间ID */
    private Long roomId;

    /** 房间号 */
    private String roomNumber;

    /** 楼栋ID */
    private Long buildingId;

    /** 楼栋名称 */
    private String buildingName;

    /** 能耗类型 */
    private Integer energyType;

    /** 能耗类型名称 */
    private String energyTypeName;

    /** 读数 */
    private BigDecimal meterReading;

    /** 用量 */
    private BigDecimal consumption;

    /** 费用 */
    private BigDecimal cost;

    /** 记录日期 */
    private LocalDate recordDate;

    /** 是否异常 */
    private Integer isAbnormal;

    /** 异常原因 */
    private String abnormalReason;

    /** 创建时间 */
    private LocalDateTime createTime;
}
