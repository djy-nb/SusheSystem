package com.sushe.system.vo;

import lombok.Data;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 宿舍楼VO
 */
@Data
public class BuildingVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 楼栋ID */
    private Long id;

    /** 楼栋名称 */
    private String name;

    /** 楼栋编号 */
    private String code;

    /** 楼层数 */
    private Integer floorCount;

    /** 总房间数 */
    private Integer roomCount;

    /** 已入住人数 */
    private Integer occupiedCount;

    /** 楼栋类型 */
    private Integer type;

    /** 楼栋类型名称 */
    private String typeName;

    /** 地址 */
    private String address;

    /** 宿管员姓名 */
    private String adminName;

    /** 联系电话 */
    private String contactPhone;

    /** 状态 */
    private Integer status;

    /** 状态名称 */
    private String statusName;

    /** 创建时间 */
    private LocalDateTime createTime;
}
